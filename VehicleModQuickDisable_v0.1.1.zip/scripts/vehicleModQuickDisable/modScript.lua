-- Load the UI mod-deactivation helper for the entire game session.
load("extensions.vehicle_mod_quick_disable")
setExtensionUnloadMode("vehicle_mod_quick_disable", "manual")
