import { runRaw } from "@/bridge/libs/Lua"
import { openConfirmation } from "@/services/popup"
import { ACCENTS } from "@/common/components/base"

const WRAPPER_CLASS = "vmd-right-quick-disable"
const STYLE_ID = "vmd-right-quick-disable-style"
const infoCache = new Map()
const pending = new Map()
const failedAt = new Map()
let observer = null
let scanTimer = null
let started = false

function luaString(value) {
  return '"' + String(value ?? "").replace(/\\/g, "\\\\").replace(/"/g, '\\"').replace(/[\r\n]/g, " ") + '"'
}

function decodeLuaResult(result) {
  if (result && typeof result === "object") return result
  if (typeof result !== "string") return null
  try { return JSON.parse(result) } catch (_) {}
  try { return JSON.parse(JSON.parse(result)) } catch (_) {}
  return null
}

function inSelector() {
  const route = String(window.location?.hash || window.location?.pathname || "").toLowerCase()
  return /vehicle-selector|freeroam-wizard|freeroam-selector|level-selector|vehicleselect/.test(route)
}

function isVisible(element) {
  if (!element?.isConnected) return false
  const rect = element.getBoundingClientRect()
  return rect.width > 0 && rect.height > 0 && getComputedStyle(element).visibility !== "hidden"
}

function readUrls(element) {
  if (!element) return []
  const nodes = [element, ...element.querySelectorAll("img, [style], .preview-image")]
  const values = []
  for (const node of nodes) {
    for (const attr of ["src", "data-src", "style", "alt", "title"]) {
      const value = node.getAttribute?.(attr)
      if (value) values.push(value)
    }
    if (node.currentSrc) values.push(node.currentSrc)
    const background = getComputedStyle(node).backgroundImage
    if (background && background !== "none") values.push(background)
  }
  return values
}

function keyFromElements(elements) {
  for (const element of elements) {
    for (const value of readUrls(element)) {
      const decoded = String(value).replace(/\\\//g, "/")
      const match = decoded.match(/(?:^|[\\/])((?:vehicles|levels))[\\/]([A-Za-z0-9_.-]+)(?=[\\/?#]|$)/i)
      if (match) {
        return {
          kind: match[1].toLowerCase() === "vehicles" ? "vehicle" : "level",
          id: match[2],
          label: element.querySelector?.(".header-title, .item-name")?.textContent?.trim() || "",
        }
      }
    }
  }
  return null
}

async function getInfo(key) {
  const cacheKey = `${key.kind}:${key.id}`
  if (infoCache.has(cacheKey)) return infoCache.get(cacheKey)
  if (pending.has(cacheKey)) return pending.get(cacheKey)
  if (Date.now() - (failedAt.get(cacheKey) || 0) < 4000) return null

  const request = runRaw(`extensions.vehicle_mod_quick_disable.getSourceInfo(${luaString(key.kind)}, ${luaString(key.id)})`)
    .then(decodeLuaResult)
    .catch(() => null)
    .then(result => {
      const info = result?.ok && result.info ? result.info : null
      if (info) infoCache.set(cacheKey, info)
      else failedAt.set(cacheKey, Date.now())
      pending.delete(cacheKey)
      return info
    })
  pending.set(cacheKey, request)
  return request
}

function installStyle() {
  if (document.getElementById(STYLE_ID)) return
  const style = document.createElement("style")
  style.id = STYLE_ID
  style.textContent = `
    .${WRAPPER_CLASS} {
      display: flex; width: 100%; box-sizing: border-box;
      align-items: center; justify-content: center; margin: .25rem 0;
    }
    .${WRAPPER_CLASS} button {
      width: 100%; min-height: 2rem; box-sizing: border-box;
      border: 1px solid rgba(255,255,255,.55); border-radius: .2rem;
      background: #a63e32; color: #fff; padding: .35rem .6rem;
      font: 700 .88rem/1.1 sans-serif; cursor: pointer;
    }
    .${WRAPPER_CLASS} button:hover { background: #c6533f; }
    .${WRAPPER_CLASS} button:disabled { opacity: .65; cursor: wait; }
  `
  document.head?.appendChild(style)
}

function removeInjectedButtons(except = null) {
  document.querySelectorAll(`.${WRAPPER_CLASS}`).forEach(node => {
    if (node !== except) node.remove()
  })
}

function findRightDetails() {
  const sections = [...document.querySelectorAll(".grid-section .bottom-section, .configurator-content .bottom-section")]
  return sections.find(isVisible) || null
}

function findActiveKey(bottomSection) {
  const grid = bottomSection?.closest(".grid-section, .configurator-content") || document
  const selectedTile = [...grid.querySelectorAll(".tile.selected")].find(isVisible)
  const previous = bottomSection?.previousElementSibling
  const detailPanel = previous?.matches(".details")
    ? previous
    : bottomSection?.parentElement?.querySelector(".details") || null
  return keyFromElements([
    detailPanel,
    selectedTile,
  ])
}

function getInsertionPoint(bottomSection) {
  // Keep the normal selector action (e.g. “Next Step”) intact and put our
  // action immediately before it. The paint swatches remain untouched.
  const children = [...bottomSection.children]
  const action = children.find(child =>
    !child.classList.contains("paint-list") &&
    (child.matches("bng-button, .bng-button, button") || child.querySelector?.("button, .bng-button"))
  )
  return action || null
}

async function addAction(bottomSection, key) {
  const cacheKey = `${key.kind}:${key.id}`
  const info = await getInfo(key)
  if (!started || !bottomSection.isConnected || !inSelector()) return
  if (!info || !info.active) {
    removeInjectedButtons()
    return
  }
  // Selection may have changed while the Lua request was in flight.
  const currentKey = findActiveKey(bottomSection)
  if (!currentKey || `${currentKey.kind}:${currentKey.id}` !== cacheKey) return

  let wrapper = bottomSection.querySelector(`:scope > .${WRAPPER_CLASS}`)
  if (!wrapper) {
    wrapper = document.createElement("div")
    wrapper.className = WRAPPER_CLASS
    const button = document.createElement("button")
    button.type = "button"
    button.textContent = "⏻  Çaktivizo modin"
    button.setAttribute("aria-label", "Çaktivizo modin e veturës ose hartës së zgjedhur")
    wrapper.appendChild(button)
    const insertBefore = getInsertionPoint(bottomSection)
    bottomSection.insertBefore(wrapper, insertBefore)

    button.addEventListener("click", async event => {
      event.preventDefault()
      event.stopPropagation()
      event.stopImmediatePropagation()
      const activeKey = findActiveKey(bottomSection)
      if (!activeKey || `${activeKey.kind}:${activeKey.id}` !== wrapper.dataset.key) return
      const activeInfo = await getInfo(activeKey)
      if (!activeInfo || !activeInfo.active) return

      const answer = await openConfirmation(
        "Çaktivizo këtë mod?",
        `Artikulli: ${activeKey.label || activeKey.id}\nZIP-i: ${activeInfo.filename || "emër i panjohur"}\n\nKy veprim e çaktivizon krejt ZIP-in, jo vetëm këtë veturë/hartë. Nëse arkiva ka disa artikuj, krejt preken. Nuk fshihet asnjë skedar.`,
        [
          { label: "Anulo", value: "cancel", extras: { cancel: true, outsideCancel: true, accent: ACCENTS.text } },
          { label: "Çaktivizo modin", value: "disable", extras: { default: true, confirm: true, accent: ACCENTS.main } },
        ],
      )
      if (answer !== "disable") return

      button.disabled = true
      let result = null
      try {
        result = decodeLuaResult(await runRaw(
          `extensions.vehicle_mod_quick_disable.deactivate(${luaString(activeKey.kind)}, ${luaString(activeKey.id)}, ${luaString(activeInfo.filename || "")})`
        ))
      } catch (_) {}

      if (result?.ok) {
        infoCache.set(`${activeKey.kind}:${activeKey.id}`, null)
        wrapper.remove()
        await openConfirmation(
          "Modi u çaktivizua",
          `${result.filename || activeInfo.filename} u çaktivizua, nuk u fshi. Mundesh me e fshi ZIP-in vetë te Mods Manager kur të jesh gati.`,
          [{ label: "Në rregull", value: "ok", extras: { default: true, confirm: true, accent: ACCENTS.main } }],
        )
      } else {
        button.disabled = false
        await openConfirmation(
          "S’u çaktivizua",
          result?.error || "Nuk u gjet ZIP-i burimor për artikullin e zgjedhur.",
          [{ label: "Në rregull", value: "ok", extras: { default: true, confirm: true, accent: ACCENTS.main } }],
        )
      }
    })
  }
  wrapper.dataset.key = cacheKey
  wrapper.title = `ZIP: ${info.filename || "emër i panjohur"}`
  const insertBefore = getInsertionPoint(bottomSection)
  if (wrapper.nextElementSibling !== insertBefore) bottomSection.insertBefore(wrapper, insertBefore)
}

function scan() {
  scanTimer = null
  if (!started || !document.body) return
  installStyle()
  if (!inSelector()) {
    removeInjectedButtons()
    return
  }
  const bottomSection = findRightDetails()
  if (!bottomSection) {
    removeInjectedButtons()
    return
  }
  const key = findActiveKey(bottomSection)
  if (!key) {
    removeInjectedButtons()
    return
  }
  const existing = bottomSection.querySelector(`:scope > .${WRAPPER_CLASS}`)
  if (existing?.dataset.key === `${key.kind}:${key.id}`) return
  removeInjectedButtons()
  void addAction(bottomSection, key)
}

function scheduleScan() {
  if (scanTimer || !started) return
  scanTimer = window.setTimeout(scan, 160)
}

export async function onLoad() {
  if (started) return
  started = true
  installStyle()
  observer = new MutationObserver(scheduleScan)
  observer.observe(document.documentElement, {
    childList: true,
    subtree: true,
    attributes: true,
    attributeFilter: ["class", "src", "style", "data-src"],
  })
  scheduleScan()
}

export async function onUnload() {
  started = false
  if (observer) observer.disconnect()
  observer = null
  if (scanTimer) window.clearTimeout(scanTimer)
  scanTimer = null
  removeInjectedButtons()
  document.getElementById(STYLE_ID)?.remove()
  infoCache.clear()
  pending.clear()
  failedAt.clear()
}
