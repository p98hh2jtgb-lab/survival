local M = {}

local function jsonResult(value)
  if jsonEncode then return jsonEncode(value) end
  return '{}'
end

local function cleanId(value)
  value = tostring(value or '')
  value = value:gsub('^.*[/\\]', '')
  value = value:gsub('[?#].*$', '')
  if value == '' or value:find('[^%w_.%-]') then return nil end
  return value
end

local function findModRecord(modTag)
  if not modTag or not core_modmanager or not core_modmanager.getModList then return nil, nil end
  local ok, mods = pcall(core_modmanager.getModList)
  if not ok or type(mods) ~= 'table' then return nil, nil end
  for key, mod in pairs(mods) do
    if type(mod) == 'table' and (tostring(key) == tostring(modTag)
        or tostring(mod.modname or '') == tostring(modTag)
        or tostring(mod.modID or '') == tostring(modTag)) then
      return key, mod
    end
  end
  return nil, nil
end

local function ownerForPath(path)
  if not core_modmanager or not core_modmanager.getModForFilename then return nil, nil end
  local ok, tag = pcall(core_modmanager.getModForFilename, path)
  if not ok or not tag then return nil, nil end
  return findModRecord(tag)
end

local function tryFind(dir, pattern, depth)
  if not FS then return {} end
  local ok, result = pcall(FS.findFiles, dir, pattern, depth or 0, true, false)
  if ok and type(result) == 'table' then return result end
  ok, result = pcall(FS.findFiles, FS, dir, pattern, depth or 0, true, false)
  if ok and type(result) == 'table' then return result end
  return {}
end

local function candidatePaths(kind, id)
  local out, seen = {}, {}
  local root = kind == 'vehicle' and '/vehicles/' or '/levels/'
  local folder = root .. id
  local fixed = kind == 'vehicle'
    and { folder .. '/info.json', folder .. '/default.jpg', folder .. '/default.png' }
    or { folder .. '/info.json', folder .. '/main.level.json', folder .. '/preview.png', folder .. '/preview.jpg' }
  for _, path in ipairs(fixed) do
    if not seen[path] then seen[path] = true; out[#out + 1] = path end
  end
  local patterns = kind == 'vehicle' and { '*.jbeam', '*.json' } or { '*.mis', '*.level.json', 'info.json' }
  for _, pattern in ipairs(patterns) do
    for _, path in ipairs(tryFind(folder .. '/', pattern, 2)) do
      if type(path) == 'string' and not seen[path] then seen[path] = true; out[#out + 1] = path end
    end
  end
  return out
end

local function findSource(kind, rawId)
  if kind ~= 'vehicle' and kind ~= 'level' then return nil, 'Lloji i zgjedhur nuk njihet.' end
  local id = cleanId(rawId)
  if not id then return nil, 'Nuk u lexua emri i veturës/hartës.' end
  if not core_modmanager then return nil, 'Mod Manager i lojës nuk është gati.' end

  local paths = candidatePaths(kind, id)
  for _, path in ipairs(paths) do
    local key, mod = ownerForPath(path)
    if key and mod then
      local fullpath = tostring(mod.fullpath or ''):gsub('\\', '/')
      if fullpath:lower():find('/mods/', 1, true) then
        local filename = fullpath:match('([^/]+)$') or fullpath
        return {
          key = tostring(key),
          name = tostring(mod.modData and (mod.modData.title or mod.modData.name) or mod.modname or key),
          filename = filename,
          fullpath = fullpath,
          active = mod.active ~= false,
          item = id,
          kind = kind,
        }
      end
    end
  end
  return nil, 'S’u gjet mod ZIP për këtë kartelë (mund të jetë veturë/hartë e lojës ose preview pa rrugë VFS).'
end

function M.getSourceInfo(kind, id)
  local info, err = findSource(kind, id)
  if not info then return jsonResult({ ok = false, error = err or 'Modi nuk u gjet.' }) end
  return jsonResult({ ok = true, info = info })
end

function M.deactivate(kind, id, expectedFilename)
  local info, err = findSource(kind, id)
  if not info then return jsonResult({ ok = false, error = err or 'Modi nuk u gjet.' }) end
  if expectedFilename and tostring(expectedFilename) ~= info.filename then
    return jsonResult({ ok = false, error = 'Modi ndryshoi prej kontrollit. Rifresko selector-in dhe provo prapë.' })
  end
  if not info.active then
    return jsonResult({ ok = false, error = 'Ky mod veç është i çaktivizuar.' })
  end
  if not core_modmanager.deactivateMod then
    return jsonResult({ ok = false, error = 'Loja nuk e ekspozon veprimin për çaktivizim.' })
  end
  local ok, result = pcall(core_modmanager.deactivateMod, info.key)
  if not ok or result == false then
    return jsonResult({ ok = false, error = 'BeamNG nuk arriti me e çaktivizu modin.' })
  end
  return jsonResult({ ok = true, filename = info.filename, name = info.name, item = info.item, kind = info.kind })
end

return M
