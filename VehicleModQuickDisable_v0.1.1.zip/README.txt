VEHICLE MOD QUICK DISABLE v0.1.1 — BeamNG.drive 0.39.4
======================================================

QËLLIMI
-------
Shton vetëm një buton “Çaktivizo modin” në panelin e detajeve në anën e djathtë, për veturën/hartën e zgjedhur. Nuk shton butona mbi kartelat dhe nuk ndryshon madhësinë, pozicionin ose pamjet e tyre. Para konfirmimit shfaqet emri i saktë i ZIP-it burimor.

E RËNDËSISHME
-------------
- Nuk e fshin ZIP-in. Pas çaktivizimit, mundesh me e fshi vetë te Mods Manager ose prej folderit Mods.
- Çaktivizohet i gjithë ZIP-i/modi, jo vetëm vetura ose harta e zgjedhur. Nëse arkiva ka disa artikuj, krejt preken; ky paralajmërim shfaqet para konfirmimit.
- Modet origjinale të BeamNG-së nuk çaktivizohen.
- Butoni shfaqet kur loja e paraqet artikullin e zgjedhur në panelin e detajeve dhe mod-i burimor mund të identifikohet.

INSTALIMI
---------
1. Mbylle BeamNG.drive.
2. Hiqe/çaktivizo build-in e vjetër VehicleModQuickDisable_v0.1.0.zip, që të mos ngarkohen dy versione.
3. Vendose VehicleModQuickDisable_v0.1.1.zip te folderi Mods i userfolder-it të BeamNG.drive. Mos e çzip-o.
4. Nise lojën, zgjidhe veturën ose hartën dhe kërko butonin në panelin e detajeve djathtas.
5. Kontrolloje emrin e ZIP-it në dritaren e konfirmimit para se me zgjedh “Çaktivizo modin”.

KTHIMI MBRAPA
-------------
Nëse e çaktivizon gabimisht, hape Mods Manager dhe aktivizoje përsëri. ZIP-i nuk fshihet nga ky mod.

STATUSI I TESTIMIT
------------------
Ky është përditësim pas feedback-ut për pamjen. U hoq plotësisht injektimi i butonave/CSS-së te kartelat; kodi tani synon veç panelin e detajeve në të djathtë. Kontrolli statik dhe integriteti i ZIP-it janë kryer, por ky sandbox nuk e nis BeamNG.drive. Prandaj, paraqitja dhe funksionimi në lojë mbesin të patestuara.
