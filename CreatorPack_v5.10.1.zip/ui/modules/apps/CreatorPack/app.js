
angular.module('beamng.apps')

.directive('pfFileRead', function() {
  return {
    restrict: 'A',
    scope: {
      pfFileRead: '=',
      pfOnRead: '&?'
    },
    link: function(scope, element) {
      element.on('change', function(evt) {
        var file = evt.target.files && evt.target.files[0];
        if (!file) return;

        var reader = new FileReader();
        reader.onload = function(e) {
          scope.$apply(function() {
            scope.pfFileRead = e.target.result;
            if (scope.pfOnRead) scope.pfOnRead();
          });
        };
        reader.readAsDataURL(file);
      });
    }
  };
})

.directive('creatorpackPanel', ['$document', '$window', '$timeout', '$rootScope', function($document, $window, $timeout, $rootScope) {
  return {
    replace: true,
    restrict: 'EA',
    templateUrl: '/ui/modules/apps/CreatorPack/app.html',
    link: function(scope, element) {
      var STORAGE_KEY = 'pfhud_config_v14_working_upload_clone';

      // =====================================================
      // v5.3.0 — Versioni shfaqet brenda HUD-it, që të shihet
      // menjëherë nëse BeamNG ka ngarkuar versionin e re.
      // =====================================================
      var MOD_VERSION = '5.10.1';
      scope.modVersion = MOD_VERSION;
      scope.storageKey = STORAGE_KEY;
      scope.toast = { show: false };
      var toastTimer = null;

      scope.fontOk = false;
      scope.fontCheckText = 'duke kontrolluar…';
      scope.fontFamilyText = 'duke kontrolluar…';

      function checkBangers() {
        try {
          var ok = false;
          if (window.document && window.document.fonts && window.document.fonts.check) {
            ok = window.document.fonts.check('16px "Bangers HUD"');
          }
          scope.fontOk = !!ok;
          scope.fontCheckText = ok ? 'document.fonts.check OK' : "fonti nuk u gjet në dokument";
        } catch (e) {
          scope.fontCheckText = 'kontrolli dështoi: ' + e.message;
        }
        try {
          if (scope.cfg.survivalFontFamily === 'user' && scope.cfg.survivalUserFontData) {
            var okUser = false;
            try { okUser = window.document.fonts.check('16px "HUD User Font"'); } catch (e3) {}
            scope.fontOk = okUser;
            scope.fontCheckText = okUser
              ? ('fonti yt: ' + (scope.cfg.survivalUserFontName || 'i ngarkuar') + ' ✓')
              : ('fonti yt nuk u aktivizua: ' + (scope.cfg.survivalUserFontName || '—'));
          }
        } catch (e4) {}
        try {
          var node = element && element[0] ? element[0].querySelector('.pf-survival') : null;
          scope.fontFamilyText = node && window.getComputedStyle
            ? String(window.getComputedStyle(node).fontFamily || '').split(',')[0]
            : 'pa element';
        } catch (e2) { scope.fontFamilyText = 'pa element'; }
      }
      scope.checkBangers = checkBangers;

      // =====================================================
      // v5.3.1 — FONTI YT: ngarko .ttf/.otf/.woff/.woff2
      // =====================================================
      scope.userFontMsg = '';
      var userFontStyleEl = null;

      function userFontStyle() {
        if (!userFontStyleEl) {
          try { userFontStyleEl = element && element[0] ? element[0].querySelector('#pfUserFontStyle') : null; }
          catch (e) { userFontStyleEl = null; }
        }
        return userFontStyleEl;
      }

      // Injekton @font-face me fontin e perdoruesit (base64 data URL).
      function applyUserFont(dataUrl) {
        var el = userFontStyle();
        if (!el) return false;
        try {
          el.textContent = dataUrl
            ? "@font-face{font-family:'HUD User Font';font-style:normal;font-weight:100 900;font-display:swap;src:url(" + dataUrl + ");}"
            : "";
          scope.survival.userFontLoaded = !!dataUrl;
          return true;
        } catch (e) {
          return false;
        }
      }
      scope.applyUserFont = applyUserFont;

      var USER_FONT_MAX = 1400000;   // ~1.4 MB

      scope.readUserFont = function(inputEl) {
        try {
          var file = inputEl && inputEl.files && inputEl.files[0];
          if (!file) return;
          if (file.size > USER_FONT_MAX) {
            scope.$applyAsync(function() {
              scope.userFontMsg = 'Fonti është shumë i madh (' + Math.round(file.size / 1024) +
                ' KB). Limiti ~1.4 MB — provo një .woff2 (ma i vogli).';
            });
            return;
          }
          if (!/\.(ttf|otf|woff2?|TTF|OTF|WOFF2?)$/.test(file.name || '')) {
            scope.$applyAsync(function() {
              scope.userFontMsg = 'Ky skedar nuk duket font. Zgjidh .ttf / .otf / .woff / .woff2';
            });
            return;
          }
          var reader = new FileReader();
          reader.onload = function(e) {
            scope.$applyAsync(function() {
              scope.cfg.survivalUserFontData = e.target.result;
              scope.cfg.survivalUserFontName = file.name;
              scope.cfg.survivalFontFamily = 'user';
              applyUserFont(e.target.result);
              try { inputEl.value = ''; } catch (x) {}
              scope.userFontMsg = 'U ngarkua: ' + file.name + ' ✓ (' + Math.round(file.size / 1024) + ' KB)';
              scope.persist();
              scope.$evalAsync(function() { checkBangers(); });
            });
          };
          reader.onerror = function() {
            scope.$applyAsync(function() { scope.userFontMsg = 'Nuk u lexua skedari. Provo përsëri.'; });
          };
          reader.readAsDataURL(file);
        } catch (e) {
          scope.userFontMsg = 'Gabim: ' + e.message;
        }
      };

      scope.clearUserFont = function() {
        scope.cfg.survivalUserFontData = '';
        scope.cfg.survivalUserFontName = '';
        if (scope.cfg.survivalFontFamily === 'user') scope.cfg.survivalFontFamily = 'bangers';
        applyUserFont('');
        scope.userFontMsg = 'Fonti i ngarkuar u hoq. U kthye Bangers.';
        scope.persist();
      };

      // Kjo e thërret input-i i file-it brenda template-it.
      try {
        window.pfhudReadFontFile = function(inputEl) {
          var fn = scope.readUserFont;
          if (fn) fn(inputEl);
        };
      } catch (e) {}
      scope.runDiagnostics = function() { checkBangers(); scope.persist(); };

      scope.showToast = function() {
        if (toastTimer) { try { $timeout.cancel(toastTimer); } catch (e) {} }
        scope.toast.show = false;
        $timeout(function() {
          scope.toast.show = true;
          toastTimer = $timeout(function() { scope.toast.show = false; }, 6000);
        }, 10);
      };

      function defaultItems(count) {
        var items = [];
        for (var i = 0; i < count; i++) {
          items.push({
            label: 'Makina ' + (i + 1),
            image: '',
            enabled: true,
            state: 'pending',
            imageScale: 1.0,
            imageOffsetX: 0,
            imageOffsetY: 0,
            imageRotation: 0,
            costMax: 10000,     // buxheti maksimal i riparimit per kete makine
            costNow: 0,         // legacy/internal cost value (not shown in HUD)
            damageRatio: 0,     // v4.1: 0..1 radial damage shown around the circle
            damagePulse: false,
            visited: i === 0,   // v4.2: hide damage UI until this slot is reached
            survivalChance: 100,
            costLocked: false   // freezes this vehicle result after PASS/FAIL
          });
        }
        return items;
      }

      function defaults() {
        return {
          showPanel: true,
          vehiclesOn: true,        // v5.1: false = fsheh rrumullakat e makinave, mbetet vetem Survival Chance
          vehiclesKey: 'v',        // v5.1: tasti UI per ON/OFF te rretheve
          positionX: 18,
          positionY: 18,
          panelX: 18,
          panelY: 112,
          itemSize: 112,
          gap: 14,
          imageScale: 1.0,
          showArrows: false,
          showMarks: true,
          markSize: 0.82,
          markPos: 'center',        // v5.10: ku del ✓/✕ — center | above | under
          markOffsetX: 0,           // v5.10: zhvendosja e shenjave (px)
          markOffsetY: 0,
          markSoundVolume: 0.85,    // v5.10: volumi i ka-ching / buzzer
          circleShape: 'circle',
          outlineWidth: 4,
          glow: 8,
          pendingFillOpacity: 0.16,
          pendingOutlineOpacity: 0.00,
          currentIndex: 0,
          soundOn: true,
          passKey: 'k',
          failKey: 'l',
          nextKey: 'PageDown',
          prevKey: 'PageUp',
          resetKey: 'g',
          togglePanelKey: 'h',
          useHotkeys: true,
          showMiniButton: true,
          fxPosX: 50,
          fxPosY: 24,
          fxScale: 1.0,
          hudDensity: 'normal',

          // ---- v4.3: SURVIVAL CHANCE ----
          survivalOn: true,
          survivalEditPosition: false,
          survivalPosX: 50,
          survivalPosY: 8,
          survivalSize: 54,
          survivalSensitivity: 1.0,
          survivalLabelText: 'SURVIVAL CHANCE',
          survivalLabelColor: '#ffffff',
          survivalValueColor: '#42ff68',
          survivalDeltaColor: '#ff8a32',
          survivalWarningColor: '#ff7a2f',
          survivalCriticalColor: '#ff334d',
          survivalColorProfileVersion: 2,
          survivalDynamicColor: true,
          survivalWarningThreshold: 55,
          survivalCriticalThreshold: 20,
          survivalLayout: 'inline',       // inline | stacked | compact
          survivalBackground: 'none',     // none | pill | card
          survivalBackgroundColor: '#071016',
          survivalBackgroundOpacity: 0.55,
          survivalShowLabel: true,
          survivalShowStatus: false,
          survivalStatusSize: 0.28,
          survivalStatusSpacing: 0.16,
          survivalStatusWeight: '900',
          survivalStatusPosition: 'bottom',
          survivalStatusPulse: true,
          survivalEmojiOn: true,
          survivalEmojiSafe: '😎',       // v5.2.1: emoji te editueshme per cdo nivel
          survivalEmojiCaution: '😬',
          survivalEmojiDanger: '😰',
          survivalEmojiCritical: '😵',
          survivalEmojiDead: '💀',
          survivalEmojiMode: 'right',    // SAFE + emoji inline
          survivalEmojiSize: 0.34,
          survivalEmojiPop: true,
          survivalEmojiProfileVersion: 3,
          survivalShowMeter: false,
          survivalShowPercent: true,
          survivalLabelScale: 1.0,         // v5.3.1: titulli i njejte madhësi me përqindjen
          survivalLabelSameAsValue: true,
          survivalUserFontData: '',        // v5.3.1: fonti qe ngarkon vetë perdoruesi (base64)
          survivalUserFontName: '',
          survivalDeltaStyle: 'subtle',    // v5.3.1: subtle | badge | off
          survivalFontFamily: 'bebas',  // v5.2.1: Bangers (i ngulitur) | narrow | impact | arialblack
          survivalFontWeight: '400',      // Bangers ka vetem 400 — pa false-bold
          survivalItalic: false,
          survivalOutline: 1,
          survivalGlow: 0,                 // v5.3.1: pa shkëlqim mbi tekst (ishte 10)
          survivalDecimals: 0,
          survivalShowDelta: true,
          survivalDeltaDuration: 850,
          survivalDeltaMin: 1,
          survivalDeltaPosition: 'right',
          survivalDeltaSize: 0.42,
          survivalDeltaGhosts: false,
          survivalRollingCounter: false,
          survivalRollDuration: 430,
          survivalSmoothTime: 340,
          survivalAnimationProfileVersion: 3,
          survivalImpactShake: false,
          survivalLowPulse: false,
          survivalDisplayMode: 'always',  // always | change | danger
          survivalAutoHideMs: 3000,
          survivalDangerShowAt: 55,
          survivalFormula: 'balanced',    // forgiving | balanced | hardcore | damageOnly
          survivalDamageWeight: 1.0,
          survivalImpactWeight: 1.0,
          survivalSpeedWeight: 1.0,
          survivalMinAlive: 1,

          // ---- v5.2: STATUSI DRAMATIK, 5 NGJYRA, FX & ZË ----
          survivalStatusPack: 'streamer',   // classic | dramatic | streamer | hardcore | custom
          survivalStatusTexts: { safe: "WE'RE GOOD", caution: 'GETTING SPICY', danger: "IT'S HEATING UP", critical: 'HANGING ON', dead: "WE'RE DONE" },
          survivalStatusRotate: true,       // rrotullo frazat brenda te njejtit nivel
          survivalRotateMs: 3000,
          survivalStatusBlend: true,        // true = ngjyrat kalojne bute, false = ndryshim i menjëhershem
          survivalCautionColor: '#ffd23f',
          survivalDeadColor: '#b3122b',
          survivalCautionThreshold: 80,
          survivalTextFx: 'none',           // none | neon | chrome | gold | blood | extrude | glitch | flicker
          survivalHeartbeat: true,          // HUD-i pulson si zemra, shpejtohet kur bie %
          survivalHeartbeatAmount: 55,
          survivalGlowPulse: true,          // v5.2.1: aureola dramatike rreth HUD-it (jo ekran i kuq)
          survivalGlowAmount: 20,
          survivalCriticalGlitch: true,     // glitch kur je ne kritik
          survivalSoundMode: 'both',        // off | heartbeat | alerts | both
          survivalSoundVolume: 0.25,     // v5.3.1: ma i bute
          survivalSoundBelow: 60,           // zeri fillon nen kete %
          streamMode: false,                // v5.2: fsheh panelin, rrumullakat dhe guidat me nje tast
          streamPrev: null,

          // ---- v2.1: GUIDAT PER SHORTS (9:16) ----
          guidesOn: false,         // shfaq kornizen e sigurt + vijat e mesit
          guideRatio: '9:16',      // 9:16 | 4:5 | 1:1 | 16:9
          guideCenterV: true,      // vija vertikale ne mes
          guideCenterH: true,      // vija horizontale ne mes
          guideThirds: false,      // rregulli i te tretave
          guideDim: 0.45,          // sa te erresohen anet jashte kornizes
          guideColor: '#00e5ff',

          // ---- v2.0 PREMIUM ----
          theme: 'luxury',         // default | glass | neon | minimal | luxury
          layout: 'row',           // row | grid | column
          gridCols: 4,
          autoAdvance: true,       // kalo automatikisht te itemi tjeter pas markimit
          // ---- v3.0: REPAIR COST (zevendeson statistikat) ----
          costOn: true,            // v4.1: enables live radial damage rings
          costAuto: true,          // vendose vete ne mes poshte rratheve
          costPosX: 50,            // perqindje, kur costAuto = false
          costPosY: 80,
          costGap: 40,             // hapesira nen rrathet kur costAuto = true
          costSize: 64,
          costLabel: true,
          costLabelText: 'REPAIR COST',
          costCurrency: '$',
          costColor: '#3dff88',
          costLabelColor: '#ffffff',
          costPulse: true,
          costDefaultMax: 30000,     // fallback kur nuk gjendet vlera e makines
          costAutoMax: true,           // tavani i kostos lidhet automatikisht me vleren e makines
          costVehicleFactor: 0.90,     // max repair ~= 90% e vleres se makines
          costFollowMark: true,      // kalo mbi rrethin e markuar kur shtyp PASS/FAIL
          costFollowMs: 2500,        // sa te rrije aty
          costPerCircle: false,      // v4.1: monetary values removed from HUD
          costBigOn: false,          // v3.1.4: shiriti i madh mbi rrathe - FIKUR
          costSens: 1.0,             // ndjeshmeria e demit
          costStick: true,           // v3.1.2: kostoja MBETET mbi rrethin e markuar
          costCircleColor: '#3dff88',   // ngjyra e kostos per-rreth
          costColorByState: false,      // ngjyros sipas PASS/FAIL
          costPassColor: '#3dff88',
          costFailColor: '#ff5b5b',
          costStyleClass: 'pf-cost-card',
          costFontWeight: '900',
          costCurve: 1.55,
          costMinDamage: 0.01,
          costShowBar: true,
          costCompactText: false,
          costGlow: true,
          animLevel: 'full',       // full | subtle | off
          showLabels: false,       // emrat nen fotot
          labelSize: 13,
          presets: [],             // presets te ruajtura
          photoArchive: {},        // v5.10.1: arkiva e fotove (fotot nuk humbin kurrë)
          photoMaxPx: 320,         // v5.10.1: madhesia max e fotos se rruatjtur (px)
          items: defaultItems(8)
        };
      }

      function normalizeConfig(saved, fallback) {
        var cfg = angular.extend({}, fallback, saved || {});
        if (!cfg.items || !cfg.items.length) cfg.items = defaultItems(8);

        // force cleaner defaults from v4 while keeping user items/images if saved
        if (!cfg.photoArchive || typeof cfg.photoArchive !== 'object') cfg.photoArchive = {};
        if (!cfg.photoMaxPx || isNaN(Number(cfg.photoMaxPx))) cfg.photoMaxPx = 320;
        if (cfg.pendingFillOpacity === undefined || cfg.pendingFillOpacity === null) cfg.pendingFillOpacity = 0.18;
        // v5.1: ON/OFF per rrumullakat e makinave (false = vetem Survival Chance)
        if (cfg.vehiclesOn === undefined || cfg.vehiclesOn === null) cfg.vehiclesOn = true;
        if (!cfg.vehiclesKey) cfg.vehiclesKey = 'v';
        if (cfg.pendingOutlineOpacity === undefined || cfg.pendingOutlineOpacity === null) cfg.pendingOutlineOpacity = 0.08;
        if (cfg.showMiniButton === undefined || cfg.showMiniButton === null) cfg.showMiniButton = true;
        if (cfg.showMarks === undefined || cfg.showMarks === null) cfg.showMarks = true;
        if (cfg.markSize === undefined || cfg.markSize === null) cfg.markSize = 0.82;
        if (cfg.markPos !== 'center' && cfg.markPos !== 'above' && cfg.markPos !== 'under') cfg.markPos = 'center';
        if (cfg.markOffsetX === undefined || cfg.markOffsetX === null) cfg.markOffsetX = 0;
        if (cfg.markOffsetY === undefined || cfg.markOffsetY === null) cfg.markOffsetY = 0;
        if (cfg.markSoundVolume === undefined || cfg.markSoundVolume === null) cfg.markSoundVolume = 0.85;
        if (cfg.useHotkeys === undefined || cfg.useHotkeys === null) cfg.useHotkeys = true;
        if (cfg.panelX === undefined || cfg.panelX === null) cfg.panelX = 18;
        if (cfg.panelY === undefined || cfg.panelY === null) cfg.panelY = 112;
        if (cfg.fxPosX === undefined || cfg.fxPosX === null) cfg.fxPosX = 50;
        if (cfg.fxPosY === undefined || cfg.fxPosY === null) cfg.fxPosY = 24;
        if (cfg.fxScale === undefined || cfg.fxScale === null) cfg.fxScale = 1.0;

        // ---- v2.0 PREMIUM defaults (ruan konfigurimet e vjetra) ----
        if (!cfg.theme) cfg.theme = 'default';
        if (!cfg.layout) cfg.layout = 'row';
        if (cfg.gridCols === undefined || cfg.gridCols === null) cfg.gridCols = 4;
        if (cfg.autoAdvance === undefined || cfg.autoAdvance === null) cfg.autoAdvance = true;
        // v3.0: repair cost
        if (cfg.costOn === undefined || cfg.costOn === null) cfg.costOn = false;
        if (cfg.costAuto === undefined || cfg.costAuto === null) cfg.costAuto = true;
        if (cfg.costPosX === undefined || cfg.costPosX === null) cfg.costPosX = 50;
        if (cfg.costPosY === undefined || cfg.costPosY === null) cfg.costPosY = 80;
        if (cfg.costGap === undefined || cfg.costGap === null) cfg.costGap = 40;
        if (cfg.costSize === undefined || cfg.costSize === null) cfg.costSize = 64;
        if (cfg.costLabel === undefined || cfg.costLabel === null) cfg.costLabel = true;
        if (!cfg.costLabelText) cfg.costLabelText = 'REPAIR COST';
        if (!cfg.costCurrency) cfg.costCurrency = '$';
        if (!cfg.costColor) cfg.costColor = '#3dff88';
        if (!cfg.costLabelColor) cfg.costLabelColor = '#ffffff';
        if (cfg.costPulse === undefined || cfg.costPulse === null) cfg.costPulse = true;
        if (cfg.costDefaultMax === undefined || cfg.costDefaultMax === null) cfg.costDefaultMax = 30000;
        if (cfg.costAutoMax === undefined || cfg.costAutoMax === null) cfg.costAutoMax = true;
        if (cfg.costVehicleFactor === undefined || cfg.costVehicleFactor === null) cfg.costVehicleFactor = 0.90;
        if (cfg.costFollowMark === undefined || cfg.costFollowMark === null) cfg.costFollowMark = true;
        if (cfg.costFollowMs === undefined || cfg.costFollowMs === null) cfg.costFollowMs = 2500;
        if (cfg.costPerCircle === undefined || cfg.costPerCircle === null) cfg.costPerCircle = true;
        if (cfg.costBigOn === undefined || cfg.costBigOn === null) cfg.costBigOn = false;
        if (cfg.costSens === undefined || cfg.costSens === null) cfg.costSens = 1.0;
        if (cfg.costStick === undefined || cfg.costStick === null) cfg.costStick = true;
        if (!cfg.costCircleColor) cfg.costCircleColor = cfg.costColor || '#3dff88';
        if (cfg.costColorByState === undefined || cfg.costColorByState === null) cfg.costColorByState = false;
        if (!cfg.costPassColor) cfg.costPassColor = '#3dff88';
        if (!cfg.costFailColor) cfg.costFailColor = '#ff5b5b';
        if (!cfg.hudDensity) cfg.hudDensity = 'normal';
        if (cfg.theme === 'default') cfg.theme = 'luxury';
        if (!cfg.costStyleClass) cfg.costStyleClass = 'pf-cost-card';
        if (!cfg.costFontWeight) cfg.costFontWeight = '900';
        if (cfg.costCurve === undefined || cfg.costCurve === null) cfg.costCurve = 1.55;
        if (cfg.costMinDamage === undefined || cfg.costMinDamage === null) cfg.costMinDamage = 0.01;
        if (cfg.costShowBar === undefined || cfg.costShowBar === null) cfg.costShowBar = true;
        if (cfg.costCompactText === undefined || cfg.costCompactText === null) cfg.costCompactText = false;
        if (cfg.costGlow === undefined || cfg.costGlow === null) cfg.costGlow = true;

        // v4.1 migration: the old money line/readouts are replaced by damage rings.
        // Keep the cost engine internally because it already provides a stable 0..1 damage ratio.
        cfg.costOn = true;
        cfg.costBigOn = false;
        cfg.costPerCircle = false;

        // pastro celesat e vjeter te statistikave
        ['showStats','statsAuto','statsPosX','statsPosY','showStreak',
         'showPercent','showProgressBar','countUp'].forEach(function(k){ delete cfg[k]; });
        if (!cfg.animLevel) cfg.animLevel = 'full';
        if (cfg.showLabels === undefined || cfg.showLabels === null) cfg.showLabels = false;
        if (cfg.labelSize === undefined || cfg.labelSize === null) cfg.labelSize = 13;
        if (!angular.isArray(cfg.presets)) cfg.presets = [];

        // ---- v4.3 survival defaults ----
        if (cfg.survivalOn === undefined || cfg.survivalOn === null) cfg.survivalOn = true;
        if (cfg.survivalEditPosition === undefined || cfg.survivalEditPosition === null) cfg.survivalEditPosition = false;
        if (cfg.survivalPosX === undefined || cfg.survivalPosX === null) cfg.survivalPosX = 50;
        if (cfg.survivalPosY === undefined || cfg.survivalPosY === null) cfg.survivalPosY = 8;
        if (cfg.survivalSize === undefined || cfg.survivalSize === null) cfg.survivalSize = 54;
        if (cfg.survivalSensitivity === undefined || cfg.survivalSensitivity === null) cfg.survivalSensitivity = 1.0;
        if (!cfg.survivalLabelText) cfg.survivalLabelText = 'SURVIVAL CHANCE';
        if (!cfg.survivalLabelColor) cfg.survivalLabelColor = '#ffffff';
        if (!cfg.survivalValueColor) cfg.survivalValueColor = '#ffad32';
        if (!cfg.survivalDeltaColor) cfg.survivalDeltaColor = '#ff8a32';
        if (cfg.survivalDynamicColor === undefined || cfg.survivalDynamicColor === null) cfg.survivalDynamicColor = true;
        if (!cfg.survivalWarningColor) cfg.survivalWarningColor = '#ff7a2f';
        if (!cfg.survivalCriticalColor) cfg.survivalCriticalColor = '#ff334d';
        // v4.6: migrate the old dull orange normal colour, including saved configs.
        if (Number(cfg.survivalColorProfileVersion || 0) < 2) {
          cfg.survivalValueColor = '#42ff68';
          cfg.survivalWarningColor = '#ff7a2f';
          cfg.survivalCriticalColor = '#ff334d';
          cfg.survivalColorProfileVersion = 2;
        }
        if (cfg.survivalWarningThreshold == null) cfg.survivalWarningThreshold = 55;
        if (cfg.survivalCriticalThreshold == null) cfg.survivalCriticalThreshold = 20;
        if (!cfg.survivalLayout) cfg.survivalLayout = 'inline';
        if (!cfg.survivalBackground) cfg.survivalBackground = 'none';
        if (!cfg.survivalBackgroundColor) cfg.survivalBackgroundColor = '#071016';
        if (cfg.survivalBackgroundOpacity == null) cfg.survivalBackgroundOpacity = 0.55;
        if (cfg.survivalShowLabel == null) cfg.survivalShowLabel = true;
        if (cfg.survivalShowStatus == null) cfg.survivalShowStatus = false;
        if (cfg.survivalStatusSize == null) cfg.survivalStatusSize = 0.28;
        if (cfg.survivalStatusSpacing == null) cfg.survivalStatusSpacing = 0.16;
        if (!cfg.survivalStatusWeight) cfg.survivalStatusWeight = '900';
        if (!cfg.survivalStatusPosition) cfg.survivalStatusPosition = 'bottom';
        if (cfg.survivalStatusPulse == null) cfg.survivalStatusPulse = true;
        if (cfg.survivalEmojiOn == null) cfg.survivalEmojiOn = true;
        if (!cfg.survivalEmojiMode || cfg.survivalEmojiMode === 'replace') cfg.survivalEmojiMode = 'right';
        if (cfg.survivalEmojiSize == null) cfg.survivalEmojiSize = 0.62;
        if (cfg.survivalEmojiPop == null) cfg.survivalEmojiPop = true;
        // v5.0: inspect the ACTUAL saved object (not merged defaults), otherwise
        // old Replace-mode configs inherit the new version number and skip migration.
        var savedEmojiVersion = saved ? Number(saved.survivalEmojiProfileVersion || 0) : 0;
        if (savedEmojiVersion < 3) {
          cfg.survivalEmojiOn = true;
          cfg.survivalShowStatus = true;
          cfg.survivalEmojiMode = 'right';
          cfg.survivalEmojiSize = 0.34;
          cfg.survivalEmojiPop = true;
          cfg.survivalEmojiProfileVersion = 3;
        }
        if (cfg.survivalShowMeter == null) cfg.survivalShowMeter = false;
        if (cfg.survivalShowPercent == null) cfg.survivalShowPercent = true;
        if (cfg.survivalLabelScale == null) cfg.survivalLabelScale = 1.0;
        if (cfg.survivalUserFontData == null) cfg.survivalUserFontData = '';
        if (cfg.survivalUserFontName == null) cfg.survivalUserFontName = '';
        if (!cfg.survivalDeltaStyle) cfg.survivalDeltaStyle = 'subtle';
        if (!cfg.survivalFontFamily) cfg.survivalFontFamily = 'futura';   // v5.1: Futura Extra Bold by default
        if (!cfg.survivalFontWeight) cfg.survivalFontWeight = '900';
        if (cfg.survivalItalic == null) cfg.survivalItalic = true;
        if (cfg.survivalOutline == null) cfg.survivalOutline = 1;
        if (cfg.survivalGlow == null) cfg.survivalGlow = 0;
        if (cfg.survivalDecimals == null) cfg.survivalDecimals = 0;
        if (cfg.survivalShowDelta == null) cfg.survivalShowDelta = true;
        if (cfg.survivalDeltaDuration == null) cfg.survivalDeltaDuration = 850;
        if (cfg.survivalDeltaMin == null) cfg.survivalDeltaMin = 1;
        if (!cfg.survivalDeltaPosition) cfg.survivalDeltaPosition = 'right';
        if (cfg.survivalDeltaSize == null) cfg.survivalDeltaSize = 0.42;
        if (cfg.survivalDeltaGhosts == null) cfg.survivalDeltaGhosts = true;
        if (cfg.survivalRollingCounter == null) cfg.survivalRollingCounter = false;
        if (cfg.survivalRollDuration == null) cfg.survivalRollDuration = 430;
        if (cfg.survivalSmoothTime == null) cfg.survivalSmoothTime = 340;
        if (cfg.survivalImpactShake == null) cfg.survivalImpactShake = false;
        if (cfg.survivalLowPulse == null) cfg.survivalLowPulse = false;
        // v4.7 performance migration: replace overlapping heavy effects with Smooth Pop.
        if (Number(cfg.survivalAnimationProfileVersion || 0) < 3) {
          cfg.survivalRollingCounter = false;
          cfg.survivalDeltaGhosts = false;
          cfg.survivalImpactShake = false;
          cfg.survivalLowPulse = false;
          cfg.survivalDeltaDuration = 900;
          cfg.survivalSmoothTime = 340;
          cfg.survivalAnimationProfileVersion = 3;
        }
        if (!cfg.survivalDisplayMode) cfg.survivalDisplayMode = 'always';
        if (cfg.survivalAutoHideMs == null) cfg.survivalAutoHideMs = 3000;
        if (cfg.survivalDangerShowAt == null) cfg.survivalDangerShowAt = 55;
        if (!cfg.survivalFormula) cfg.survivalFormula = 'balanced';
        if (cfg.survivalDamageWeight == null) cfg.survivalDamageWeight = 1.0;
        if (cfg.survivalImpactWeight == null) cfg.survivalImpactWeight = 1.0;
        if (cfg.survivalSpeedWeight == null) cfg.survivalSpeedWeight = 1.0;
        if (cfg.survivalMinAlive == null) cfg.survivalMinAlive = 1;

        // ---- v5.2 migration: statusi dramatik, 5 ngjyra, FX, ze, stream ----
        if (!cfg.survivalStatusPack) cfg.survivalStatusPack = 'streamer';
        var DEF_TEXTS = { safe: "WE'RE GOOD", caution: 'GETTING SPICY', danger: "IT'S HEATING UP", critical: 'HANGING ON', dead: "WE'RE DONE" };
        // v5.3.2: fjalët që s'pëlqyen nuk kthehen ma kurrë (edhe në tekstin Custom)
        // v5.4: vetëm fjalët e vjetra të mërzitshme zëvendësohen (COOKED/GG/SKILL ISSUE lejohen prap)
        var OLD_WORDS = /^(END OF THE ROAD|THAT'S IT|RUN OVER|BACK TO THE GARAGE|STEADY|TENSE|IN PERIL|LAST BREATH)$/;
        var savedStatusVersion = saved ? Number(saved.survivalStatusProfileVersion || 0) : 0;
        var savedFontVersion = saved ? Number(saved.survivalFontProfileVersion || 0) : 0;
        if (!cfg.survivalStatusTexts || typeof cfg.survivalStatusTexts !== 'object') cfg.survivalStatusTexts = angular.extend({}, DEF_TEXTS);
        ['safe','caution','danger','critical','dead'].forEach(function(k) {
          if (!cfg.survivalStatusTexts[k]) cfg.survivalStatusTexts[k] = DEF_TEXTS[k];
        });
        if (cfg.survivalStatusRotate == null) cfg.survivalStatusRotate = true;
        if (cfg.survivalRotateMs == null) cfg.survivalRotateMs = 3000;
        if (cfg.survivalStatusBlend == null) cfg.survivalStatusBlend = true;
        if (!cfg.survivalCautionColor) cfg.survivalCautionColor = '#ffd23f';
        if (!cfg.survivalDeadColor) cfg.survivalDeadColor = '#b3122b';
        if (cfg.survivalCautionThreshold == null) cfg.survivalCautionThreshold = 80;
        // v5.1 ruante vetem 3 ngjyra: safe/warning/critical. Ruaj ato si parazgjedhje te reja.
        if (savedStatusVersion < 1) {
          cfg.survivalCautionColor = cfg.survivalCautionColor || '#ffd23f';
          cfg.survivalDeadColor = cfg.survivalDeadColor || '#b3122b';
          cfg.survivalStatusProfileVersion = 1;
        }
        if (!cfg.survivalTextFx) cfg.survivalTextFx = 'none';
        if (cfg.survivalHeartbeat == null) cfg.survivalHeartbeat = true;
        if (cfg.survivalHeartbeatAmount == null) cfg.survivalHeartbeatAmount = 55;
        if (cfg.survivalGlowPulse == null) cfg.survivalGlowPulse = true;
        if (cfg.survivalGlowAmount == null) cfg.survivalGlowAmount = 20;
        // ---- v5.6: meme SFX ----
        if (cfg.memeSfxOn == null) cfg.memeSfxOn = true;
        if (cfg.memeSfxVolume == null) cfg.memeSfxVolume = 0.7;
        // ---- v5.5: emoji në çdo frazë (3D), Emoji Mood i vjetër fiket që mos me dal dy herë ----
        if (cfg.survivalEmoji3d == null) cfg.survivalEmoji3d = true;
        if (cfg.survivalPhraseEmoji == null) cfg.survivalPhraseEmoji = true;
        if (!(saved && saved.survivalV550)) { cfg.survivalEmojiOn = false; cfg.survivalV550 = 1; }
        // ---- v5.4: paketat e vjetra classic/hardcore -> Clean / Minimal; teksti Custom merr fushat e reja ----
        if (cfg.survivalStatusPack === 'classic' || cfg.survivalStatusPack === 'hardcore') cfg.survivalStatusPack = 'minimal';
        if (cfg.survivalStatusTexts && typeof cfg.survivalStatusTexts === 'object') {
          if (!cfg.survivalStatusTexts.severe) cfg.survivalStatusTexts.severe = cfg.survivalStatusTexts.critical || 'HANG ON!';
          if (!cfg.survivalStatusTexts.extreme) cfg.survivalStatusTexts.extreme = 'LAST CHANCE';
        }
        // ---- v5.3.3: paketa Streamer e re si default, ndërrim çdo 3s, glow i kuq ma i butë ----
        var savedV533 = saved ? Number(saved.survivalV533 || 0) : 0;
        if (savedV533 < 1) {
          if (cfg.survivalStatusPack !== 'custom') cfg.survivalStatusPack = 'streamer';
          cfg.survivalStatusRotate = true;
          cfg.survivalRotateMs = 3000;
          cfg.survivalGlowAmount = Math.min(Number(cfg.survivalGlowAmount) || 20, 20);
          cfg.survivalV533 = 1;
        }
        // ---- v5.3.2: flash i kuq + vula “TOTALED” u hoqën KREJT ----
        delete cfg.survivalRedFlash;
        delete cfg.survivalVerdictOn;
        delete cfg.survivalVerdictText;
        delete cfg.survivalVerdictMs;
        if (cfg.survivalStatusTexts) {
          ['safe','caution','danger','critical','dead'].forEach(function(k) {
            var v = cfg.survivalStatusTexts[k];
            if (typeof v === 'string' && OLD_WORDS.test(v.trim().toUpperCase())) cfg.survivalStatusTexts[k] = DEF_TEXTS[k];
          });
        }
        if (cfg.survivalCriticalGlitch == null) cfg.survivalCriticalGlitch = true;
        if (!cfg.survivalSoundMode) cfg.survivalSoundMode = 'both';
        if (cfg.survivalSoundVolume == null) cfg.survivalSoundVolume = 0.35;
        if (cfg.survivalSoundBelow == null) cfg.survivalSoundBelow = 60;
        if (cfg.streamMode == null) cfg.streamMode = false;

        // v5.1: Survival Chance duket ma dramatic si parazgjedhje
        if (savedStatusVersion < 1) {
          cfg.survivalImpactShake = true;
          cfg.survivalLowPulse = true;
          cfg.survivalShowStatus = true;
        }

        // ---- v5.3.1: pa glow, titull nje madhësi me %, -% discret ----
        if (savedFontVersion < 2) {
          cfg.survivalGlow = 0;
          cfg.survivalLabelScale = 1.0;
          cfg.survivalDeltaStyle = 'subtle';
          cfg.survivalGlowAmount = Math.min(Number(cfg.survivalGlowAmount) || 40, 40);
          cfg.survivalSoundVolume = Math.min(Number(cfg.survivalSoundVolume) || 0.25, 0.25);
          cfg.survivalFontProfileVersion = 2;
        }

        // ---- v5.2.1: Bangers per te gjitha pjeset, pa bold/italic te rreme ----
        if (cfg.survivalFontFamily === 'futura') cfg.survivalFontFamily = 'bangers';
        if (savedFontVersion < 1) {
          cfg.survivalFontFamily = 'bangers';
          cfg.survivalFontWeight = '400';
          cfg.survivalItalic = false;
          cfg.survivalFontProfileVersion = 1;
        }
        // ---- v5.7.0: fonti CLEAN (Bebas Neue) si parazgjedhje ----
        if (savedFontVersion < 3) {
          cfg.survivalFontFamily = 'bebas';
          cfg.survivalFontWeight = '400';
          cfg.survivalItalic = false;
          cfg.survivalGlow = 0;
          cfg.survivalTextFx = 'none';
        }
        cfg.survivalFontProfileVersion = Math.max(3, Number(cfg.survivalFontProfileVersion) || 0);
        if (cfg.circlesClean == null) cfg.circlesClean = true;   // v5.9.1
        if (cfg.autoPhotoOnSwitch == null) cfg.autoPhotoOnSwitch = false;
        if (cfg.autoPhotoNext == null) cfg.autoPhotoNext = false;
        if (cfg.autoPhotoTolerance == null) cfg.autoPhotoTolerance = 32;   // v5.9.5: pak ma agresive
        // v5.9.9: vlerat e larta (45+) e hanin makinat e ndritshme -> kthejme ne 32
        if (Number(cfg.autoPhotoTolerance) > 40) cfg.autoPhotoTolerance = 32;
        if (cfg.liveOn == null) cfg.liveOn = true;          // v5.9.6: Ctrl+1 = foto LIVE nga loja
        // v5.9.9: Ctrl+1 = foto LIVE; nese kapja/prerja deshton, UI-ja e ven VET foton
        // e modit (pa screenshot). Ctrl+2 = foto e modit direkt. (pa shenje = LIVE)
        if (cfg.liveFlip == null) cfg.liveFlip = false;     // nese kapja del vertikalisht e kthyer
        if (cfg.liveView == null) cfg.liveView = 'auto';    // v5.9.7: 'auto' (3/4 mbrapa) ose 'front' (3/4 perpara)
        if (cfg.survivalLabelGap == null) cfg.survivalLabelGap = 0.12;   // v5.8.0: titulli afer %
        if (!cfg.survivalEmojiSafe) cfg.survivalEmojiSafe = '😎';
        if (!cfg.survivalEmojiCaution) cfg.survivalEmojiCaution = '😬';
        if (!cfg.survivalEmojiDanger) cfg.survivalEmojiDanger = '😰';
        if (!cfg.survivalEmojiCritical) cfg.survivalEmojiCritical = '😵';
        if (!cfg.survivalEmojiDead) cfg.survivalEmojiDead = '💀';

        // ---- v2.1 guides ----
        if (cfg.guidesOn === undefined || cfg.guidesOn === null) cfg.guidesOn = false;
        if (!cfg.guideRatio) cfg.guideRatio = '9:16';
        if (cfg.guideCenterV === undefined || cfg.guideCenterV === null) cfg.guideCenterV = true;
        if (cfg.guideCenterH === undefined || cfg.guideCenterH === null) cfg.guideCenterH = true;
        if (cfg.guideThirds === undefined || cfg.guideThirds === null) cfg.guideThirds = false;
        if (cfg.guideDim === undefined || cfg.guideDim === null) cfg.guideDim = 0.45;
        if (!cfg.guideColor) cfg.guideColor = '#00e5ff';
        cfg.passKey = 'k';
        cfg.failKey = 'l';
        cfg.nextKey = 'PageDown';
        cfg.prevKey = 'PageUp';
        cfg.resetKey = 'g';
        cfg.togglePanelKey = 'h';
        if (!cfg.streamKey) cfg.streamKey = 'b';

        angular.forEach(cfg.items, function(item, idx) {
          if (item.enabled === undefined) item.enabled = true;
          if (!item.label) item.label = 'Makina ' + (idx + 1);
          if (!item.state) item.state = 'pending';
          if (!item.image) {                       // v5.10.1: riktheje foton nga arkiva
            var ark = cfg.photoArchive['s' + idx];
            if (!ark && item.imageModel) ark = cfg.photoArchive['m:' + item.imageModel];
            if (ark) item.image = ark;
          }
          if (item.imageScale === undefined || item.imageScale === null) item.imageScale = cfg.imageScale || 1.0;
          if (item.imageOffsetX === undefined || item.imageOffsetX === null) item.imageOffsetX = 0;
          if (item.imageOffsetY === undefined || item.imageOffsetY === null) item.imageOffsetY = 0;
          if (item.imageRotation === undefined || item.imageRotation === null) item.imageRotation = 0;
          if (item.costMax === undefined || item.costMax === null) item.costMax = Number(cfg.costDefaultMax) || 10000;
          if (item.costNow === undefined || item.costNow === null) item.costNow = 0;
          if (item.damageRatio === undefined || item.damageRatio === null) item.damageRatio = 0;
          item.damageRatio = Math.max(0, Math.min(1, Number(item.damageRatio) || 0));
          item.damagePulse = false;
          if (item.visited === undefined || item.visited === null) {
            item.visited = idx === Number(cfg.currentIndex || 0) || item.damageRatio > 0 || item.state !== 'pending';
          }
          if (item.survivalChance === undefined || item.survivalChance === null) {
            item.survivalChance = item.damageRatio >= 0.995 ? 0 : Math.max(1, Math.round(100 * (1 - Math.pow(item.damageRatio, 0.82))));
          }
          item.survivalChance = Math.max(0, Math.min(100, Number(item.survivalChance) || 0));
          if (item.costLocked === undefined || item.costLocked === null) item.costLocked = false;
        });

        return cfg;
      }

      function load() {
        var d = defaults();
        try {
          var raw = localStorage.getItem(STORAGE_KEY);
          if (!raw) return d;
          return normalizeConfig(JSON.parse(raw), d);
        } catch (e) {
          return d;
        }
      }

      scope.cfg = load();
      scope.selected = Math.max(0, Math.min(scope.cfg.currentIndex || 0, scope.cfg.items.length - 1));
      if (scope.cfg.items[scope.selected]) scope.cfg.items[scope.selected].visited = true;
      scope.storageWarning = '';

      scope.rootClass = function() {
        return 'pf-theme-' + (scope.cfg.theme || 'default') +
               (scope.liveHide ? ' pf-live-hide' : '') +
               ' pf-anim-' + (scope.cfg.animLevel || 'full') +
               ' pf-layout-' + (scope.cfg.layout || 'row') +
               ' pf-density-' + (scope.cfg.hudDensity || 'normal') +
               (scope.cfg.costOn ? ' pf-damage-mode' : '');
      };

      scope.labelStyle = function() {
        return { fontSize: (Number(scope.cfg.labelSize) || 13) + 'px' };
      };
      scope.fx = { show: false, type: null };
      var fxTimer = null;


      scope.fileInputs = {};
      scope.registerFileInput = function(index, el) {
        scope.fileInputs[index] = el;
      };
      scope.openFilePicker = function(index) {
        var el = scope.fileInputs[index];
        if (el && el.click) el.click();
      };
      scope.readItemImage = function(index, inputEl) {
        try {
          var file = inputEl.files && inputEl.files[0];
          if (!file) return;
          var reader = new FileReader();
          reader.onload = function(e) {
            scope.$applyAsync(function() {
              if (scope.cfg.items[index]) {
                scope.cfg.items[index].image = e.target.result;
                scope.persist();
              }
            });
          };
          reader.readAsDataURL(file);
        } catch (err) {}
      };

      window.pfhudReadImage = function(index, inputEl) {
        try {
          var file = inputEl.files && inputEl.files[0];
          if (!file) return;

          var reader = new FileReader();
          reader.onload = function(e) {
            try {
              var sc = angular.element(inputEl).scope();
              sc.$applyAsync(function() {
                sc.cfg.items[Number(index)].image = e.target.result;
                sc.persist();
              });
            } catch (err) {}
          };
          reader.readAsDataURL(file);
        } catch (e) {}
      };


      scope.setShape = function(shape) {
        scope.cfg.circleShape = shape;
        scope.persist();
      };

      scope.moveHud = function(dx, dy) {
        scope.cfg.positionX = Number(scope.cfg.positionX || 0) + dx;
        scope.cfg.positionY = Number(scope.cfg.positionY || 0) + dy;
        scope.persist();
      };

      scope.resizeHud = function(delta) {
        scope.cfg.itemSize = Math.max(40, Math.min(220, Number(scope.cfg.itemSize || 112) + delta));
        scope.persist();
      };

      scope.adjustGap = function(delta) {
        scope.cfg.gap = Math.max(0, Math.min(60, Number(scope.cfg.gap || 14) + delta));
        scope.persist();
      };


      function stripRaw(obj) {
        var out = {}, k;
        for (k in obj) {
          if (obj.hasOwnProperty(k) && k.indexOf('__raw') === -1) out[k] = obj[k];
        }
        return out;
      }

      // v5.10.1: fotot ruhen VETEM ne arkive (cfg.photoArchive) — kshtu nuk dublikohen
      // dhe rrathët i marrin prapë automatikisht kur hapet modi.
      var autoCompressing = false;      // v5.10.1: roje kunder ciklit te kompresimit
      function configForSave(withImages) {
        var out = stripRaw(scope.cfg);
        if (!out.photoArchive || typeof out.photoArchive !== 'object') out.photoArchive = {};
        out.items = (scope.cfg.items || []).map(function(it, i) {
          var c = {}; for (var k in it) if (it.hasOwnProperty(k)) c[k] = it[k];
          // v5.10.1: arkiva mbushet vetë nga fotot që janë në rrathë (s'humbe kurrë gja)
          if (it && it.image) {
            out.photoArchive['s' + i] = it.image;
            if (it.imageModel) out.photoArchive['m:' + it.imageModel] = it.image;
          }
          if (!withImages) c.image = '';
          return c;
        });
        return out;
      }
      scope.photoCount = function() {
        var n = 0;
        angular.forEach(scope.cfg.items, function(it) { if (it && it.image) n++; });
        return n;
      };
      scope.storageKB = function() {
        try { return Math.round(JSON.stringify(configForSave(false)).length / 1024); } catch (e) { return 0; }
      };

      scope.persist = function() {
        scope.cfg.currentIndex = scope.selected;
        try {
          localStorage.setItem(STORAGE_KEY, JSON.stringify(configForSave(false)));
          scope.storageWarning = '';
        } catch (e) {
          // Fotot ruhen si base64 -> mund ta kalojne kuoten ~5MB.
          // Provo edhe njehere pa presets, qe te pakten HUD-i te mos humbase.
          try {
            var slim = configForSave(false);
            slim.presets = [];
            localStorage.setItem(STORAGE_KEY, JSON.stringify(slim));
            scope.storageWarning = 'Memoria u mbush - presets nuk u ruajten. Shtyp "🗜️ Kompreso fotot".';
          } catch (e2) {
            // v5.10.1: provo vetë kompresimin, pastaj rua prapë — fotot mos humbin.
            // autoCompressing = roje kundër ciklit (mos ringarko pa fund).
            if (autoCompressing) {
              scope.storageWarning = 'Memoria eshte krejt plot! Fshij disa foto ose rrathë me "🗑️ Fshi fotot".';
            } else {
              autoCompressing = true;
              scope.storageWarning = 'Memoria u mbush! Po i kompresoj fotot vetë…';
              scope.$evalAsync(function() {
                scope.compressPhotos(220, function() {
                  try {
                    localStorage.setItem(STORAGE_KEY, JSON.stringify(configForSave(false)));
                    scope.storageWarning = 'Memoria u mbush — fotot u kompresuan vetë (nuk u humb asnji).';
                  } catch (e3) {
                    scope.storageWarning = 'Memoria eshte krejt plot! Fshij disa foto ose rrathë me "🗑️ Fshi fotot".';
                  }
                  autoCompressing = false;      // v5.10.1: roja hiqet vetem në fund
                });
              });
            }
          }
        }
      };

      // =====================================================
      // GUIDAT PER SHORTS / REELS (9:16)
      // =====================================================
      // U rikthyen ne v3.1 - u fshine gabimisht kur u hoqen statistikat.

      scope.viewport = { w: 1920, h: 1080 };

      function measureViewport() {
        try {
          var el = element && element[0] ? element[0] : null;
          var w = (el && el.offsetWidth) || $window.innerWidth || 1920;
          var h = (el && el.offsetHeight) || $window.innerHeight || 1080;
          if (w > 0 && h > 0) { scope.viewport.w = w; scope.viewport.h = h; }
        } catch (e) {}
      }
      measureViewport();

      function ratioValue(r) {
        switch (String(r)) {
          case '9:16': return 9 / 16;
          case '4:5':  return 4 / 5;
          case '1:1':  return 1;
          case '16:9': return 16 / 9;
          default:     return 9 / 16;
        }
      }

      scope.safeBox = function() {
        var vw = scope.viewport.w, vh = scope.viewport.h;
        var ar = ratioValue(scope.cfg.guideRatio);
        var boxH = vh, boxW = vh * ar;
        if (boxW > vw) { boxW = vw; boxH = vw / ar; }
        return { w:boxW, h:boxH, left:(vw-boxW)/2, top:(vh-boxH)/2, cx:vw/2, cy:vh/2 };
      };

      scope.guideFrameStyle = function() {
        var b = scope.safeBox();
        return { left:b.left+'px', top:b.top+'px', width:b.w+'px', height:b.h+'px',
                 borderColor: scope.cfg.guideColor };
      };
      scope.guideDimLeftStyle = function() {
        var b = scope.safeBox();
        return { left:'0px', top:'0px', width:Math.max(0,b.left)+'px', height:'100%',
                 background:'rgba(0,0,0,'+Number(scope.cfg.guideDim||0)+')' };
      };
      scope.guideDimRightStyle = function() {
        var b = scope.safeBox();
        return { left:(b.left+b.w)+'px', top:'0px',
                 width:Math.max(0, scope.viewport.w-(b.left+b.w))+'px', height:'100%',
                 background:'rgba(0,0,0,'+Number(scope.cfg.guideDim||0)+')' };
      };
      scope.guideVStyle = function(){ return { left: scope.safeBox().cx+'px', background: scope.cfg.guideColor }; };
      scope.guideHStyle = function(){ return { top:  scope.safeBox().cy+'px', background: scope.cfg.guideColor }; };
      scope.guideThirdStyle = function(which, i) {
        var b = scope.safeBox();
        if (which === 'v') return { left:(b.left + b.w*(i/3))+'px', background: scope.cfg.guideColor };
        return { top:(b.top + b.h*(i/3))+'px', background: scope.cfg.guideColor };
      };
      scope.guideLabel = function() {
        var b = scope.safeBox();
        return Math.round(b.w)+' x '+Math.round(b.h)+'  ('+scope.cfg.guideRatio+')';
      };
      scope.guideLabelStyle = function() {
        var b = scope.safeBox();
        return { left:b.left+'px', top:Math.max(0,b.top-26)+'px', color: scope.cfg.guideColor };
      };

      function hudDims() {
        var n = 0;
        angular.forEach(scope.cfg.items, function(it) { if (it && it.enabled !== false) n++; });
        if (n < 1) n = 1;

        var lay = scope.cfg.layout || 'row';
        var cols = n, rows = 1;
        if (lay === 'column') { cols = 1; rows = n; }
        else if (lay === 'grid') {
          cols = Math.max(1, Number(scope.cfg.gridCols) || 4);
          rows = Math.ceil(n / cols);
          if (n < cols) cols = n;
        }

        var size = Number(scope.cfg.itemSize) || 112;
        var gap  = Number(scope.cfg.gap) || 0;
        var labelH = scope.cfg.showLabels ? (Number(scope.cfg.labelSize) || 13) + 12 : 0;
        return {
          w: cols * size + (cols - 1) * gap,
          h: rows * size + (rows - 1) * gap + labelH
        };
      }

      scope.fitToGuide = function(where) {
        measureViewport();
        var b = scope.safeBox();
        var d = hudDims();

        scope.cfg.positionX = Math.round(b.left + (b.w - d.w) / 2);

        var pad = Math.round(b.h * 0.06);
        if (where === 'top')         scope.cfg.positionY = Math.round(b.top + pad);
        else if (where === 'bottom') scope.cfg.positionY = Math.round(b.top + b.h - d.h - pad - 70);
        else                         scope.cfg.positionY = Math.round(b.cy - d.h / 2);

        if (scope.cfg.positionX < 0) scope.cfg.positionX = 0;
        if (scope.cfg.positionY < 0) scope.cfg.positionY = 0;
        scope.persist();
      };

      scope.shortsPreset = function(kind) {
        scope.cfg.guidesOn = true;
        scope.cfg.guideRatio = '9:16';

        if (kind === 'grid2') { scope.cfg.layout = 'grid'; scope.cfg.gridCols = 2; }
        else { scope.cfg.layout = 'column'; }

        var b = scope.safeBox();
        var n = 0;
        angular.forEach(scope.cfg.items, function(it) { if (it && it.enabled !== false) n++; });
        if (n < 1) n = 1;

        var cols = (kind === 'grid2') ? Math.min(2, n) : 1;
        var rows = Math.ceil(n / cols);
        var gap = Number(scope.cfg.gap) || 14;

        var maxByH = (b.h * 0.72 - (rows - 1) * gap) / rows;
        var maxByW = (b.w * 0.86 - (cols - 1) * gap) / cols;
        var size = Math.floor(Math.min(maxByH, maxByW));
        if (size < 40) size = 40;
        if (size > 220) size = 220;
        scope.cfg.itemSize = size;

        scope.fitToGuide('center');
      };

      var onResize = function() { scope.$applyAsync(measureViewport); };
      $window.addEventListener('resize', onResize);

      // =====================================================
      // PREVIEW I MADH RRETHOR NE EDITOR
      // =====================================================
      scope.thumbStyle = function(item) {
        var radius = '50%';
        var shape = String(scope.cfg.circleShape).toLowerCase();
        if (shape === 'rounded') radius = '22px';
        if (shape === 'square')  radius = '0px';

        var bc = 'rgba(255,255,255,0.14)';
        if (item.state === 'pass') bc = 'rgba(104,255,164,0.98)';
        else if (item.state === 'fail') bc = 'rgba(255,88,88,0.98)';

        return {
          borderRadius: radius,
          borderWidth: Math.max(3, Number(scope.cfg.outlineWidth || 4)) + 'px',
          borderColor: bc,
          background: 'rgba(0,0,0,' + Number(scope.cfg.pendingFillOpacity || 0.16) + ')'
        };
      };

      scope.thumbImgStyle = function(item) {
        var scale = item.imageScale != null ? item.imageScale : (scope.cfg.imageScale || 1.0);
        var ox = Number(item.imageOffsetX || 0);
        var oy = Number(item.imageOffsetY || 0);
        var rot = Number(item.imageRotation || 0);
        var k = 190 / (Number(scope.cfg.itemSize) || 112);

        return {
          backgroundImage: item.image ? ('url(' + item.image + ')') : 'none',
          backgroundSize: Math.round(scale * 1.55 * 100) + '%',
          backgroundPosition: 'calc(50% + ' + (ox * k) + 'px) calc(50% + ' + (oy * k) + 'px)',
          transform: 'rotate(' + rot + 'deg)'
        };
      };

      // =====================================================
      // v3.1 — ZGJEDHES NGJYRASH
      // =====================================================
      // CEF-i i BeamNG nuk e hap dialogun e sistemit per <input type="color">,
      // prandaj perdorim nje palete te vetendertuar + fushe hex.

      scope.palette = [
        '#ffffff', '#c8d2dc', '#8c99a6', '#3c4652', '#000000', '#ff3c3c', '#ff6b35', '#ffa726',
        '#ffd400', '#c6ff00', '#3dff88', '#00e5a0', '#00d4ff', '#2f9bff', '#5b6cff', '#9b5bff',
        '#e05bff', '#ff4fa3', '#8d5524', '#00ffc8', '#ff0080', '#7cfc00', '#ff2d55', '#40e0d0'
      ];

      scope.pickerOpen = null;

      scope.isPickerOpen = function(key) { return scope.pickerOpen === key; };

      scope.togglePicker = function(key, ev) {
        if (ev) { ev.preventDefault(); ev.stopPropagation(); }
        scope.pickerOpen = (scope.pickerOpen === key) ? null : key;
      };

      scope.closePicker = function() { scope.pickerOpen = null; };

      var HEX_RE = /^#([0-9a-fA-F]{3}|[0-9a-fA-F]{6})$/;

      function normalizeHex(h, fallback) {
        if (typeof h !== 'string') return fallback;
        var v = h.trim();
        if (v.charAt(0) !== '#') v = '#' + v;
        if (!HEX_RE.test(v)) return fallback;
        v = v.toLowerCase();
        if (v.length === 4) {   // #abc -> #aabbcc
          v = '#' + v[1] + v[1] + v[2] + v[2] + v[3] + v[3];
        }
        return v;
      }

      scope.sameColor = function(a, b) {
        return normalizeHex(a, 'x') === normalizeHex(b, 'y');
      };

      // Shkrimi manual: ruaj tekstin e papërpunuar qe perdoruesi te
      // mund te shkruaje lirshem, apliko vetem kur behet hex i vlefshem.
      scope.setColorField = function(target, key) {
        if (!target) return;
        var raw = target[key + '__raw'];
        var norm = normalizeHex(raw, null);
        if (norm) { target[key] = norm; scope.persist(); }
      };

      scope.pickColor = function(target, key, color) {
        if (!target) return;
        var norm = normalizeHex(color, null);
        if (!norm) return;
        target[key] = norm;
        target[key + '__raw'] = norm;
        scope.persist();
      };

      // mbylle popup-in kur klikohet jashte
      function onDocClickPicker() {
        if (scope.pickerOpen !== null) {
          scope.$applyAsync(function() { scope.pickerOpen = null; });
        }
      }
      $document.on('click', onDocClickPicker);

      // mbush fushat __raw kur ngarkohet konfigurimi
      function syncColorRaw() {
        scope.cfg.costColor__raw = scope.cfg.costColor;
        scope.cfg.costLabelColor__raw = scope.cfg.costLabelColor;
        scope.cfg.costCircleColor__raw = scope.cfg.costCircleColor;
        scope.cfg.costPassColor__raw = scope.cfg.costPassColor;
        scope.cfg.costFailColor__raw = scope.cfg.costFailColor;
        if (scope.cfg.guideColor) scope.cfg.guideColor__raw = scope.cfg.guideColor;
        scope.cfg.survivalLabelColor__raw = scope.cfg.survivalLabelColor;
        scope.cfg.survivalValueColor__raw = scope.cfg.survivalValueColor;
        scope.cfg.survivalDeltaColor__raw = scope.cfg.survivalDeltaColor;
        scope.cfg.survivalWarningColor__raw = scope.cfg.survivalWarningColor;
        scope.cfg.survivalCriticalColor__raw = scope.cfg.survivalCriticalColor;
        scope.cfg.survivalBackgroundColor__raw = scope.cfg.survivalBackgroundColor;
      }
      syncColorRaw();

      // =====================================================
      // v3.1 — REPAIR COST (per makine, me maksimum)
      // =====================================================
      // Lua dergon demin e papërpunuar (0..1). Ne e shnderrojme ne
      // dollare duke e shumezuar me buxhetin maksimal te asaj makine.
      //   dem 0%   -> $0
      //   dem 13%  -> $1,300  (nese max = 10,000)
      //   dem 100% -> $10,000
      // Cdo makine e ka maksimumin e vet, i ndryshueshem nga paneli.

      scope.cost = { mode: 'fallback', pulse: false, ratio: 0 };

      var costLast = 0;
      var costPulseDelay = null;
      var costPulseTimer = null;
      var followTimer = null;

      // v4.3 Survival Chance animation state
      scope.survival = {
        pulse:false, shake:false, rolling:false, emojiPulse:false, oldValue:100, displayValue:100,
        visible:true, deltaVisible:false, deltaText:'',
        // ---- v5.2 ----
        rotIndex:0, stateKey:'safe', auraOpacity:0, userFontLoaded:false
      };
      var survivalPulseTimer = null;
      var survivalDeltaTimer = null;
      var survivalHideTimer = null;
      var survivalShakeTimer = null;
      var survivalRollTimer = null;
      var survivalTweenTimer = null;
      var survivalEmojiTimer = null;
      var unwatchSurvivalEmoji = null;
      // ---- v5.2 timerat ----
      var survivalRotateTimer = null;
      var unwatchSurvivalState = null;

      // Lightweight 30 FPS number tween. New telemetry continues from the current
      // visual value instead of restarting/jumping every 0.25 seconds.
      function animateSurvivalDisplay(target) {
        target = Math.max(0, Math.min(100, Number(target)));
        if (!isFinite(target)) target = 100;
        var start = Number(scope.survival.displayValue);
        if (!isFinite(start)) start = target;
        if (survivalTweenTimer) { try { $timeout.cancel(survivalTweenTimer); } catch(e) {} }
        var duration = Math.max(120, Math.min(900, Number(scope.cfg.survivalSmoothTime) || 340));
        var began = Date.now();
        function frame() {
          var t = Math.min(1, (Date.now() - began) / duration);
          var eased = 1 - Math.pow(1 - t, 3);
          scope.survival.displayValue = start + (target - start) * eased;
          refreshSurvivalDrama();
          if (t < 1) survivalTweenTimer = $timeout(frame, 33);
          else { scope.survival.displayValue = target; survivalTweenTimer = null; refreshSurvivalDrama(); }
        }
        frame();
      }

      syncSurvivalDisplay();

      // v5.2: nis rrahjen, rrotullimin e frazave dhe ze rin ne sfond
            function syncSurvivalDisplay() {
        var it = scope.cfg.items[scope.selected];
        var v = it ? Number(it.survivalChance) : 100;
        scope.survival.displayValue = isFinite(v) ? Math.max(0, Math.min(100, v)) : 100;
      }
      syncSurvivalDisplay();

      // v5.2: nis rrahjen, rrotullimin e frazave dhe ze rin ne sfond
      // v5.3.0: kontrollon fontin dhe shfaq toast-in me versionin
      $timeout(function() {
        refreshSurvivalDrama();
        restartSurvivalRotation();
        startSurvivalSound();
        if (scope.cfg.survivalUserFontData) applyUserFont(scope.cfg.survivalUserFontData);
        checkBangers();
        scope.showToast();
        // rikontrollo pasi fonti të jetë ngarkuar vërtet
        $timeout(function() { checkBangers(); }, 1400);
      }, 400);

      function showSurvivalDelta(drop, oldValue) {
        var decimals = Math.max(0, Math.min(1, Number(scope.cfg.survivalDecimals) || 0));
        drop = Math.max(0, Number(drop) || 0);
        var minDrop = Math.max(0.1, Number(scope.cfg.survivalDeltaMin) || 1);
        scope.survival.visible = true;

        if (survivalPulseTimer) { try { $timeout.cancel(survivalPulseTimer); } catch(e) {} }
        if (survivalDeltaTimer) { try { $timeout.cancel(survivalDeltaTimer); } catch(e) {} }
        if (survivalHideTimer) { try { $timeout.cancel(survivalHideTimer); } catch(e) {} }
        if (survivalShakeTimer) { try { $timeout.cancel(survivalShakeTimer); } catch(e) {} }

        scope.survival.pulse = false;
        scope.survival.shake = false;
        scope.survival.rolling = false;
        scope.survival.deltaVisible = false;
        if (survivalRollTimer) { try { $timeout.cancel(survivalRollTimer); } catch(e) {} }
        scope.survival.oldValue = isFinite(Number(oldValue)) ? Number(oldValue) : (scope.survivalRawValue ? scope.survivalRawValue() + drop : 100);

        $timeout(function() {
          scope.survival.deltaText = '-' + drop.toFixed(decimals) + '%';
          scope.survival.pulse = true;
          scope.survival.rolling = scope.cfg.survivalRollingCounter !== false;
          scope.survival.shake = scope.cfg.survivalImpactShake !== false && drop >= minDrop;
          scope.survival.deltaVisible = scope.cfg.survivalShowDelta !== false && drop >= minDrop;
          survivalPulseTimer = $timeout(function() { scope.survival.pulse = false; }, 370);
          survivalRollTimer = $timeout(function() { scope.survival.rolling = false; }, Math.max(220, Number(scope.cfg.survivalRollDuration) || 430));
          survivalShakeTimer = $timeout(function() { scope.survival.shake = false; }, 430);
          survivalDeltaTimer = $timeout(function() { scope.survival.deltaVisible = false; },
            Math.max(300, Number(scope.cfg.survivalDeltaDuration) || 850));

          // ---- v5.3.1: pa popup mbi ekran — vetëm tingulli (i butë) ----
          if (drop >= minDrop) survivalSoundAlert(null, null, drop);
          memeSfxOnDrop(drop);
          refreshSurvivalDrama();
        }, 12);

        if (scope.cfg.survivalDisplayMode === 'change') {
          survivalHideTimer = $timeout(function() { scope.survival.visible = false; },
            Math.max(500, Number(scope.cfg.survivalAutoHideMs) || 3000));
        }
      }

      // Kur shtypet PASS/FAIL, kostoja kalon perkohesisht mbi ate rreth
      scope.costFollowIdx = -1;

      // v3.2: paneli u nda ne tab-a per te hequr mbingarkesen vizuale
      scope.tab = 'kryesore';

      function engineLua(cmd) {
        try {
          if (window.bngApi && typeof window.bngApi.engineLua === 'function') {
            window.bngApi.engineLua(cmd); return true;
          }
          if (window.bngApi && typeof window.bngApi.engineLuaAsync === 'function') {
            window.bngApi.engineLuaAsync(cmd); return true;
          }
        } catch (e) {}
        return false;
      }

      function bootCostLua() {
        engineLua("extensions.load('creatorpack')");
        engineLua("if extensions.creatorpack and extensions.creatorpack.setDamageSensitivity then "
                + "extensions.creatorpack.setDamageSensitivity(" + (Number(scope.cfg.costSens) || 1) + ") end");
        engineLua("if extensions.creatorpack and extensions.creatorpack.setCostEnabled then "
                + "extensions.creatorpack.setCostEnabled(" + (scope.cfg.costOn ? "true" : "false") + ") end");
      }

      scope.applyCostSens = function() {
        engineLua("if extensions.creatorpack and extensions.creatorpack.setDamageSensitivity then "
                + "extensions.creatorpack.setDamageSensitivity(" + (Number(scope.cfg.costSens) || 1) + ") end");
        scope.persist();
      };

      scope.toggleCost = function() {
        if (scope.cfg.costOn) bootCostLua();
        else engineLua("if extensions.creatorpack and extensions.creatorpack.setCostEnabled then "
                     + "extensions.creatorpack.setCostEnabled(false) end");
        scope.persist();
      };

      // Makina qe po matet tani: ajo e zgjedhur, nese s'eshte e ngrire
      function activeCostItem() {
        var it = scope.cfg.items[scope.selected];
        if (it && it.enabled !== false) return it;
        return null;
      }

      var unsubCost = $rootScope.$on('creatorpack.cost', function(e, d) {
        if (!d) return;
        scope.cost.mode = d.mode || 'fallback';

        // ratio 0..1 nga Lua (deformimi i papërpunuar ndaj referimit)
        var ratio = Number(d.ratio);
        if (!isFinite(ratio)) ratio = 0;
        ratio = Math.max(0, Math.min(1, ratio));
        scope.cost.ratio = ratio;

        var it = activeCostItem();
        if (!it) { scope.$applyAsync(); return; }
        it.visited = true;

        // v3.3: tavani i riparimit lidhet me vleren reale te makines.
        // 90% e vleres se makines, me kufi 5k..100k qe te mos dalin
        // as shuma qesharake, as repair costs me miliona.
        var vehicleValue = Number(d.maxValue);
        if (scope.cfg.costAutoMax && isFinite(vehicleValue) && vehicleValue > 0) {
          var factor = Number(scope.cfg.costVehicleFactor);
          if (!isFinite(factor)) factor = 0.90;
          factor = Math.max(0.50, Math.min(1.00, factor));
          var autoMax = Math.round((vehicleValue * factor) / 500) * 500;
          autoMax = Math.max(500, Math.min(250000, autoMax));
          it.costMax = autoMax;
        }

        // v4.1: store the actual damage ratio for this circle. It only grows
        // during a run and freezes together with the result after PASS/FAIL.
        if (!it.costLocked) {
          var oldDamage = Math.max(0, Math.min(1, Number(it.damageRatio) || 0));
          var newDamage = Math.max(oldDamage, ratio);
          it.damageRatio = newDamage;
          if (newDamage > oldDamage + 0.002 && scope.cfg.costPulse !== false && scope.cfg.animLevel !== 'off') {
            it.damagePulse = false;
            $timeout(function() {
              it.damagePulse = true;
              $timeout(function() { it.damagePulse = false; }, 430);
            }, 10);
          }
        }

        // v4.3: structural risk + recent impact severity. Chance never rises
        // during the run; 0% is reserved for a genuinely totalled vehicle.
        if (!it.costLocked) {
          var currentRatio = Math.max(0, Math.min(1, Number(it.damageRatio) || 0));
          var speedKmh = Math.max(0, Number(d.speedKmh) || 0);
          var deltaDamage = Math.max(0, currentRatio - oldDamage);
          var sensitivity = Math.max(0.65, Math.min(1.35, Number(scope.cfg.survivalSensitivity) || 1));
          var formula = scope.cfg.survivalFormula || 'balanced';
          var formulaScale = formula === 'forgiving' ? 0.78 : (formula === 'hardcore' ? 1.28 : 1.0);
          var curveExp = formula === 'forgiving' ? 0.92 : (formula === 'hardcore' ? 0.72 : 0.82);
          var damageWeight = Number(scope.cfg.survivalDamageWeight);
          var impactWeight = Number(scope.cfg.survivalImpactWeight);
          var speedWeight = Number(scope.cfg.survivalSpeedWeight);
          if (!isFinite(damageWeight)) damageWeight = 1;
          if (!isFinite(impactWeight)) impactWeight = 1;
          if (!isFinite(speedWeight)) speedWeight = 1;
          damageWeight = Math.max(0, Math.min(2, damageWeight));
          impactWeight = formula === 'damageOnly' ? 0 : Math.max(0, Math.min(2, impactWeight));
          speedWeight = formula === 'damageOnly' ? 0 : Math.max(0, Math.min(2, speedWeight));
          var targetChance;
          if (currentRatio >= 0.995) {
            targetChance = 0;
          } else if (currentRatio < 0.0005) {
            targetChance = 100;
          } else {
            var structuralRisk = Math.pow(currentRatio, curveExp) * 100 * damageWeight;
            var speedFactor = 0.30 + Math.min(1, speedKmh / 160) * 0.45 * speedWeight;
            var impactRisk = deltaDamage * 100 * speedFactor * impactWeight;
            targetChance = 100 - (structuralRisk + impactRisk) * sensitivity * formulaScale;
            var minAlive = Math.max(1, Math.min(15, Number(scope.cfg.survivalMinAlive) || 1));
            targetChance = Math.max(minAlive, Math.min(99.9, targetChance));
          }
          var oldChance = Math.max(0, Math.min(100, Number(it.survivalChance)));
          if (!isFinite(oldChance)) oldChance = 100;
          if (targetChance < oldChance) {
            it.survivalChance = targetChance;
            if (it === activeCostItem()) animateSurvivalDisplay(targetChance);
            if (scope.cfg.survivalOn && it === activeCostItem()) showSurvivalDelta(oldChance - targetChance, oldChance);
          }
        }

        // e ngrire = u markua me PASS/FAIL; vlera e saj nuk preket me
        if (it.costLocked) { scope.$applyAsync(); return; }

        var max = Math.max(0, Number(it.costMax) || 0);
        var curve = Number(scope.cfg.costCurve);
        if (!isFinite(curve) || curve <= 0) curve = 1.55;
        var minDamage = Number(scope.cfg.costMinDamage);
        if (!isFinite(minDamage)) minDamage = 0.01;
        minDamage = Math.max(0, Math.min(0.25, minDamage));
        var effectiveRatio = ratio <= minDamage ? 0 : Math.max(0, Math.min(1, (ratio - minDamage) / (1 - minDamage)));
        // Non-linear premium curve: small hits stay cheap, major crashes scale harder.
        var v = Math.round(Math.pow(effectiveRatio, curve) * max);

        // kostoja vetem rritet gjate nje sesioni (nuk bie kur makina qetesohet)
        if (v < (it.costNow || 0)) v = it.costNow;

        if (scope.cfg.costPulse && v > costLast + Math.max(5, max * 0.005)) {
          if (costPulseDelay) { try { clearTimeout(costPulseDelay); } catch (x) {} }
          if (costPulseTimer) { try { clearTimeout(costPulseTimer); } catch (x) {} }
          scope.cost.pulse = false;
          costPulseDelay = setTimeout(function () {
            scope.$applyAsync(function () { scope.cost.pulse = true; });
            costPulseTimer = setTimeout(function () {
              scope.$applyAsync(function () { scope.cost.pulse = false; });
            }, 300);
          }, 10);
        }

        costLast = v;
        it.costNow = v;
        scope.$applyAsync();
      });

      function hexToRgba(hex, alpha) {
        var h = String(hex || '#000000').replace('#','');
        if (h.length === 3) h = h[0]+h[0]+h[1]+h[1]+h[2]+h[2];
        var n = parseInt(h,16); if (!isFinite(n)) n = 0;
        return 'rgba('+((n>>16)&255)+','+((n>>8)&255)+','+(n&255)+','+alpha+')';
      }

      function mixHex(a, b, t) {
        function rgb(h) {
          h = String(h || '#000000').replace('#','');
          if (h.length === 3) h = h[0]+h[0]+h[1]+h[1]+h[2]+h[2];
          var n = parseInt(h,16); if (!isFinite(n)) n = 0;
          return [(n>>16)&255,(n>>8)&255,n&255];
        }
        t = Math.max(0,Math.min(1,Number(t)||0));
        var x=rgb(a), y=rgb(b), out=[];
        for (var i=0;i<3;i++) out.push(Math.round(x[i]+(y[i]-x[i])*t));
        return '#'+out.map(function(v){return ('0'+v.toString(16)).slice(-2);}).join('');
      }

      // ---- v4.1 radial damage helpers ----
      var DAMAGE_RING_CIRCUMFERENCE = 292.17; // 2 * PI * 46.5 (SVG viewBox)

      scope.damageRatioOf = function(item) {
        var r = item ? Number(item.damageRatio) : 0;
        if (!isFinite(r)) r = 0;
        return Math.max(0, Math.min(1, r));
      };

      scope.damagePercent = function(item) {
        var r = scope.damageRatioOf(item);
        if (r >= 0.995) return 100;
        return Math.round(r * 100);
      };

      scope.damageColor = function(item) {
        var pct = scope.damagePercent(item);
        if (pct >= 100) return '#ff334d'; // pure red only when fully destroyed
        if (pct <= 35) return mixHex('#42ff68','#9dff3f',pct/35);
        if (pct <= 75) return mixHex('#9dff3f','#ff8a2f',(pct-35)/40);
        return mixHex('#ff8a2f','#ff5638',(pct-75)/24);
      };

      scope.damageVisible = function(item, index) {
        if (!item) return false;
        return item.visited === true || index === scope.selected || item.costLocked === true || scope.damageRatioOf(item) > 0;
      };

      scope.damageLabel = function(item) {
        var pct = scope.damagePercent(item);
        if (pct >= 100) return 'TOTALLED';
        if (pct >= 80) return 'CRITICAL';
        return 'DAMAGE';
      };

      scope.damageValueStyle = function(item) {
        var color = scope.damageColor(item);
        return {
          color: color,
          textShadow: '0 2px 7px rgba(0,0,0,.95), 0 0 8px ' + color
        };
      };

      scope.damageRingOffset = function(item) {
        var r = scope.damageRatioOf(item);
        if (r >= 0.995) r = 1;
        return (DAMAGE_RING_CIRCUMFERENCE * (1 - r)).toFixed(2);
      };

      scope.damageReadoutClass = function(item, index) {
        var pct = scope.damagePercent(item);
        return {
          'damage-critical': pct >= 80 && pct < 100,
          'damage-totalled': pct >= 100,
          'is-inactive': index !== scope.selected && pct === 0,
          'is-unvisited': !scope.damageVisible(item, index)
        };
      };

      scope.survivalRawValue = function() {
        var it = activeCostItem();
        if (!it) return 100;
        var v = Number(it.survivalChance);
        return isFinite(v) ? Math.max(0, Math.min(100, v)) : 100;
      };

      scope.survivalVisualValue = function() {
        var v = Number(scope.survival.displayValue);
        return isFinite(v) ? Math.max(0,Math.min(100,v)) : scope.survivalRawValue();
      };

      scope.survivalValue = function() {
        var decimals = Math.max(0, Math.min(1, Number(scope.cfg.survivalDecimals) || 0));
        return scope.survivalVisualValue().toFixed(decimals);
      };

      scope.formatSurvivalValue = function(value) {
        var decimals = Math.max(0, Math.min(1, Number(scope.cfg.survivalDecimals) || 0));
        var v = Number(value); if (!isFinite(v)) v = 100;
        return Math.max(0, Math.min(100, v)).toFixed(decimals);
      };

      // =====================================================
      // v5.2 — 5 NGJYRA (safe / caution / danger / critical / dead)
      // =====================================================
      scope.survivalStateKey = function() {
        var v = scope.survivalVisualValue();
        if (v <= 0) return 'dead';
        if (v <= Number(scope.cfg.survivalCriticalThreshold || 20)) return 'critical';
        if (v <= Number(scope.cfg.survivalWarningThreshold || 55)) return 'danger';
        if (v <= Number(scope.cfg.survivalCautionThreshold || 80)) return 'caution';
        return 'safe';
      };

      function survivalThresholds() {
        var c = Math.max(1, Math.min(99, Number(scope.cfg.survivalCautionThreshold) || 80));
        var w = Math.max(1, Math.min(98, Number(scope.cfg.survivalWarningThreshold) || 55));
        var k = Math.max(1, Math.min(97, Number(scope.cfg.survivalCriticalThreshold) || 20));
        if (w >= c) w = c - 1;
        if (k >= w) k = Math.max(1, w - 1);
        return { caution: c, warning: w, critical: k };
      }

      scope.survivalPalette = function() {
        return {
          safe: scope.cfg.survivalValueColor || '#42ff68',
          caution: scope.cfg.survivalCautionColor || '#ffd23f',
          danger: scope.cfg.survivalWarningColor || '#ff7a2f',
          critical: scope.cfg.survivalCriticalColor || '#ff334d',
          dead: scope.cfg.survivalDeadColor || '#b3122b'
        };
      };

      scope.survivalColor = function() {
        var v = scope.survivalVisualValue();
        var pal = scope.survivalPalette();
        if (!scope.cfg.survivalDynamicColor) return pal.safe;
        if (!scope.cfg.survivalStatusBlend) return pal[scope.survivalStateKey()] || pal.safe;
        var t = survivalThresholds();
        if (v >= t.caution) return pal.safe;
        if (v <= 0) return pal.dead;
        if (v >= t.warning) return mixHex(pal.caution, pal.safe, (v - t.warning) / Math.max(1, t.caution - t.warning));
        if (v >= t.critical) return mixHex(pal.danger, pal.caution, (v - t.critical) / Math.max(1, t.warning - t.critical));
        return mixHex(pal.critical, pal.danger, Math.max(0, v) / Math.max(1, t.critical));
      };

      // =====================================================
      // v5.2 — STATUSI DRAMATIK (paketa frazash, anglisht)
      // =====================================================
      // v5.4 — 22 STILE REAKSIONESH (+ Custom), 6 nivele sipas përqindjes:
      //   safe 76–100 · caution 51–75 · danger 26–50 · severe 6–25 · extreme 1–5 · dead 0
      var SURVIVAL_PACKS = {
        "cinematic": {
          "safe": [
            "ALL QUIET 🟢",
            "IN CONTROL ✅",
            "CLEAR SKIES ✅",
            "STEADY HANDS 🤲",
            "CALM BEFORE 😌",
            "UNTOUCHED ✅",
            "FOCUSED 🎯",
            "ON COURSE 🌤️"
          ],
          "caution": [
            "SOMETHING'S COMING 👁️",
            "STAY SHARP 😬",
            "EYES OPEN 👀",
            "THE AIR CHANGES ⚠️",
            "TENSION RISES 👁️",
            "NOT ALONE 🌫️",
            "WATCH THE ROAD 👀",
            "FIRST CRACKS ⚠️"
          ],
          "danger": [
            "BRACE YOURSELF 💥",
            "NO MARGIN LEFT 🟠",
            "THE ODDS TURN ⛓️",
            "PRESSURE MOUNTS ⚠️",
            "HOLD THE LINE ✊",
            "TIME RUNS SHORT ⏳",
            "ON THIN ICE 🧊",
            "EVERYTHING SHAKES ⚠️"
          ],
          "severe": [
            "DON'T BLINK 🔴",
            "BRACE FOR IMPACT 💥",
            "THIS COULD BE IT 🌪️",
            "NO WAY BACK 🚫",
            "SECONDS LEFT ⏳",
            "DANGER CLOSE 🚨",
            "HANGING BY A THREAD 🌪️",
            "EVERYTHING ON THE LINE 🚨"
          ],
          "extreme": [
            "LAST CHANCE ⏳",
            "THIS IS IT 💔",
            "ONE MORE HIT... 😵",
            "FINAL SECONDS ⏳",
            "NOW OR NEVER 😵",
            "THE LAST BREATH 😵",
            "ONE SHOT LEFT 😵",
            "AGAINST ALL ODDS ⏳"
          ],
          "dead": [
            "LIGHTS OUT 🌑",
            "FADE TO BLACK 🌑",
            "THE END 🎬",
            "ROLL CREDITS 🎬",
            "SILENCE 🌑",
            "IT'S OVER 🕯️",
            "CUT. 🎬",
            "NO SEQUEL 🎬"
          ]
        },
        "dramatic": {
          "safe": [
            "LOOKING GOOD ✅",
            "STILL STRONG ✅",
            "ALL GOOD ✅",
            "HOLDING UP 👌",
            "FEELING GOOD ✅",
            "NOTHING TO FEAR 💯",
            "SOLID ✅",
            "UNBROKEN 💪"
          ],
          "caution": [
            "CAREFUL... 😬",
            "GETTING RISKY 👀",
            "NOT SO SAFE... 😬",
            "THAT WAS CLOSE 😐",
            "HOLD STEADY 😬",
            "IT'S SLIPPING 😅",
            "EASY NOW... 😬",
            "FEEL THAT? 🤔"
          ],
          "danger": [
            "HOLD ON! ✊",
            "THIS IS BAD 😨",
            "IT'S FALLING APART 🥵",
            "NOT GOOD 😟",
            "WE'RE LOSING IT 😧",
            "FIGHT IT! ✊",
            "STAY WITH ME 🫨",
            "PLEASE HOLD 😫"
          ],
          "severe": [
            "NO... NO... 😱",
            "IT'S BREAKING 🚨",
            "HANG ON! ✊",
            "DON'T GIVE UP 💪",
            "SO MUCH DAMAGE 🥶",
            "IT CAN'T END 😣",
            "KEEP FIGHTING ✊",
            "NOT LIKE THIS 🫨"
          ],
          "extreme": [
            "NO WAY 🤯",
            "STILL BREATHING?! 🤯",
            "BARELY ALIVE 😵",
            "ONE LAST PUSH 😵",
            "HOW?! 🤯",
            "DON'T YOU DARE 😳",
            "HOLD ON... PLEASE 😫",
            "IT'S NOT OVER! 💔"
          ],
          "dead": [
            "IT'S OVER 💀",
            "GONE. 🪦",
            "NOTHING LEFT ☠️",
            "HEARTBREAK 😭",
            "IT'S FINISHED 💥",
            "ALL IS LOST 🫠",
            "NO MORE 🏳️",
            "FAREWELL 😭"
          ]
        },
        "streamer": {
          "safe": [
            "WE'RE GOOD ✅",
            "EASY MONEY 💸",
            "CHAT WE CHILLING 💬",
            "LOOKIN' CLEAN ✨",
            "NO STRESS 😌",
            "W DRIVING 🚗",
            "CLIP THAT 🎥",
            "TOO EASY CHAT 💬"
          ],
          "caution": [
            "GETTING SPICY 🔥",
            "CAREFUL NOW 😬",
            "CHAT... 💬",
            "AYO? 😐",
            "WE GOOD? ✅",
            "OKAY OKAY 😅",
            "THAT'S SUS 🤨",
            "HOLD UP ✊"
          ],
          "danger": [
            "CHAT IT'S BAD 💬",
            "UH OH 😨",
            "NAH WAIT ✋",
            "BRO WHAT 😳",
            "WE'RE TWEAKING 😧",
            "CHAT HELP 💬",
            "NOT THE BUMPER 🚗",
            "THIS AIN'T IT ⚠️"
          ],
          "severe": [
            "BRO PLEASE 😫",
            "CHAT PRAY FOR ME 💬",
            "AIN'T NO WAY 🤯",
            "WE'RE SO BACK? 🙏",
            "NAHHH 😩",
            "CHAT DON'T CLIP 🎥",
            "HANDS SHAKING 😰",
            "I'M SWEATING 😰"
          ],
          "extreme": [
            "CHAT I'M COOKED 💀",
            "BRO PLEASE 😭",
            "AIN'T NO WAY 🤯",
            "ONE HP CHAT 💬",
            "CLIP IT CLIP IT 🎥",
            "HOW AM I ALIVE 🤯",
            "DON'T BREATHE 🤐",
            "CHAT HOLD MY HAND 💬"
          ],
          "dead": [
            "CHAT I'M COOKED 🍳",
            "GG CHAT 🪦",
            "WE'RE DONE ☠️",
            "L + RATIO 🪦",
            "ENDING STREAM 🪦",
            "CHAT IT'S JOEVER 🪦",
            "RUN IT BACK 🎥",
            "UNINSTALLING ❌"
          ]
        },
        "youtube": {
          "safe": [
            "STAY TILL THE END 🍿",
            "WATCH THIS 👀",
            "EASY... FOR NOW 😎",
            "SO FAR SO GOOD ✅",
            "HERE WE GO 🚀",
            "PERFECT RUN? ✨",
            "ALL SMILES 💯",
            "KEEP WATCHING 🍿"
          ],
          "caution": [
            "WAIT FOR IT... ⏳",
            "HERE IT COMES 😒",
            "OH? 👀",
            "THIS GETS WORSE 🤨",
            "NOTICE THAT? 👀",
            "PLOT TWIST? 🟡",
            "HMM... 🤔",
            "IT STARTS 🫣"
          ],
          "danger": [
            "WATCH CLOSELY 👀",
            "SO CLOSE 😨",
            "WHAT JUST HAPPENED? 😰",
            "OH NO... 😨",
            "IT GETS WORSE 🟠",
            "DON'T SKIP ⏭️",
            "REWIND THAT 🎥",
            "BIG MISTAKE 🫠"
          ],
          "severe": [
            "NO WAY... 🤯",
            "LOOK AT THIS 👀",
            "THE WORST PART ☠️",
            "IS THIS THE END? 🎬",
            "YOU SEE THAT?! 👀",
            "COMMENT IF ALIVE 🔔",
            "KEEP WATCHING 🍿",
            "HOW MUCH MORE? 🤯"
          ],
          "extreme": [
            "WAIT... WHAT?! 🤯",
            "HOW IS THIS ALIVE 🤯",
            "1% CLUTCH? 😵",
            "UNREAL 🤯",
            "NO WAY IT HOLDS 🤯",
            "BEST MOMENT ⚡",
            "DON'T LOOK AWAY 👀",
            "SUBSCRIBE IF IT LIVES 🔔"
          ],
          "dead": [
            "AND THAT'S THAT 🫡",
            "WELL... THAT HAPPENED 💀",
            "SEE YOU NEXT VIDEO 👋",
            "THAT'S A WRAP 🎬",
            "TOTALLED 🪦",
            "REPLAY? 🎥",
            "LIKE IF YOU CRIED 🔔",
            "0% ACHIEVED 🏳️"
          ]
        },
        "meme": {
          "safe": [
            "VIBING 😎",
            "STONKS 📈",
            "BIG CHILLIN 🛋️",
            "WE CHILLIN 😏",
            "TOP G DRIVER 👑",
            "EZ CLAP 👏",
            "SIGMA MODE 🗿",
            "NPC BEHAVIOR 🤖"
          ],
          "caution": [
            "HMMM 🤨",
            "SUS 🤨",
            "BRO? 🤨",
            "UH... 👀",
            "NOT STONKS 📉",
            "SIDE EYE 👀",
            "WELL... 🤨",
            "HOUSTON? 🚀"
          ],
          "danger": [
            "BRO 💀",
            "NAHH 😭",
            "THIS IS FINE 🔥",
            "EMOTIONAL DAMAGE 😭",
            "OOF 🤕",
            "YIKES 🤕",
            "BONK 🤕",
            "BRUH 🤕"
          ],
          "severe": [
            "WELL... 💀",
            "INSTANT REGRET 😣",
            "F IN THE CHAT 💀",
            "SEND HELP 🆘",
            "TO BE CONTINUED ➡️",
            "HE'S LOST IT 😭",
            "OUCH OWIE 🤕",
            "CAR SAID NO 🚗"
          ],
          "extreme": [
            "1 HP 💀",
            "HOLD MY BEER 🍺",
            "PLOT ARMOR? 🛡️",
            "LOADING... 1% 📡",
            "BRO IS A CAT 🐈",
            "HOW 😭",
            "NOT DEAD YET 😮‍💨",
            "SPEEDRUN % ⏱️"
          ],
          "dead": [
            "COOKED 🍳",
            "RIP 💀",
            "WASTED 🪦",
            "F 💀",
            "GG 💀",
            "YOU DIED 💀",
            "RIP BOZO 💀",
            "PRESS F 💀"
          ]
        },
        "savage": {
          "safe": [
            "BEGINNER'S LUCK 🍀",
            "DON'T GET COCKY 😏",
            "WON'T LAST ⌛",
            "ENJOY IT 😌",
            "SUSPICIOUSLY OK ✅",
            "EVEN YOU CAN'T FAIL 👌",
            "NOT BAD... YET 🙃",
            "SURPRISING 😲"
          ],
          "caution": [
            "WHO GAVE YOU KEYS? 🚗",
            "DRIVING TEST FAIL 🚗",
            "THAT WAS YOU 😬",
            "BRAKES EXIST 🚗",
            "NICE ONE, GENIUS 🤨",
            "WOW. JUST WOW. 😐",
            "GOOGLE 'STEERING' 🚗",
            "BOLD MOVE 😅"
          ],
          "danger": [
            "SKILL ISSUE 🤦",
            "NICE DRIVING 💀",
            "AMAZING JOB... 👏",
            "PEAK TALENT 🙃",
            "GET A BUS PASS 🚗",
            "THAT'S EMBARRASSING 😳",
            "CERTIFIED MENACE 😈",
            "INSURANCE CRIES 💸"
          ],
          "severe": [
            "YOU HAD ONE JOB 🤦",
            "10/10 DRIVING 👏",
            "SHOULD'VE WALKED 🚗",
            "HISTORY IN MAKING 📖",
            "TRULY GIFTED 🎁",
            "PROUD OF YOU? NO 🙅",
            "LICENSE REVOKED 🚗",
            "DID YOU CLOSE EYES? 👀"
          ],
          "extreme": [
            "IMPRESSIVELY BAD 👏",
            "HOW? JUST HOW? 🤯",
            "ALMOST TALENT 🙃",
            "UNIQUE SKILLSET 🤡",
            "CAR BEGS MERCY 🚗",
            "YOU'RE DOING GREAT 🙂",
            "STILL? PATHETIC 🙄",
            "WORLD RECORD FAIL 🏆"
          ],
          "dead": [
            "WELL DESERVED 👏",
            "SKILL ISSUE 🤦",
            "TOLD YOU 🙄",
            "TAKE THE BUS 🚗",
            "NICE DRIVING 💀",
            "CAREER OVER ⚰️",
            "LEGENDARY FAIL 💥",
            "UNINSTALL 🪦"
          ]
        },
        "chaotic": {
          "safe": [
            "VROOOM 🏎️",
            "YEEHAW 🤠",
            "FULL SEND! 🏎️",
            "WHEEE 🎢",
            "LET'S GOOO 🚀",
            "NO BRAKES! 🚗",
            "ZOOM ZOOM 🏎️",
            "YAHOO! 🎉"
          ],
          "caution": [
            "WAIT WHAT 😳",
            "HUH?! 😬",
            "WHO DID THAT 👀",
            "EEEK 😖",
            "WOAH WOAH 😲",
            "WHAT WAS THAT 😳",
            "OOPS? 😅",
            "ACK! 🫣"
          ],
          "danger": [
            "OH GOD 😱",
            "ABORT ABORT 😱",
            "WHAT IS HAPPENING 😱",
            "MAYDAY! 🚨",
            "EVERYTHING HURTS 🤕",
            "AAAAH 😱",
            "WHY IS IT SPINNING 😖",
            "FIRE?! 🔥"
          ],
          "severe": [
            "NO NO NO 😫",
            "HELP 🆘",
            "ALARMS EVERYWHERE 🚨",
            "PULL UP PULL UP 🪂",
            "WHERE ARE THE BRAKES 🚗",
            "I CAN'T SEE 👀",
            "AAAAAAAH 😱",
            "RED ALERT 🚨"
          ],
          "extreme": [
            "AAAAAAAAA 😱",
            "EJECT EJECT 🪂",
            "SYSTEM MELTDOWN 📡",
            "EVERYTHING IS ON FIRE 🔥",
            "WHAT WHY HOW 🤯",
            "OH NONONONO 😫",
            "SOMEBODY DO SOMETHING 🆘",
            "HOLY— 😱"
          ],
          "dead": [
            "KABOOM 💥",
            "WELP. 🫠",
            "SPLAT 🫓",
            "ERROR 404: CAR 📡",
            "CHAOS WON 🌀",
            "BOOM. 💥",
            "CRASH.EXE 📡",
            "...WHAT 😶"
          ]
        },
        "deadpan": {
          "safe": [
            "FINE. ✅",
            "ACCEPTABLE. 🙂",
            "ADEQUATE. 😐",
            "NO COMPLAINTS. ✅",
            "TOLERABLE. 😐",
            "UNREMARKABLE. 😑",
            "IT'S A CAR. 🚗",
            "GOING. 😐"
          ],
          "caution": [
            "HM. 🤔",
            "NOTED. 🤔",
            "INTERESTING. 🤔",
            "SLIGHTLY WORSE. 🤨",
            "WELL THEN. 🤔",
            "THAT HAPPENED. 🟡",
            "LESS FINE. 😐",
            "OKAY. 😐"
          ],
          "danger": [
            "NOT IDEAL. ⚠️",
            "THAT'S A PROBLEM. 😨",
            "UNFORTUNATE. 😑",
            "CONCERNING. 😐",
            "SUBOPTIMAL. 🟠",
            "DISAPPOINTING. 😒",
            "HOW NICE. 🙂",
            "LOVELY. 🙂"
          ],
          "severe": [
            "THIS SEEMS BAD. 😨",
            "QUITE BROKEN. 😑",
            "PROBABLY FINE. 🙂",
            "MILDLY FATAL. 😵‍💫",
            "IT'S FINE. 🙂",
            "AS EXPECTED. 😑",
            "REGRETTABLE. 😣",
            "HOW TYPICAL. 😒"
          ],
          "extreme": [
            "STILL HERE. SOMEHOW. 😑",
            "BARELY. 😵",
            "STATISTICALLY RUDE. 📊",
            "IMPRESSIVE, I GUESS. 👏",
            "ONE PERCENT. NEAT. 👍",
            "CLOSE ENOUGH. 🤷",
            "MORE OR LESS. 🤷",
            "ANY SECOND. ⏳"
          ],
          "dead": [
            "EXPECTED. 😑",
            "AND THAT'S THAT. 🫡",
            "CAR: NO. 🚗",
            "GREAT. 👍",
            "SHOCKING. NOT. 😑",
            "COMPLETE. ✔️",
            "OK. 👍",
            "END. 😶"
          ]
        },
        "commentator": {
          "safe": [
            "FLAWLESS SO FAR! ✨",
            "WHAT A DRIVE! 🏎️",
            "HE'S IN CONTROL! ✅",
            "BEAUTIFUL LINE! 🏎️",
            "TEXTBOOK! ✨",
            "CLEAN AS YOU LIKE! ✨",
            "LOOK AT HIM GO! 👀",
            "PERFECT START! ✨"
          ],
          "caution": [
            "A LITTLE SCRAPE! 🎙️",
            "HE'S TAKEN A HIT! 🎙️",
            "DAMAGE REPORTED! 📋",
            "HE'LL FEEL THAT! 🫣",
            "SLIGHT WOBBLE! 🎙️",
            "CAN HE RECOVER? 😬",
            "HE'S RATTLED! 👀",
            "CONTACT! 💥"
          ],
          "danger": [
            "HE'S IN TROUBLE! 😨",
            "THIS IS CLOSE! 😧",
            "BIG DAMAGE! 😖",
            "HE'S LOSING IT! 🫨",
            "OH HE'S HURT! 🤕",
            "WHAT A HIT! 😨",
            "SMOKE FROM THE CAR! 💨",
            "HE'S STRUGGLING! 🥵"
          ],
          "severe": [
            "HE'S STILL IN IT! 🎙️",
            "CAN HE HOLD ON?! ✊",
            "UNBELIEVABLE! 🤯",
            "SERIOUS DAMAGE! 💢",
            "IT'S FALLING APART! 🫨",
            "WHAT A DISASTER! 😱",
            "THE CROWD GASPS! 🏁",
            "HANGING ON! 😵‍💫"
          ],
          "extreme": [
            "HE'S BARELY ALIVE! 😵",
            "CAN HE SURVIVE?! 🎙️",
            "WHAT A SAVE! 🧤",
            "YOU CANNOT SCRIPT THIS! 🏁",
            "INCREDIBLE SCENES! 🏁",
            "ON A KNIFE'S EDGE! 😵",
            "STILL MOVING! 🏎️",
            "HISTORY IN THE MAKING! 📖"
          ],
          "dead": [
            "IT'S ALL OVER! ⚰️",
            "AND HE'S OUT! 🏁",
            "RETIRED! 🏁",
            "THAT'S THE END! 🎬",
            "DNF! 🏁",
            "WHAT A FINISH! 🏁",
            "HEARTBREAK! 😭",
            "NO WAY BACK! 🏁"
          ]
        },
        "horror": {
          "safe": [
            "TOO QUIET... 🤫",
            "SOMETHING WATCHES 👁️",
            "DON'T RELAX 👁️",
            "FOR NOW... 🕯️",
            "IT WAITS 🕸️",
            "STILL ALONE? 🕯️",
            "DON'T LOOK BACK 👀",
            "IT'S CALM. TOO CALM. 🤫"
          ],
          "caution": [
            "DID YOU HEAR THAT? 👂",
            "IT'S CLOSER 👣",
            "SOMETHING'S WRONG 😨",
            "THE LIGHTS FLICKER 👁️",
            "DON'T STOP 🏃",
            "FOOTSTEPS... 🏃",
            "IT SAW YOU 👀",
            "COLD AIR 🧊"
          ],
          "danger": [
            "RUN. 🏃",
            "IT'S HERE 👹",
            "NO ESCAPE 🏃",
            "THEY'RE COMING 👣",
            "DON'T SCREAM 🤐",
            "HIDE 🏃",
            "THE DOORS ARE LOCKED 🚪",
            "IT FOUND YOU 👁️"
          ],
          "severe": [
            "IT'S TOO LATE ⏳",
            "THE END IS NEAR 🕯️",
            "BEHIND YOU 🏃",
            "NOWHERE TO HIDE 🏃",
            "CAN'T GET OUT ⏳",
            "IT'S INSIDE 🕷️",
            "THE DARK TAKES 🌑",
            "SILENCE FALLS 🌑"
          ],
          "extreme": [
            "LAST CHANCE ⏳",
            "ONE BREATH LEFT 🕯️",
            "IT'S SMILING 😈",
            "DON'T MOVE 🤐",
            "IT'S RIGHT THERE 💔",
            "TOO CLOSE 🩸",
            "CAN'T WAKE UP ⏳",
            "THE CLOCK STOPS ⏳"
          ],
          "dead": [
            "NO ONE SURVIVES 🕯️",
            "CONSUMED 🕳️",
            "THE DARK WINS 🌑",
            "NEVER SEEN AGAIN ⚰️",
            "IT'S OVER 🕯️",
            "GOODNIGHT 🌑",
            "SILENCE 🌑",
            "TAKEN ⚰️"
          ]
        },
        "action": {
          "safe": [
            "LOCKED AND LOADED 🔫",
            "LET'S ROLL 🚀",
            "HERE WE GO! 🚀",
            "PEDAL DOWN 🏎️",
            "MISSION START 🎯",
            "GEAR UP 🎯",
            "HIT IT! 🏎️",
            "ENGINES HOT 🔥"
          ],
          "caution": [
            "INCOMING! 🎯",
            "EVASIVE! 🔄",
            "HEADS UP! 😬",
            "WE'VE GOT COMPANY 🎯",
            "TAKE COVER 🎯",
            "STAY ON TARGET 🎯",
            "PUNCH IT! 🏎️",
            "MOVE MOVE! 🏃"
          ],
          "danger": [
            "HANG ON! ✊",
            "IMPACT INCOMING 💥",
            "WE'RE HIT! 😨",
            "GO GO GO! 🏎️",
            "HOLD IT TOGETHER ✊",
            "SHE CAN'T TAKE MUCH 🟠",
            "DAMAGE CONTROL! 😧",
            "PUSH THROUGH! 😖"
          ],
          "severe": [
            "BRACE FOR IMPACT 💥",
            "NOT TODAY 🛡️",
            "HOLD ON TIGHT! ✊",
            "SHE'S BREAKING UP 🚨",
            "ALL OR NOTHING 🎲",
            "ENGINE FAILING! 🚗",
            "DON'T QUIT NOW 💪",
            "TOO HOT! 🔥"
          ],
          "extreme": [
            "ONE LAST RUN 🏃",
            "YIPPEE-KI-YAY 🤠",
            "SAY YOUR PRAYERS 😎",
            "MAKE IT COUNT 🎯",
            "FINAL STAND 😵",
            "JUMP! 🪂",
            "IT'S NOW OR NEVER 😵",
            "THIS ENDS NOW ⚔️"
          ],
          "dead": [
            "MISSION FAILED 🎯",
            "BOOM. 💥",
            "TARGET DOWN 🎯",
            "WE LOST HER 🕊️",
            "OUT OF ACTION 🚫",
            "KIA 🎯",
            "SIGNAL LOST 📡",
            "HASTA LA VISTA 😎"
          ]
        },
        "arcade": {
          "safe": [
            "FULL HEALTH ❤️‍🩹",
            "PLAYER 1 READY 🎮",
            "COMBO x3 🍄",
            "PERFECT! ✨",
            "HIGH SCORE! 🏆",
            "BONUS STAGE 🍄",
            "POWER UP! 🍄",
            "1UP 🍄"
          ],
          "caution": [
            "WARNING! 🚨",
            "HP DROPPING ❤️‍🩹",
            "SHIELD DOWN 🛡️",
            "TAKE COVER! 🎯",
            "ARMOR LOW 🛡️",
            "COMBO LOST 🍄",
            "-100 PTS 🏆",
            "HIT! 💥"
          ],
          "danger": [
            "DANGER! 🚨",
            "LOW HP ❤️‍🩹",
            "HEALTH LOW ❤️‍🩹",
            "BOSS ATTACK! 👾",
            "DODGE! 💨",
            "NEED HEALTH ❤️‍🩹",
            "COMBO BREAKER 🍄",
            "OUCH! -250 🤕"
          ],
          "severe": [
            "CRITICAL! ⚠️",
            "LAST LIFE 🍄",
            "HP RED ❤️‍🩹",
            "FIND A MEDKIT ❤️‍🩹",
            "BEEP BEEP BEEP 🚨",
            "LOW BATTERY 🪫",
            "TIME RUNNING OUT ⏳",
            "HEALTH CRITICAL ❤️‍🩹"
          ],
          "extreme": [
            "1 HP LEFT ❤️‍🩹",
            "EXTRA LIFE? 🍄",
            "CONTINUE? 🎮",
            "INSERT COIN 🪙",
            "9... 8... 7... ⏳",
            "FINAL LIFE 🍄",
            "POWER UP NEEDED 🍄",
            "LAST HIT POINT ❤️‍🩹"
          ],
          "dead": [
            "GAME OVER 🎮",
            "YOU LOSE 🎮",
            "TRY AGAIN? 🎮",
            "NO LIVES LEFT 🪦",
            "PLAYER 1 DOWN 🎮",
            "CONTINUE? NO 🎮",
            "K.O. 🎮",
            "THANKS FOR PLAYING 🎮"
          ]
        },
        "genz": {
          "safe": [
            "LOWKEY GOATED 🐐",
            "IT'S GIVING SAFE ✅",
            "NO CAP WE GOOD ✅",
            "MAIN CHARACTER 💅",
            "SLAY 💅",
            "UNBOTHERED 😌",
            "RENT FREE 🏠",
            "ATE THAT 💅"
          ],
          "caution": [
            "LOWKEY SUS 🤨",
            "NOT THE VIBE 😒",
            "IT'S GIVING RISK 😬",
            "BRO... 😐",
            "HOLD UP FR ✊",
            "SLIGHTLY TWEAKING 👀",
            "UMM OK 😶",
            "RED FLAG 🚩"
          ],
          "danger": [
            "NAH THIS IS WILD 😳",
            "NOT GOOD FR 😟",
            "WE'RE TWEAKING 🫨",
            "THIS AIN'T IT ⚠️",
            "BRO WHY 😩",
            "HIGHKEY BAD 😨",
            "NO BECAUSE WHY 😭",
            "IT'S GIVING DOOM ☠️"
          ],
          "severe": [
            "BRO IS COOKED 💀",
            "WE'RE SO DONE 😩",
            "AIN'T NO WAY 🤯",
            "I'M CRASHING OUT 🫨",
            "NAHHH FR 😭",
            "IT'S JOEVER-ISH 😬",
            "DELULU TO SURVIVE 🦄",
            "BRO... 😐"
          ],
          "extreme": [
            "HOW IS BRO ALIVE 🤯",
            "ON GOD 1% 😵",
            "IT'S GIVING MIRACLE 🙏",
            "BRO REFUSES TO DIE 🧟",
            "LITERALLY SHAKING 😰",
            "NO CAP HOW 🤯",
            "CAN'T BE REAL 🤯",
            "UNREAL AURA ✨"
          ],
          "dead": [
            "IT'S JOEVER 🪦",
            "BRO IS COOKED 🍳",
            "WE'RE SO DONE 😩",
            "MASSIVE L 🪦",
            "AURA -1000 📉",
            "NO SHOT 🙅",
            "IT'S OVER FR ☠️",
            "RIP BRO 💀"
          ]
        },
        "minimal": {
          "safe": [
            "SAFE ✅",
            "STABLE ✅",
            "NOMINAL ✅",
            "OK ✅",
            "CLEAR ✅",
            "SECURE ✅",
            "GOOD ✅",
            "NORMAL ✅"
          ],
          "caution": [
            "CAUTION ⚠️",
            "WARNING 🚨",
            "ALERT 🚨",
            "MINOR DAMAGE ⚠️",
            "UNSTABLE 🟡",
            "CHECK ⚠️",
            "NOTICE 👀",
            "WATCH 👀"
          ],
          "danger": [
            "DANGER 🚨",
            "DAMAGED ⚠️",
            "HIGH RISK ⚠️",
            "SEVERE 🟠",
            "UNSAFE ⚠️",
            "BREACH ⚠️",
            "FAILING ⚠️",
            "HAZARD 🚨"
          ],
          "severe": [
            "CRITICAL ⚠️",
            "BREAKING 🚨",
            "EMERGENCY 🚨",
            "CRITICAL DAMAGE ⚠️",
            "IMMINENT ⚠️",
            "SYSTEM FAILING 📡",
            "LOW INTEGRITY 🔴",
            "RED 🔴"
          ],
          "extreme": [
            "MINIMAL ⚪",
            "FINAL ⏳",
            "LAST ⏳",
            "1% LEFT ⏳",
            "NEAR FAILURE ⚠️",
            "BARELY ⏳",
            "LIMIT ⚠️",
            "EDGE ⚠️"
          ],
          "dead": [
            "TOTALLED 🪦",
            "DESTROYED 🪦",
            "FAILED ⚰️",
            "OFFLINE 📡",
            "NO CHANCE ❌",
            "ZERO ⭕",
            "ENDED ⚰️",
            "LOST ❌"
          ]
        },
        "darkhumor": {
          "safe": [
            "ENJOY IT WHILE IT LASTS 😌",
            "NOT DEAD YET 😮‍💨",
            "SPARE PARTS: 0 NEEDED 🧩",
            "INSURANCE SMILES 💸",
            "MECHANIC IS SAD 🚗",
            "SO FAR SO ALIVE 🙂",
            "COFFIN ON HOLD 💀",
            "LIFE IS GOOD 😌"
          ],
          "caution": [
            "CALL THE MECHANIC 🚗",
            "PARTS FALLING OFF? 🧩",
            "WRITE YOUR WILL? 📝",
            "TOW TRUCK ON STANDBY 🚗",
            "THAT'S EXPENSIVE 💸",
            "SCRAPYARD WAVES 👋",
            "HEARSE WARMING UP 💀",
            "PRAY FOR PAINT 🙏"
          ],
          "danger": [
            "THAT WENT WELL... 🙃",
            "CAR IS CRYING 🚗",
            "PARTS EVERYWHERE 🧩",
            "SCRAPYARD CALLING 📞",
            "RIP BUMPER 💀",
            "FUNERAL BOOKED? 💀",
            "PIECE BY PIECE 🧩",
            "WHO NEEDS DOORS 🚪"
          ],
          "severe": [
            "WELL, THAT'S IT 💀",
            "PICK A COFFIN 💀",
            "FLOWERS ORDERED 💐",
            "IT WAS A GOOD CAR 🚗",
            "EULOGY LOADING 💀",
            "HALF A CAR 🚗",
            "CAR.EXE DYING 📡",
            "TELL MY WIFE... 💌"
          ],
          "extreme": [
            "SAY GOODBYE 👋",
            "ZOMBIE CAR 👻",
            "BORROWED TIME ⏳",
            "ALIVE-ISH 🧟",
            "WALKING DEAD 💀",
            "ONE FOOT IN SCRAP 🚗",
            "GHOST MODE 👻",
            "DEATH IS WAITING 💀"
          ],
          "dead": [
            "REST IN PIECES 🧩",
            "SEE YOU NEXT RUN 👋",
            "GOODBYE 👋",
            "LEGO SET NOW 🧩",
            "BOX OF PARTS 🧩",
            "SCRAP METAL 🚗",
            "PAID IN PIECES 💸",
            "ORGAN DONOR 💀"
          ]
        },
        "optimistic": {
          "safe": [
            "WE GOT THIS ✅",
            "BEAUTIFUL DAY 😌",
            "SMOOTH SAILING 😌",
            "LIVING THE DREAM 💯",
            "PERFECT! ✨",
            "SO PROUD 💪",
            "KEEP IT UP! 💪",
            "YOU'RE AMAZING 💪"
          ],
          "caution": [
            "STILL GREAT! 💪",
            "JUST A SCRATCH 🩹",
            "TOTALLY FINE! ✅",
            "BARELY NOTICED 😊",
            "KEEP GOING ✊",
            "WE'RE OKAY! 😊",
            "NO BIG DEAL 😊",
            "STAY POSITIVE 🌈"
          ],
          "danger": [
            "STILL POSSIBLE! ✨",
            "WE CAN FIX THIS 🔧",
            "HALF FULL! 🥛",
            "CHIN UP! 💪",
            "DON'T GIVE UP 💪",
            "PLENTY LEFT! 😊",
            "COMEBACK TIME 🔥",
            "BELIEVE! 🙏"
          ],
          "severe": [
            "NOT OVER YET 💪",
            "MIRACLES HAPPEN 🌈",
            "STAY STRONG! 💪",
            "STILL MOVING! 🏎️",
            "EVERY % COUNTS 💯",
            "YOU CAN DO IT! 💪",
            "THINK POSITIVE 💭",
            "HOPE LIVES 🙏"
          ],
          "extreme": [
            "BELIEVE! 🙏",
            "1% IS ENOUGH! 😵",
            "STILL ALIVE = WIN 🏆",
            "ANYTHING'S POSSIBLE 🌟",
            "LEGENDS DO THIS 🌟",
            "COMEBACK LOADING 🔋",
            "NEVER SURRENDER 💪",
            "WE'RE SO BACK 🏆"
          ],
          "dead": [
            "MAYBE NEXT TIME 🤞",
            "ALMOST... 🥲",
            "GOOD TRY 👍",
            "YOU DID GREAT 💪",
            "LEARNING EXPERIENCE 📚",
            "PROUD OF YOU 💪",
            "TRY AGAIN! 🎮",
            "SO CLOSE! 🥲"
          ]
        },
        "pessimistic": {
          "safe": [
            "I DON'T LIKE THIS 🤨",
            "TOO GOOD TO BE TRUE 🤨",
            "IT WON'T LAST ⌛",
            "SOMETHING'S OFF 🤨",
            "SUSPICIOUS 🤨",
            "HERE IT COMES 😒",
            "ANY MOMENT NOW ⏳",
            "DON'T JINX IT 🤨"
          ],
          "caution": [
            "SEE? STARTING 😒",
            "SOMETHING'S WRONG 😨",
            "KNEW IT 🙄",
            "DOWNHILL FROM HERE 📉",
            "HERE WE GO AGAIN 😒",
            "OF COURSE 😒",
            "TOLD YOU SO 🙄",
            "TYPICAL 🤨"
          ],
          "danger": [
            "THIS WON'T END WELL 😒",
            "DOOMED FROM START ☠️",
            "WHAT DID I SAY 🙄",
            "NO SURPRISE 😒",
            "INEVITABLE ☠️",
            "WORST CASE: NOW ☠️",
            "IT ONLY GETS WORSE 😰",
            "WHY DO WE TRY 😩"
          ],
          "severe": [
            "YEP. WE'RE DONE. 😒",
            "SAW IT COMING 🙄",
            "POINTLESS 😮‍💨",
            "SAVE THE REPLAY 🎥",
            "WHY BOTHER 😮‍💨",
            "WRITTEN IN STONE 🪨",
            "COUNTING DOWN ⏳",
            "ACCEPT IT 😮‍💨"
          ],
          "extreme": [
            "JUST END IT 😩",
            "PROLONGING PAIN 😩",
            "ALIVE? NOT FOR LONG ⌛",
            "DELAYING THE END ⌛",
            "ANY SECOND NOW ⏳",
            "DON'T GET HOPEFUL 😒",
            "THIS IS DUMB 😮‍💨",
            "SIGH. 😮‍💨"
          ],
          "dead": [
            "CALLED IT. 🙄",
            "TOLD YOU. 🙄",
            "OBVIOUSLY. 🙄",
            "AS PREDICTED 🙄",
            "WHO'S SURPRISED? 🤷",
            "NOBODY. 🤷",
            "SAME AS ALWAYS 🪦",
            "I KNEW IT. 🙄"
          ]
        },
        "overconfident": {
          "safe": [
            "EASY 😎",
            "LIGHT WORK 😎",
            "I GOT THIS 😎",
            "ZERO PROBLEM 😎",
            "TOO GOOD 😎",
            "NO ONE CAN STOP ME 😎",
            "BUILT DIFFERENT 😎",
            "UNKILLABLE 😎"
          ],
          "caution": [
            "STILL EASY... 😎",
            "OKAY... 🫣",
            "MEANT TO DO THAT 😏",
            "WARM-UP ONLY 😏",
            "STILL WINNING 🏆",
            "TOTALLY PLANNED 🤡",
            "A SCRATCH. PFF. 😏",
            "WAIT A SECOND... 🤨"
          ],
          "danger": [
            "MAYBE NOT... 😅",
            "HMM. OKAY. 🤔",
            "STILL FINE. PROBABLY 😅",
            "THAT WAS LAG 🤡",
            "NOT MY FAULT 🤡",
            "UH... PLANNED? 🤡",
            "LET ME COOK 🍳",
            "ALMOST CALCULATED 🤡"
          ],
          "severe": [
            "I TAKE IT BACK 🫠",
            "WE HAVE A PROBLEM 😨",
            "SLIGHT MISTAKE 🫠",
            "OKAY THAT HURT 🤕",
            "NOT SO EASY 😅",
            "I MAY HAVE LIED 😅",
            "HUMBLED 🫠",
            "HELP? JUST ASKING 🆘"
          ],
          "extreme": [
            "OKAY I LIED. 🫠",
            "MAYBE NOT. 😬",
            "WE'RE COOKED. 🍳",
            "I'M SORRY 🫠",
            "NEVER AGAIN 🫠",
            "EGO: DESTROYED 🫠",
            "WHO SAID EASY? 😅",
            "PLEASE HOLD 😫"
          ],
          "dead": [
            "I LIED. 🫠",
            "WE'RE COOKED. 🍳",
            "HUMBLED. 🫠",
            "LESSON LEARNED 📚",
            "NEVER SPEAKING AGAIN 🪦",
            "DON'T SAY IT 🤐",
            "OKAY. FAIR. 🫠",
            "EGO: 0% 🫠"
          ]
        },
        "panic": {
          "safe": [
            "WE'RE GOOD ✅",
            "ALL GOOD ✅",
            "FINE, TOTALLY FINE ✅",
            "RELAXED 😌",
            "CALM 😌",
            "NO WORRIES 😌",
            "BREATHING NORMAL 👌",
            "CHILL 😌"
          ],
          "caution": [
            "WAIT... 😳",
            "HOLD ON... ✊",
            "UM... 🤔",
            "WAS THAT BAD? 😨",
            "OKAY OKAY 👀",
            "STAY CALM 😌",
            "BREATHE... 😮‍💨",
            "IT'S FINE? 😅"
          ],
          "danger": [
            "WAIT WAIT 😳",
            "NO NO 😫",
            "OH NO 😨",
            "NOT GOOD NOT GOOD 😟",
            "WHAT DO I DO 😰",
            "STAY CALM STAY CALM 😰",
            "OKAY PANIC 😱",
            "UH OH UH OH 😨"
          ],
          "severe": [
            "NO NO NO 😫",
            "STOP STOP STOP 😫",
            "PLEASE PLEASE 😫",
            "WHY WHY WHY 😱",
            "HELP HELP 🆘",
            "I CAN'T 😩",
            "NONONO 😫",
            "MAKE IT STOP 😫"
          ],
          "extreme": [
            "NO NO NO NO 💀",
            "HELP 😭",
            "PLEASE PLEASE PLEASE 😫",
            "STOP STOP STOP 😫",
            "AAAAAA 😱",
            "I'M GONNA CRY 😭",
            "NONONONONO 😫",
            "MOMMY 😭"
          ],
          "dead": [
            "NOOOOOO 😭",
            "WHY 😭",
            "I'M SHAKING 😰",
            "IT'S GONE 😭",
            "NO NO... IT'S OVER 😫",
            "I CAN'T BREATHE 😵",
            "SOBBING 😭",
            "WHAT HAPPENED 😭"
          ]
        },
        "storyteller": {
          "safe": [
            "IT BEGAN SO WELL... 🎬",
            "HE FELT UNSTOPPABLE 🌤️",
            "EVERYTHING WAS FINE ✅",
            "IT WAS A GOOD DAY ✅",
            "FOR NOW... 🕯️",
            "NOBODY SAW IT COMING 🌤️",
            "LITTLE DID HE KNOW 🕰️",
            "HE WAS SO SURE 🌤️"
          ],
          "caution": [
            "HE HAD NO IDEA... 🕰️",
            "THEN IT HAPPENED ⚠️",
            "THE FIRST MISTAKE ⚠️",
            "SOMETHING CHANGED 🌫️",
            "A SMALL CRACK 🪟",
            "HE IGNORED IT ⚠️",
            "THAT WAS THE SIGN 👁️",
            "AND THEN... 🕰️"
          ],
          "danger": [
            "THINGS GOT WORSE... ⛈️",
            "IT SPIRALED ⚠️",
            "HE COULDN'T STOP IT 😫",
            "THE TRUTH HIT HARD ⚡",
            "NO TURNING BACK ⛓️",
            "PANIC SET IN 😱",
            "HE KNEW IT THEN ⚡",
            "THE ROAD TURNED 🛣️"
          ],
          "severe": [
            "THIS WAS THE MOMENT... 🌪️",
            "EVERYTHING FELL APART 🚨",
            "HE HELD ON ✊",
            "ONE LAST HOPE 🙏",
            "THE END WAS NEAR 🎬",
            "HE PRAYED 🙏",
            "TIME SLOWED DOWN ⏳",
            "NOBODY BREATHED ⏳"
          ],
          "extreme": [
            "AGAINST ALL ODDS... 🌟",
            "HE REFUSED TO QUIT ✊",
            "ONE HIT FROM LEGEND 🌟",
            "HISTORY WATCHED 📖",
            "THE FINAL CHAPTER 📖",
            "ONE LAST BREATH... 😵",
            "WOULD HE MAKE IT? 🕯️",
            "AND THEN... 🕰️"
          ],
          "dead": [
            "IT WAS TOO LATE... 🎬",
            "THE END. 🎬",
            "AND THAT WAS IT ⚰️",
            "HE NEVER MADE IT 🕯️",
            "THE STORY ENDS 📖",
            "A TRAGIC ENDING 😭",
            "THEY STILL TALK ABOUT IT ⚰️",
            "SO IT ENDED 🕯️"
          ]
        },
        "clickbait": {
          "safe": [
            "100% PERFECT?! ✨",
            "YOU WON'T BELIEVE THIS 😱",
            "WATCH WHAT HAPPENS 👀",
            "BEST RUN EVER?! 🏆",
            "NO DAMAGE?! 💯",
            "WORLD RECORD?! 🏆",
            "IS THIS REAL?! 😲",
            "NOT CLICKBAIT ❗"
          ],
          "caution": [
            "WAIT FOR IT! ⏳",
            "SHOCKING! 🤯",
            "THIS CHANGES EVERYTHING 😱",
            "UH OH?! 😨",
            "WHAT?! 🤯",
            "(GONE WRONG) 😨",
            "UNEXPECTED! 🤔",
            "FIRST HIT?! 😬"
          ],
          "danger": [
            "GONE WRONG! 😨",
            "EMOTIONAL! 😭",
            "DISASTER?! 😱",
            "(NOT CLICKBAIT) ❗",
            "CAUGHT ON CAMERA 🎥",
            "HALF GONE?! 😱",
            "INSANE! 🤯",
            "OMG!! 🤯"
          ],
          "severe": [
            "SCARIEST MOMENT! 🚨",
            "CAN IT SURVIVE?! 😱",
            "YOU WON'T BELIEVE 😱",
            "10%?! 😱",
            "3AM CHALLENGE?! 🌙",
            "GONE SUPER WRONG 😨",
            "CRAZIEST EVER 🤯",
            "WATCH TILL END 👀"
          ],
          "extreme": [
            "IMPOSSIBLE?! 🤯",
            "1%?! 😵",
            "MIRACLE?! 🙏",
            "SCIENCE CAN'T EXPLAIN 🧪",
            "NOBODY SURVIVES THIS 😱",
            "WORLD'S LUCKIEST 🍀",
            "INSANE CLUTCH?! 🤯",
            "UNBELIEVABLE!! 🤯"
          ],
          "dead": [
            "0%?! 😱",
            "IT'S DESTROYED! 🪦",
            "(EMOTIONAL) 😭",
            "I CAN'T BELIEVE IT 😭",
            "RIP?! 💀",
            "IT FINALLY HAPPENED 😱",
            "GONE FOREVER! ❌",
            "SHOCKING ENDING 🤯"
          ]
        },
        "brainrot": {
          "safe": [
            "SKIBIDI SAFE 🚽",
            "RIZZ LEVEL MAX 💅",
            "SIGMA DRIVING 🗿",
            "GYATT DAMN CLEAN 💅",
            "MEWING AT 100% 🗿",
            "AURA +9999 ✨",
            "OHIO? NOT TODAY 🧠",
            "FANUM TAX FREE 🍟"
          ],
          "caution": [
            "OHIO MOMENT 🧠",
            "AURA -100 📉",
            "LOW TAPER FADE? 💈",
            "NOT VERY SIGMA 🗿",
            "RIZZ DROPPING 💅",
            "EDGING DANGER 😬",
            "SUS AMOGUS 🤨",
            "BUSSIN? NO 🤢"
          ],
          "danger": [
            "OHIO FINAL BOSS 🧠",
            "AURA DEBT 📉",
            "SKIBIDI DAMAGE 🚽",
            "FANUM TAXED 🍟",
            "BRAIN = 404 🧠",
            "RIZZ BANKRUPT 💅",
            "GRIMACE SHAKE 🥤",
            "MOG'D BY WALL 🗿"
          ],
          "severe": [
            "BRAINROT CRASH 🧠",
            "SKIBIDI DOOMED 🚽",
            "NPC MELTDOWN 🤖",
            "AURA NEGATIVE 📉",
            "OHIO FOREVER 🧠",
            "CAR GOT FANUM'D 🍟",
            "BUGGED OUT 📡",
            "L RIZZ 📉"
          ],
          "extreme": [
            "1% SIGMA 🗿",
            "BRO IS MEWING 🗿",
            "AURA FARMING 🌾",
            "SKIBIDI MIRACLE 🚽",
            "HOW BRO ALIVE 🤯",
            "BEYOND OHIO 🧠",
            "GLITCH IN MATRIX 📡",
            "BRAIN FULLY ROTTED 🧠"
          ],
          "dead": [
            "SKIBIDI TOILETED 🚽",
            "OHIO WON 🧠",
            "AURA 0 📉",
            "COOKED ×1000 🍳",
            "FANUM TAXED 100% 🍟",
            "BRAIN ROTTED 🧠",
            "SIGMA DIED 💀",
            "GYATT DAMN OVER 💀"
          ]
        }
      };
      var SURVIVAL_LEVELS = ['safe','caution','danger','severe','extreme','dead'];
      scope.survivalPackNames = ["cinematic", "dramatic", "streamer", "youtube", "meme", "savage", "chaotic", "deadpan", "commentator", "horror", "action", "arcade", "genz", "minimal", "darkhumor", "optimistic", "pessimistic", "overconfident", "panic", "storyteller", "clickbait", "brainrot", "custom"];
      scope.survivalPackLabels = {"cinematic": "Cinematic", "dramatic": "Dramatic", "streamer": "Streamer", "youtube": "YouTube", "meme": "Meme", "savage": "Savage", "chaotic": "Chaotic", "deadpan": "Deadpan", "commentator": "Commentator", "horror": "Horror", "action": "Action Movie", "arcade": "Arcade", "genz": "Gen Z / Internet", "minimal": "Clean / Minimal", "darkhumor": "Dark Humor", "optimistic": "Optimistic", "pessimistic": "Pessimistic", "overconfident": "Overconfident", "panic": "Panic", "storyteller": "Storyteller", "clickbait": "Clickbait", "brainrot": "Brainrot", "custom": "Custom"};

      // Niveli i frazës nga përqindja (i pavarur nga pragjet e ngjyrave)
      scope.survivalPhraseLevel = function() {
        var v = Number(scope.survivalVisualValue()) || 0;
        if (v <= 0) return 'dead';
        var r = Math.ceil(v);
        if (r <= 5) return 'extreme';
        if (r <= 25) return 'severe';
        if (r <= 50) return 'danger';
        if (r <= 75) return 'caution';
        return 'safe';
      };

      // Zgjedhje e rastësishme pa përsëritje të menjëhershme, stabile brenda nji intervali 3s
      var phraseCache = { key:null, text:'', last:{} };

      // v5.8.0: +8 fraza per nivel ne cdo stil (pa perseritje)
      (function(){ var EXTRA = {"cinematic": {"safe": ["THE ROAD IS OURS", "NOTHING BUT OPEN ROAD", "SMOOTH AS SILK", "THE CITY SLEEPS", "ONE MAN, ONE ROAD", "PERFECT TAKE", "GOLDEN HOUR 🌅", "NOT A SCRATCH"], "caution": ["THE AIR CHANGES", "A SHADOW FALLS", "TENSION RISING", "THE MUSIC SHIFTS", "FIRST CRACKS", "KEEP IT TOGETHER", "SLOW MOTION...", "THE PLOT THICKENS"], "danger": ["THE STORM ARRIVES", "NO MORE MARGIN", "BREAKING POINT", "EVERY SECOND COUNTS", "THE WALLS CLOSE IN", "HOLD THE LINE", "SPARKS FLY", "LOSING THE LIGHT"], "severe": ["FINAL ACT", "LAST STAND", "RUNNING ON FUMES", "BARELY BREATHING", "THE CURTAIN SHAKES", "ONE MORE SCENE", "FADING...", "ALL OR NOTHING"], "extreme": ["FINAL FRAME", "LAST HEARTBEAT", "HOLD YOUR BREATH", "THE LIGHTS FLICKER", "ONE LAST SHOT", "SILENCE FALLS", "CUT TO BLACK?", "THIN AIR"], "dead": ["FADE TO BLACK", "ROLL CREDITS", "THE END.", "SCENE OVER", "CURTAIN CALL", "NO SEQUEL", "THAT'S A WRAP", "LIGHTS OUT"]}, "dramatic": {"safe": ["A HERO RISES", "DESTINY SMILES", "GLORY AWAITS", "FATE IS KIND", "UNBREAKABLE SPIRIT", "THE LEGEND BEGINS", "NOBLE MACHINE", "PEACE, FOR NOW"], "caution": ["A DARK OMEN", "FATE STIRS", "THE FIRST BETRAYAL", "WHISPERS OF RUIN", "THE GODS FROWN", "A WOUND OPENS", "PRIDE BEFORE THE FALL", "TROUBLE BREWS"], "danger": ["SUFFERING BEGINS", "THE TRAGEDY UNFOLDS", "BLEEDING STEEL", "ANGUISH!", "THE HEAVENS WEEP", "NO MERCY GIVEN", "HOW DID IT COME TO THIS", "BROKEN BUT STANDING"], "severe": ["FORSAKEN!", "THE HERO FALTERS", "ALL HOPE FADES", "A CRUEL FATE", "TORN APART", "THE FINAL SORROW", "WHY, FATE, WHY?!", "ON BENDED KNEE"], "extreme": ["THE LAST BREATH!", "DESTINY CALLS", "NOOOOO!", "THE FINAL CRY", "FAREWELL, OLD FRIEND", "HEART OF STEEL, BREAKING", "ONE LAST PRAYER", "IT CANNOT END LIKE THIS"], "dead": ["A TRAGIC END", "FALLEN HERO", "GONE TOO SOON", "THE LEGEND DIES", "MOURN THE MACHINE", "TRAGEDY COMPLETE", "SILENCED FOREVER", "NEVER FORGOTTEN"]}, "streamer": {"safe": ["CHAT WE CHILLING", "EZ CLAP", "CHAT SAW THAT?", "CLEAN RUN CHAT", "W DRIVING", "CLIP IT? NAH", "STREAM SAFE", "VIBES IMMACULATE"], "caution": ["CHAT RELAX", "MINOR SETBACK", "THAT WAS LAG", "CHAT DON'T CLIP THAT", "OKAY OKAY", "IT'S FINE CHAT", "HOLD ON CHAT", "WHO SAID THAT?"], "danger": ["CHAT IT'S GETTING BAD", "MODS HELP", "NOT ON STREAM", "CHAT I'M SWEATING", "THIS IS CONTENT", "STOP SPAMMING L", "CHAT BELIEVE", "DON'T @ ME"], "severe": ["CHAT WE'RE COOKED", "END STREAM?", "CLIP THAT 😭", "CHAT HELP", "THAT'S A VOD MOMENT", "F IN CHAT", "I'M TILTED", "CHAT WHY"], "extreme": ["CHAT IT'S OVER", "SPAM F", "CHAT DON'T LOOK", "RAID ME NOW", "CHAT PLEASE 😭", "IT'S JOEVER CHAT", "UNPLUG IT", "ALT F4?"], "dead": ["GG CHAT", "STREAM ENDED", "F IN THE CHAT", "CLIP IT 💀", "CHAT WE LOST", "BRB CRYING", "THANKS FOR WATCHING", "RESTART STREAM"]}, "youtube": {"safe": ["SMASH THAT LIKE", "INTRO SEQUENCE", "DAY 1 CHALLENGE", "THUMBNAIL READY", "STAY TILL THE END", "NO WAY THIS WORKS", "SUB FOR PART 2", "OKAY LET'S GO"], "caution": ["THIS GETS CRAZY", "YOU WON'T BELIEVE", "PLOT TWIST INCOMING", "DON'T SKIP", "KEEP WATCHING", "HERE WE GO", "IT STARTS...", "COMMENT BELOW"], "danger": ["THIS IS THE PART", "REPLAY THAT", "THE FAIL IS COMING", "LOOK AT THIS", "RIGHT HERE", "ZOOM IN", "SLOW-MO THAT", "PAUSE THE VIDEO"], "severe": ["THE BIG MOMENT", "THUMBNAIL MOMENT", "THIS IS WHY", "INSANE MOMENT", "THEY SAID IT WAS SAFE", "AND HERE IT COMES", "VIEWERS SCREAMING", "PART 2?!"], "extreme": ["3... 2... 1...", "THE CLIMAX", "HERE IT IS", "DON'T BLINK", "FINAL SECONDS", "THE PAYOFF", "MOMENT OF TRUTH", "OH MY GOD"], "dead": ["LIKE IF YOU CRIED", "SEE YOU IN PART 2", "OUTRO MUSIC", "THANKS FOR WATCHING", "SUBSCRIBE FOR MORE", "THAT'S THE VIDEO", "END SCREEN", "WORTH IT?"]}, "meme": {"safe": ["VIBING 😎", "STONKS 📈", "EZ", "BUILT DIFFERENT", "THIS IS FINE (IT IS)", "MAIN CHARACTER", "NPC CAN'T RELATE", "HE'S CHILLING"], "caution": ["UHHH", "MINOR L", "HOLD UP", "WAIT WHAT", "SUS", "BRUH", "THIS IS FINE 🔥", "OOF"], "danger": ["NOT STONKS 📉", "EMOTIONAL DAMAGE", "OH NAH", "BIG L", "SADGE", "BRUH MOMENT", "AINTNOWAY", "HE'S FUMBLING"], "severe": ["IT'S JOEVER", "CRYING 😭", "DEAD 💀", "RIP BOZO", "SKILL DIFF", "HE FELL OFF", "NOT THE CAR 😭", "UNALIVED (ALMOST)"], "extreme": ["💀💀", "THIS IS NOT FINE", "WASTED...", "OHHH NOOO", "MISSION FAILED?", "PAIN", "HELP 😭", "BYE BYE"], "dead": ["WASTED", "RIP 💀", "MISSION FAILED", "HE'S GONE", "RATIO", "L + CAR", "F", "BONK"]}, "savage": {"safe": ["DON'T GET COCKY", "FOR NOW", "LUCKY START", "EVEN YOU CAN'T MISS", "BARE MINIMUM", "NOBODY'S IMPRESSED", "YOU'RE TRYING, CUTE", "SLOW DOWN, HERO"], "caution": ["WHO GAVE YOU KEYS?", "MIRRORS EXIST", "BRAKES ARE LEFT", "THAT WAS EMBARRASSING", "NICE PARKING", "LICENSE WHERE?", "RETURN THE CAR", "GRANDMA DRIVES BETTER"], "danger": ["DRIVING SCHOOL CALLED", "ARE YOU BLIND?", "WHAT WAS THAT?", "DELETE THE GAME", "STEERING WHEEL: DECOR", "YOU'RE THE HAZARD", "TRAFFIC CONES FEAR NOTHING", "CERTIFIED BOT"], "severe": ["UNINSTALL", "HOPELESS", "WALK NEXT TIME", "TAKE THE BUS", "IMPRESSIVELY BAD", "RECORD LEVEL FAIL", "NOT EVEN CLOSE", "INSURANCE HATES YOU"], "extreme": ["HOW?!", "ZERO TALENT", "YOU DID THIS", "TRULY TERRIBLE", "SAY GOODBYE", "UNREAL INCOMPETENCE", "DISGRACEFUL", "STOP DRIVING"], "dead": ["CONGRATS, GENIUS", "WORLD'S WORST DRIVER", "AS EXPECTED", "DESERVED", "HANG UP THE KEYS", "LICENSE REVOKED", "CLASSIC YOU", "DISAPPOINTING"]}, "chaotic": {"safe": ["WHEEE!", "FULL SEND MODE", "GO GO GO", "CHAOS LOADING", "HANDS OFF WHEEL?", "YEEHAW", "ZOOM ZOOM", "NO RULES"], "caution": ["OOPS!", "WHAT WAS THAT?!", "BOUNCE!", "SPIN IT!", "AGAIN!", "OOPSIE DAISY", "WOBBLE WOBBLE", "WHOOPS"], "danger": ["EVERYTHING IS ON FIRE", "MAYDAY MAYDAY", "EJECT!", "DON'T STOP!", "MORE!", "CHAOS!!!", "WHERE ARE THE BRAKES", "LEFT? RIGHT? YES!"], "severe": ["SPARKS EVERYWHERE", "TOTAL MAYHEM", "RED ALERT RED ALERT", "AAAAAA", "SYSTEM FAILURE", "PARTS FLYING", "WHO'S DRIVING?!", "FULL CHAOS"], "extreme": ["AAAAAAAAA", "BRACE BRACE BRACE", "EVERYONE OUT", "MELTDOWN", "KABOOM INCOMING", "LOST IT", "ERROR ERROR", "IT'S HAPPENING"], "dead": ["KABOOM", "CHAOS WINS", "DEMOLISHED", "BOOM. DONE.", "PIECES EVERYWHERE", "SCATTERED", "WELL THAT HAPPENED", "AGAIN?!"]}, "deadpan": {"safe": ["FINE.", "ACCEPTABLE.", "ADEQUATE.", "NOTHING TO REPORT.", "OKAY.", "NORMAL.", "CAR: PRESENT.", "NOT BAD. NOT GOOD."], "caution": ["HM.", "THAT HAPPENED.", "NOTED.", "SLIGHTLY WORSE.", "UNFORTUNATE.", "MILDLY CONCERNING.", "OH.", "INTERESTING."], "danger": ["BAD.", "THIS IS BAD.", "SUBOPTIMAL.", "NOT GREAT.", "WORSENING.", "AS PREDICTED.", "DISAPPOINTING.", "I SEE."], "severe": ["VERY BAD.", "THAT'S A LOT OF DAMAGE.", "MOSTLY BROKEN.", "WELL.", "STILL MOVING. BARELY.", "UNSURPRISING.", "CONCERNING.", "ANYWAY."], "extreme": ["ALMOST DONE.", "ANY SECOND NOW.", "TYPICAL.", "SURE.", "THIS IS IT.", "GREAT.", "WONDERFUL.", "OKAY THEN."], "dead": ["AND IT'S GONE.", "CAR: ABSENT.", "THAT'S THAT.", "FIGURES.", "OH WELL.", "DONE.", "EXPECTED.", "NEXT."]}, "commentator": {"safe": ["A CLEAN LAP!", "TEXTBOOK DRIVING!", "HE'S IN THE ZONE!", "MASTERFUL CONTROL!", "WHAT A START!", "LEADING THE PACK!", "NOT A MISTAKE IN SIGHT!", "SUPERB!"], "caution": ["A SMALL SLIP!", "HE'S LOST SOME TIME!", "OFF THE RACING LINE!", "A LITTLE WOBBLE!", "CAN HE RECOVER?", "PRESSURE BUILDING!", "THAT'LL COST HIM!", "CONTACT!"], "danger": ["OH HE'S HIT HARD!", "BIG MOMENT!", "HE'S STRUGGLING!", "SMOKE FROM THE CAR!", "THE CROWD GASPS!", "DISASTER LOOMS!", "WHAT A HIT!", "HE'S GOING WIDE!"], "severe": ["HE'S HANGING ON!", "THE CAR IS FALLING APART!", "UNBELIEVABLE!", "HE REFUSES TO QUIT!", "DRAMA HERE TODAY!", "CAN YOU BELIEVE IT?!", "IT'S CARNAGE!", "HE NEEDS A MIRACLE!"], "extreme": ["IT'S NOW OR NEVER!", "ONE LAST PUSH!", "HE'S ON THE EDGE!", "INCREDIBLE SCENES!", "HOLD ON!", "THE FINAL MOMENTS!", "HEART IN MOUTH!", "OH MY WORD!"], "dead": ["AND HE'S OUT!", "RACE OVER!", "WHAT A FINISH!", "HE'S RETIRED!", "NO MORE!", "THE DREAM ENDS!", "UNBELIEVABLE SCENES!", "HE'S DONE, FOLKS!"]}, "horror": {"safe": ["TOO QUIET...", "DON'T LOOK BACK", "SOMETHING WATCHES", "IT'S DARK HERE", "STAY IN THE CAR", "LOCK THE DOORS", "NOTHING'S THERE...", "THE FOG ROLLS IN"], "caution": ["DID YOU HEAR THAT?", "IT'S FOLLOWING", "FOOTSTEPS...", "THE LIGHTS DIM", "BEHIND YOU", "COLD BREATH", "WHISPERS", "IT KNOWS"], "danger": ["IT'S CLOSER", "HIDE", "DON'T SCREAM", "IT FOUND YOU", "NO SIGNAL", "THE ENGINE CHOKES", "SOMETHING'S INSIDE", "SHADOWS MOVE"], "severe": ["IT'S HERE", "DON'T TURN AROUND", "TOO LATE TO HIDE", "IT'S HUNGRY", "THE DOORS WON'T OPEN", "BLEEDING OIL", "HEARTBEAT LOUDER", "YOU'RE NOT ALONE"], "extreme": ["IT'S RIGHT BEHIND", "NO WAY OUT", "SILENCE...", "IT'S SMILING", "LAST CHANCE", "DARKNESS", "CAN'T BREATHE", "IT'S OVER YOU"], "dead": ["IT GOT YOU", "NEVER FOUND", "SWALLOWED BY DARK", "THE FOG WINS", "NO ONE HEARD", "GONE WITHOUT A TRACE", "IT'S QUIET NOW", "THEY'LL NEVER KNOW"]}, "action": {"safe": ["LOCKED AND LOADED", "LET'S ROLL", "MISSION START", "ENGINES HOT", "HERE COMES TROUBLE", "TIME TO WORK", "ROGER THAT", "CLEAR PATH"], "caution": ["INCOMING!", "TAKING FIRE", "STAY SHARP", "EYES UP", "WE'VE GOT COMPANY", "DODGE IT", "WATCH YOUR SIX", "FLANK LEFT"], "danger": ["I'M HIT", "COVER ME", "GET DOWN", "WE NEED BACKUP", "HOLD POSITION", "PUNCH IT", "NO RETREAT", "FIGHT BACK"], "severe": ["MAN DOWN", "STILL KICKING", "I'VE HAD WORSE", "NOT DONE YET", "ONE MORE ROUND", "THIS IS PERSONAL", "HANG TIGHT", "GIVE IT EVERYTHING"], "extreme": ["I'LL BE BACK", "LAST BULLET", "GO OUT SWINGING", "ONE-WAY TRIP", "YIPPEE KI-YAY", "DO OR DIE", "BLAZE OF GLORY", "SEE YOU ON THE OTHER SIDE"], "dead": ["MISSION FAILED", "TARGET LOST", "HERO DOWN", "NO EXTRACTION", "BLAZE OF GLORY", "OUT OF AMMO", "THE END OF THE MISSION", "HASTA LA VISTA"]}, "arcade": {"safe": ["PLAYER 1 READY", "HIGH SCORE!", "COMBO x2", "BONUS STAGE", "POWER UP!", "STAGE CLEAR", "PERFECT!", "1UP!"], "caution": ["HIT!", "-10 POINTS", "COMBO BROKEN", "OUCH!", "SHIELD LOW", "CAREFUL PLAYER", "MISS!", "TRY AGAIN"], "danger": ["HP LOW!", "DANGER ZONE", "NO SHIELD", "BOSS INCOMING", "HEALTH CRITICAL", "FIND A POWER UP", "LIVES: 1", "TIME RUNNING OUT"], "severe": ["LOW BATTERY", "FLASHING RED", "ONE HIT LEFT", "NEED HEALTH!", "BLINK BLINK", "NO LIVES LEFT?", "K.O. SOON", "HURRY UP!"], "extreme": ["CONTINUE? 9...", "FINAL HIT", "8...7...", "DANGER!!", "LAST PIXEL", "INSERT COIN!", "OVERHEAT", "K.O.?!"], "dead": ["K.O.!", "INSERT COIN", "CONTINUE?", "YOU LOSE", "GAME OVER", "TRY AGAIN?", "PLAYER 1 DOWN", "SCORE: 0"]}, "genz": {"safe": ["NO CAP", "IT'S GIVING SAFE", "SLAY", "LOWKEY GOATED", "RENT FREE", "MAIN CHARACTER ERA", "VALID", "ATE THAT"], "caution": ["LOWKEY SUS", "NOT THE VIBE", "IT'S GIVING RISK", "BRO?", "MID", "RED FLAG 🚩", "UNHINGED", "SHEESH"], "danger": ["THIS AIN'T IT", "HIGHKEY BAD", "DELULU", "IT'S GIVING DISASTER", "RATIOED", "FLOPPED", "OFF VIBES", "BRO FUMBLED"], "severe": ["NOT THE CAR 😭", "IT'S SO OVER", "BRO IS FINISHED", "DOWN BAD", "CRINGE", "CAUGHT IN 4K", "NO REDEMPTION ARC", "SEND HELP"], "extreme": ["IT'S GIVING FINALE", "BRO IS DONE 💀", "GENUINELY OVER", "BYE BESTIE", "IM CRYING", "LITERALLY DYING", "NOT SURVIVING THIS", "ERA ENDING"], "dead": ["IT'S OVER 💀", "ATE AND LEFT CRUMBS", "LEFT ON READ", "BRO GOT CANCELED", "UNALIVED", "DEAD ASS DEAD", "THE END ERA", "NO CAP GONE"]}, "minimal": {"safe": ["STABLE", "NOMINAL", "OK", "SECURE", "GOOD", "CLEAR", "INTACT", "READY"], "caution": ["WARNING", "MINOR DAMAGE", "ALERT", "WATCH", "MONITOR", "REDUCED", "UNSTABLE", "CHECK"], "danger": ["HIGH RISK", "DAMAGED", "UNSAFE", "SERIOUS", "FAILING", "IMPAIRED", "RED", "ALERT: HIGH"], "severe": ["SEVERE", "FAILURE", "BREAKDOWN", "MAJOR DAMAGE", "LOW", "DEGRADED", "FAULT", "EMERGENCY"], "extreme": ["EXTREME", "FATAL", "IMMINENT", "LAST", "MINIMUM", "ZERO SOON", "OFFLINE SOON", "FINAL"], "dead": ["DESTROYED", "OFFLINE", "0", "DOWN", "NULL", "ENDED", "LOST", "TERMINATED"]}, "darkhumor": {"safe": ["NOT DEAD YET", "INSURANCE SLEEPS", "DEATH IS BORED", "STILL IN ONE PIECE", "GRIM REAPER ON BREAK", "ALIVE, SADLY", "TOO EASY", "FUNERAL POSTPONED"], "caution": ["REAPER'S AWAKE", "ORDER THE FLOWERS?", "INSURANCE WOKE UP", "A LITTLE LESS CAR", "PIECE BY PIECE", "WRITE YOUR WILL", "DEATH IS TAKING NOTES", "WARM UP THE HEARSE"], "danger": ["CALL THE PRIEST", "RESERVE A PLOT", "HALF A CAR", "SCRAPYARD CALLING", "REAPER IS WAVING", "DEATH SAYS HI", "ALMOST ART", "PARTS FOR SALE"], "severe": ["CLOSED CASKET", "PICK A HYMN", "EULOGY PENDING", "ONE WHEEL IN THE GRAVE", "SPARE PARTS SOON", "DEATH IS CLOSE", "NEXT OF KIN?", "SCRAP VALUE ONLY"], "extreme": ["FINAL WISHES?", "SAY YOUR GOODBYES", "REAPER'S HERE", "MEET YOUR MAKER", "ON DEATH'S DOORSTEP", "DIG THE HOLE", "LAST RITES", "PAPERWORK READY"], "dead": ["FLOWERS ORDERED", "SCRAP METAL NOW", "PIECES FOR SALE", "OPEN CASKET? NO", "DEATH WINS", "MAY IT REST", "BURIED", "ASHES TO ASHES"]}, "optimistic": {"safe": ["WHAT A DAY!", "FEELING GREAT", "SUNSHINE AHEAD ☀️", "WE'VE GOT THIS", "BEST DRIVE EVER", "SMILES ONLY", "HAPPY WHEELS", "EVERYTHING'S AWESOME"], "caution": ["JUST A SCRATCH", "STILL GOOD!", "NO BIG DEAL", "WE'RE FINE!", "LEARNING!", "STILL SMILING", "MINOR BUMP", "IT'LL BUFF OUT"], "danger": ["WE CAN FIX THIS", "STAY POSITIVE!", "KEEP GOING!", "HALF FULL!", "COMEBACK TIME", "NOT OVER YET", "BELIEVE!", "STILL ROLLING!"], "severe": ["EVERY BIT COUNTS", "NEVER GIVE UP!", "MIRACLES HAPPEN", "YOU'RE DOING GREAT", "ALMOST A COMEBACK", "HOPE IS ALIVE", "CHIN UP!", "KEEP THE FAITH"], "extreme": ["ONE PERCENT IS ENOUGH!", "IT'S NOT OVER!", "HANG IN THERE!", "WE BELIEVE!", "STILL A CHANCE!", "DON'T STOP NOW!", "ALMOST THERE!", "YOU CAN DO IT!"], "dead": ["WE LEARNED A LOT", "PROUD OF YOU", "NEXT RUN'S THE ONE", "STILL A WINNER", "GREAT EFFORT!", "WHAT A RIDE!", "SMILE ANYWAY", "TOMORROW WE RISE"]}, "pessimistic": {"safe": ["WON'T LAST", "ENJOY IT WHILE IT LASTS", "TOO GOOD TO BE TRUE", "SOMETHING'S WRONG", "I DON'T TRUST THIS", "JUST WAIT", "SUSPICIOUSLY FINE", "HERE WE GO AGAIN"], "caution": ["AND SO IT BEGINS", "TOLD YOU", "THERE IT IS", "DOWNHILL FROM HERE", "OF COURSE", "NATURALLY", "SAW IT COMING", "TYPICAL"], "danger": ["IT ONLY GETS WORSE", "NO SURPRISE", "PREDICTABLE", "WHAT DID YOU EXPECT", "INEVITABLE", "HERE COMES THE REST", "NEVER GOES RIGHT", "KNEW IT"], "severe": ["NO POINT NOW", "MIGHT AS WELL STOP", "HOPELESS, AS USUAL", "ALWAYS THIS WAY", "WHY EVEN TRY", "WE NEVER HAD A CHANCE", "AS I SAID", "ACCEPT IT"], "extreme": ["HERE IT COMES", "ANY MOMENT NOW", "WHY DID WE TRY", "ALL AS EXPECTED", "DON'T EVEN HOPE", "TOLD YOU SO", "IT WAS ALWAYS GOING TO END", "SIGH"], "dead": ["OBVIOUSLY", "SAW THAT COMING", "OF COURSE IT DID", "AS PREDICTED", "TOLD YOU SO.", "WHAT A SURPRISE. NOT.", "I KNEW IT", "NOTHING NEW"]}, "overconfident": {"safe": ["TOO EASY", "I'M A NATURAL", "WATCH AND LEARN", "UNTOUCHABLE", "PRO DRIVER", "NOBODY DRIVES LIKE ME", "BORN FOR THIS", "FLAWLESS"], "caution": ["MEANT TO DO THAT", "STYLE POINTS", "THAT WAS PLANNED", "CALCULATED", "STILL THE BEST", "WARM-UP HIT", "RELAX, I GOT IT", "SMALL TAP"], "danger": ["UH... ALSO PLANNED", "IT'S STRATEGY", "NOBODY SAW THAT", "STILL GOT IT... RIGHT?", "OKAY THAT HURT", "MINOR ISSUE", "WHO PUT THAT THERE?", "NOT MY FAULT"], "severe": ["OKAY MAYBE NOT", "HELP? NO. MAYBE.", "I'M FINE (I'M NOT)", "THIS WASN'T THE PLAN", "I OVERSOLD IT", "HUMBLED", "EGO DAMAGED", "RETHINKING THINGS"], "extreme": ["I WAS WRONG", "HUMBLED HARD", "PLEASE STOP", "NO MORE SPEECHES", "OKAY I'M BAD", "FORGET WHAT I SAID", "I QUIT BRAGGING", "MOM COME PICK ME UP"], "dead": ["NEVER SPEAKING AGAIN", "DELETE MY WORDS", "WORST DRIVER ALIVE", "EGO: DESTROYED", "FULLY HUMBLED", "DIDN'T SEE THAT", "I'LL SEE MYSELF OUT", "RETIRING NOW"]}, "panic": {"safe": ["OKAY OKAY OKAY", "WE'RE FINE?", "ALL GOOD... RIGHT?", "DON'T JINX IT", "BREATHE", "CALM... CALM", "NOTHING YET", "STAY CHILL"], "caution": ["WHAT WAS THAT", "OH NO", "HUH?! HUH?!", "DID WE HIT?", "IS THAT BAD?", "UH OH UH OH", "HANDS SHAKING", "OKAY DON'T PANIC"], "danger": ["PANIC PANIC", "WHAT DO I DO", "BRAKES BRAKES", "NONONO", "HELP ME", "WHY WHY WHY", "AAAH", "OH GOD OH GOD"], "severe": ["AAAAAA", "SOMEBODY HELP", "I CAN'T", "PLEASE PLEASE", "MAKE IT STOP", "NOT LIKE THIS", "OH NO OH NO", "HEART ATTACK"], "extreme": ["AAAAAAAA 😭", "MOMMY", "NO NO NO NO NO", "PLEASE STOP", "I'M SCREAMING", "IT'S HAPPENING", "NOOOO", "FREAKING OUT"], "dead": ["I'M DONE 😭", "WHY 😭", "NOOOO", "IT HAPPENED", "I NEED A MINUTE", "SCREAMING INTERNALLY", "SOMEONE HOLD ME", "NEVER AGAIN"]}, "storyteller": {"safe": ["ONCE UPON A TIME...", "IT WAS A QUIET DAY", "OUR HERO SET OFF", "THE ROAD WAS LONG", "ALL WAS WELL...", "HE FELT UNSTOPPABLE", "A PERFECT MORNING", "LITTLE DID HE KNOW"], "caution": ["BUT THEN...", "SOMETHING WENT WRONG", "A SMALL MISTAKE", "HE IGNORED THE SIGNS", "THE FIRST CRACK", "IT STARTED SMALL", "HE SHOULD'VE STOPPED", "NOBODY WARNED HIM"], "danger": ["THINGS GOT WORSE", "HE PANICKED", "THE ROAD FOUGHT BACK", "NO ONE CAME", "HE KEPT GOING", "A TERRIBLE CHOICE", "THE CAR SCREAMED", "HE REGRETTED IT"], "severe": ["CHAPTER'S ENDING", "HE HAD ONE CHANCE", "NOTHING WENT RIGHT", "AND IT KEPT GOING", "THE TALE TURNED DARK", "FEW SURVIVED THIS", "HIS LUCK RAN OUT", "NO TURNING BACK"], "extreme": ["IN HIS FINAL MOMENT...", "ONE LAST PAGE", "AND JUST LIKE THAT", "THEN SILENCE...", "HE CLOSED HIS EYES", "THE LAST LINE", "AND SO...", "FATE DECIDED"], "dead": ["AND THAT WAS THE END", "THE BOOK CLOSES", "A STORY FOR LATER", "HE NEVER MADE IT", "THE LAST CHAPTER", "TOLD FOR YEARS", "NO HAPPY ENDING", "THE END."]}, "clickbait": {"safe": ["100% SAFE?!", "TOO GOOD?!", "NO WAY?!", "PERFECT RUN?!", "UNBELIEVABLE START", "MUST WATCH", "GONE RIGHT?!", "EXPERTS SHOCKED"], "caution": ["FIRST HIT?!", "WAIT WHAT?!", "IT STARTED?!", "SHOCKING!", "CAUGHT ON CAMERA", "WATCH TILL END", "YOU WON'T BELIEVE", "OMG?!"], "danger": ["HALF GONE?!", "GONE WRONG!", "INSANE CRASH?!", "NOT CLICKBAIT", "99% FAIL THIS", "SHOCKING DAMAGE", "HE DID WHAT?!", "MUST SEE!"], "severe": ["ALMOST 0?!", "TOO FAR?!", "EMOTIONAL!", "GONE WAY WRONG", "DOCTORS HATE THIS", "REAL?!", "SCARY!", "HE REGRETS IT"], "extreme": ["1%?!", "LAST SECOND?!", "UNREAL?!", "HEART STOPPING", "WILL HE SURVIVE?!", "CRAZIEST ENDING", "SHOCKING!!", "3AM CHALLENGE?!"], "dead": ["0% (REAL)", "IT HAPPENED?!", "GONE FOREVER?!", "NOT CLICKBAIT!", "THE ENDING?!", "WE LOST IT ALL", "SAD ENDING?!", "RIP?!"]}, "brainrot": {"safe": ["SKIBIDI SAFE", "RIZZ LEVEL MAX", "OHIO NEVER", "SIGMA GRINDSET", "AURA +1000", "GYATT ENGINE", "MEWING ON ROAD", "FANUM TAX FREE"], "caution": ["AURA -100", "LOW RIZZ", "OHIO VIBES", "FANUM TAXED", "SUS AMOGUS", "NPC MOVE", "SKIBIDI WOBBLE", "MINUS AURA"], "danger": ["OHIO LEVEL", "AURA -5000", "SKIBIDI DANGER", "RIZZ DEPLETED", "CAUGHT LACKING", "BETA MOVE", "GRIMACE SHAKE", "NO SIGMA"], "severe": ["AURA BANKRUPT", "FULL OHIO", "SKIBIDI DOOMED", "ZERO RIZZ", "TOTAL NPC", "MOGGED", "BRAIN.EXE STOPPED", "RIZZLESS"], "extreme": ["AURA -INFINITY", "OHIO FINAL BOSS", "SKIBIDI BYE", "NEGATIVE RIZZ", "GYATT GONE", "ALPHA NO MORE", "RIP SIGMA", "MEWING FAILED"], "dead": ["SKIBIDI DEAD", "OHIO WINS", "AURA: 0", "RIZZ DECEASED", "FANUM TOOK IT ALL", "L + OHIO", "SIGMA DOWN", "BRAINROT COMPLETE"]}};
        Object.keys(EXTRA).forEach(function(s){ var P = SURVIVAL_PACKS[s]; if (!P) return;
          Object.keys(EXTRA[s]).forEach(function(l){ var have = {}; (P[l]=P[l]||[]).forEach(function(t){have[t]=1;});
            EXTRA[s][l].forEach(function(t){ if(!have[t]){ P[l].push(t); have[t]=1; } }); }); }); })();
      // v5.8.0: "shuffle bag" — s'perseritet asnje fraze derisa te dalin te gjitha
      var phraseBags = {};
      function pickPhrase(pack, level, list) {
        var key = pack + '|' + level + '|' + (scope.survival.rotIndex || 0);
        if (phraseCache.key === key && phraseCache.text) return phraseCache.text;
        var lastKey = pack + '|' + level;
        var bag = phraseBags[lastKey];
        if (!bag || !bag.length || bag.n !== list.length) {
          bag = list.map(function(_, k){ return k; });
          for (var a = bag.length - 1; a > 0; a--) { var b = Math.floor(Math.random() * (a + 1)); var t = bag[a]; bag[a] = bag[b]; bag[b] = t; }
          if (bag.length > 1 && list[bag[bag.length-1]] === phraseCache.last[lastKey]) { var t2 = bag[0]; bag[0] = bag[bag.length-1]; bag[bag.length-1] = t2; }
          bag.n = list.length; phraseBags[lastKey] = bag;
        }
        var txt = list[bag.pop()];
        phraseCache.key = key; phraseCache.text = txt; phraseCache.last[lastKey] = txt;
        return txt;
      }
      function pickPhraseOld(pack, level, list) {
        var key = pack + '|' + level + '|' + (scope.survival.rotIndex || 0);
        if (phraseCache.key === key && phraseCache.text) return phraseCache.text;
        var lastKey = pack + '|' + level;
        var prev = phraseCache.last[lastKey];
        var i = Math.floor(Math.random() * list.length);
        if (list.length > 1 && list[i] === prev) i = (i + 1 + Math.floor(Math.random() * (list.length - 1))) % list.length;
        phraseCache.key = key; phraseCache.text = list[i]; phraseCache.last[lastKey] = list[i];
        return list[i];
      }

      // v5.5 — EMOJI 3D (Microsoft Fluent 3D, MIT) — pamje e ngjashme me iOS, njejt në çdo PC
      var EMOJI_3D = {};
      ["1f198", "1f300", "1f308", "1f311", "1f319", "1f31f", "1f324", "1f32a", "1f32b", "1f33e", "1f340", "1f344", "1f35f", "1f373", "1f37a", "1f37f", "1f381", "1f389", "1f399", "1f3a2", "1f3a5", "1f3ac", "1f3ae", "1f3af", "1f3b2", "1f3c1", "1f3c3", "1f3c6", "1f3ce", "1f3e0", "1f3f3", "1f408", "1f410", "1f440", "1f441", "1f442", "1f44b", "1f44c", "1f44d", "1f44f", "1f451", "1f463", "1f479", "1f47b", "1f47e", "1f480", "1f485", "1f488", "1f48c", "1f490", "1f494", "1f4a2", "1f4a5", "1f4a8", "1f4aa", "1f4ac", "1f4ad", "1f4af", "1f4b8", "1f4c8", "1f4c9", "1f4ca", "1f4cb", "1f4d6", "1f4da", "1f4dd", "1f4de", "1f4e1", "1f504", "1f50b", "1f514", "1f525", "1f527", "1f52b", "1f534", "1f54a", "1f56f", "1f570", "1f573", "1f577", "1f578", "1f5ff", "1f605", "1f608", "1f60a", "1f60c", "1f60e", "1f60f", "1f610", "1f611", "1f612", "1f616", "1f61f", "1f623", "1f627", "1f628", "1f629", "1f62b", "1f62c", "1f62d", "1f62e-200d-1f4a8", "1f630", "1f631", "1f632", "1f633", "1f635", "1f635-200d-1f4ab", "1f636", "1f642", "1f643", "1f644", "1f645", "1f64f", "1f680", "1f697", "1f6a8", "1f6a9", "1f6aa", "1f6ab", "1f6bd", "1f6cb", "1f6e1", "1f6e3", "1f7e0", "1f7e1", "1f7e2", "1f910", "1f914", "1f915", "1f916", "1f91e", "1f920", "1f921", "1f922", "1f926", "1f928", "1f92b", "1f92f", "1f932", "1f937", "1f95b", "1f964", "1f972", "1f975", "1f976", "1f984", "1f9ca", "1f9df", "1f9e0", "1f9e4", "1f9e9", "1f9ea", "1fa78", "1fa79", "1fa82", "1fa99", "1fa9f", "1faa6", "1faa8", "1faab", "1fad3", "1fae0", "1fae1", "1fae3", "1fae8", "231b", "23ed", "23f1", "23f3", "2620", "2694", "26a0", "26a1", "26aa", "26b0", "26c8", "26d3", "2705", "270a", "270b", "2714", "2728", "274c", "2757", "2764-200d-1fa79", "27a1", "2b55"].forEach(function(k) { EMOJI_3D[k] = true; });
      var EMOJI_SPLIT = /((?:[\u2300-\u23FF\u2600-\u27BF\u2B00-\u2BFF]|\uD83C[\uDC00-\uDFFF]|\uD83D[\uDC00-\uDFFF]|\uD83E[\uDC00-\uDFFF])\uFE0F?(?:\u200D(?:[\u2600-\u27BF]|\uD83C[\uDC00-\uDFFF]|\uD83D[\uDC00-\uDFFF]|\uD83E[\uDC00-\uDFFF])\uFE0F?)*)/;
      function emojiKey(e) {
        var out = [];
        for (var i = 0; i < e.length; i++) {
          var c = e.codePointAt(i);
          if (c > 0xFFFF) i++;
          if (c !== 0xFE0F) out.push(c.toString(16));
        }
        return out.join('-');
      }
      var partsCache = { text:null, style:null, parts:[] };
      scope.survivalStatusParts = function() {
        var text = scope.survivalStatus();
        var use3d = scope.cfg.survivalEmoji3d !== false;
        var showEmoji = scope.cfg.survivalPhraseEmoji !== false;
        var style = (use3d ? '3d' : 'sys') + (showEmoji ? '' : '-none');
        if (partsCache.text === text && partsCache.style === style) return partsCache.parts;
        var parts = [];
        String(text).split(EMOJI_SPLIT).forEach(function(seg, idx) {
          if (!seg) return;
          if (idx % 2 === 1) {
            if (!showEmoji) return;
            var k = emojiKey(seg);
            if (use3d && EMOJI_3D[k]) parts.push({ img:'/ui/modules/apps/CreatorPack/emoji/' + k + '.png', alt:seg });
            else parts.push({ emoji:seg });
          } else {
            parts.push({ text: showEmoji ? seg : seg.replace(/\s+$/, '') });
          }
        });
        partsCache = { text:text, style:style, parts:parts };
        return parts;
      };

      scope.survivalStatus = function() {
        var level = scope.survivalPhraseLevel();
        var pack = scope.cfg.survivalStatusPack || 'streamer';
        if (pack === 'custom') {
          var texts = scope.cfg.survivalStatusTexts || {};
          var fallback = { severe:'critical', extreme:'critical' };
          var txt = texts[level] || texts[fallback[level]] || SURVIVAL_PACKS.minimal[level][0];
          return String(txt).toUpperCase();
        }
        var set = SURVIVAL_PACKS[pack] || SURVIVAL_PACKS.streamer;
        var list = set[level] || ['SAFE'];
        if (!scope.cfg.survivalStatusRotate) return list[0];
        return pickPhrase(pack, level, list);
      };

      scope.setSurvivalPack = function(name) {
        scope.cfg.survivalStatusPack = name;
        scope.survival.rotIndex = 0;
        restartSurvivalRotation();
        scope.persist();
      };

      // Kur perdoruesi shkruan tekst vetjak, kalo automatikisht ne paketen Custom.
      scope.survivalCustomEdit = function() {
        if (scope.cfg.survivalStatusPack !== 'custom') scope.cfg.survivalStatusPack = 'custom';
        scope.survival.rotIndex = 0;
        restartSurvivalRotation();
        scope.persist();
      };

      function packHasRotation() {
        var pack = scope.cfg.survivalStatusPack || 'streamer';
        return pack !== 'custom' && !!SURVIVAL_PACKS[pack];
      }

      function restartSurvivalRotation() {
        if (survivalRotateTimer) { try { $timeout.cancel(survivalRotateTimer); } catch (e) {} survivalRotateTimer = null; }
        if (!scope.cfg.survivalStatusRotate || !packHasRotation()) return;
        var every = Math.max(800, Math.min(15000, Number(scope.cfg.survivalRotateMs) || 3000));
        function step() {
          survivalRotateTimer = $timeout(function() {
            scope.survival.rotIndex = (Number(scope.survival.rotIndex) || 0) + 1;
            step();
          }, every);
        }
        step();
      }
      scope.restartSurvivalRotation = restartSurvivalRotation;

      // v5.2.1 FIX: emoji zgjidhet nga NIVELI (jo nga fjala e paketes).
      // Me pare kthehej gjithmone 💀 sepse frazat nuk ishin 'SAFE'/'DANGER'.
      scope.survivalEmojiText = function() {
        var key = scope.survivalStateKey();
        var map = {
          safe: scope.cfg.survivalEmojiSafe || '😎',
          caution: scope.cfg.survivalEmojiCaution || '😬',
          danger: scope.cfg.survivalEmojiDanger || '😰',
          critical: scope.cfg.survivalEmojiCritical || '😵',
          dead: scope.cfg.survivalEmojiDead || '💀'
        };
        return map[key] || map.safe;
      };

      scope.survivalEmojiStyle = function() {
        var size = Math.max(.14, Math.min(1.10, Number(scope.cfg.survivalEmojiSize) || .34));
        return { fontSize:size+'em' };
      };

      scope.survivalEmojiClass = function() {
        return {
          'emoji-pop': scope.survival.emojiPulse && scope.cfg.survivalEmojiPop !== false,
          'emoji-left': scope.cfg.survivalEmojiMode === 'left',
          'emoji-right': scope.cfg.survivalEmojiMode === 'right',
          'emoji-replace': scope.cfg.survivalEmojiMode === 'replace'
        };
      };

      // =====================================================
      // v5.2 — kur ndryshon NIVELI (jo fjala): pop, flash, ze, game over
      // =====================================================
      var STATE_ORDER = { safe: 0, caution: 1, danger: 2, critical: 3, dead: 4 };

      unwatchSurvivalState = scope.$watch(function() { return scope.survivalStateKey(); }, function(now, before) {
        scope.survival.stateKey = now;
        if (!before || now === before) return;

        // niveli i re fillon gjithmone nga fraza e pare
        scope.survival.rotIndex = 0;

        var worse = (STATE_ORDER[now] || 0) > (STATE_ORDER[before] || 0);

        if (worse) survivalSoundAlert(now, before);

        if (scope.cfg.survivalEmojiPop !== false && !scope.survival.emojiPulse) {
          if (survivalEmojiTimer) { try { $timeout.cancel(survivalEmojiTimer); } catch (e) {} }
          scope.survival.emojiPulse = false;
          $timeout(function() {
            scope.survival.emojiPulse = true;
            survivalEmojiTimer = $timeout(function() { scope.survival.emojiPulse = false; }, 520);
          }, 10);
        }
      });

      scope.survivalVisible = function() {
        if (!scope.cfg.survivalOn) return false;
        if (scope.cfg.survivalEditPosition) return true;
        var mode = scope.cfg.survivalDisplayMode || 'always';
        if (mode === 'change') return scope.survival.visible !== false;
        if (mode === 'danger') return scope.survivalRawValue() <= Number(scope.cfg.survivalDangerShowAt || 55);
        return true;
      };

      // =====================================================
      // v5.1 — ON/OFF per rrumullakat e makinave
      // Fshehja eshte thjesht vizuale: motori i demit dhe
      // Survival Chance vazhdojne te punojne normalisht.
      // =====================================================
      scope.vehiclesVisible = function() {
        return scope.cfg.vehiclesOn !== false;
      };
      scope.toggleVehicles = function() {
        scope.cfg.vehiclesOn = !scope.vehiclesVisible();
        scope.persist();
      };
      scope.toggleSurvival = function() {
        scope.cfg.survivalOn = !scope.cfg.survivalOn;
        if (scope.cfg.survivalOn) scope.survival.visible = true;
        scope.persist();
      };
      scope.survivalOnly = function() {
        scope.cfg.vehiclesOn = false;
        scope.cfg.survivalOn = true;
        scope.survival.visible = true;
        scope.persist();
      };
      scope.showVehiclesAgain = function() {
        scope.cfg.vehiclesOn = true;
        scope.persist();
      };

      // v5.7.0: preset CLEAN — font Bebas Neue, 1 decimal, pa glow/halo/heartbeat
      scope.applyCleanPreset = function() {
        var c = scope.cfg;
        c.survivalFontFamily = 'bebas'; c.survivalFontWeight = '400'; c.survivalItalic = false;
        c.survivalGlow = 0; c.survivalGlowPulse = false; c.survivalHeartbeat = false;
        c.survivalTextFx = 'none'; c.survivalCriticalGlitch = false; c.survivalLowPulse = false;
        c.survivalOutline = 0; c.survivalDecimals = 1; c.survivalLayout = 'inline';
        c.survivalLabelColor = '#ffffff'; c.survivalBackground = 'none';
        c.survivalStatusSize = Math.min(Number(c.survivalStatusSize) || .28, .22);
        scope.persist();
      };

      scope.survivalClass = function() {
        var cls = {};
        var fam = scope.cfg.survivalFontFamily || 'bangers';
        cls['font-bangers'] = (fam === 'bangers' || fam === 'futura');    // v5.2.1: Bangers (edhe per config-et e vjetra)
        cls['font-user'] = fam === 'user' && !!scope.cfg.survivalUserFontData;   // v5.3.1
        cls['delta-style-' + (scope.cfg.survivalDeltaStyle || 'subtle')] = true; // v5.3.1
        cls['font-narrow'] = fam === 'narrow';
        cls['font-bebas'] = fam === 'bebas';   // v5.7.0 CLEAN
        cls['layout-' + (scope.cfg.survivalLayout || 'inline')] = true;
        cls['bg-' + (scope.cfg.survivalBackground || 'none')] = true;
        cls['delta-' + (scope.cfg.survivalDeltaPosition || 'right')] = true;
        cls['pulse'] = scope.survival.pulse;
        cls['rolling'] = scope.survival.rolling;
        cls['status-' + (scope.cfg.survivalStatusPosition || 'bottom')] = true;
        cls['status-pulse'] = scope.cfg.survivalStatusPulse !== false && scope.survival.pulse;
        cls['impact-shake'] = scope.survival.shake;
        cls['low-pulse'] = scope.cfg.survivalLowPulse !== false && scope.survivalRawValue() <= Number(scope.cfg.survivalCriticalThreshold || 20);
        cls['edit-position'] = scope.cfg.survivalEditPosition;
        // ---- v5.2: FX teksti, rrahje zemre, glitch ----
        cls['fx-' + (scope.cfg.survivalTextFx || 'none')] = true;
        cls['font-impact'] = fam === 'impact';
        cls['font-arialblack'] = fam === 'arialblack';
        var key = scope.survivalStateKey();
        cls['heartbeat'] = scope.cfg.survivalHeartbeat === true && scope.survivalRawValue() < Number(scope.cfg.survivalSoundBelow || 60) + 15;
        cls['glitchy'] = scope.cfg.survivalCriticalGlitch !== false && (key === 'critical' || key === 'dead');
        cls['is-dead'] = key === 'dead';
        return cls;
      };

      scope.survivalStyle = function() {
        var bg = hexToRgba(scope.cfg.survivalBackgroundColor || '#071016', Math.max(0, Math.min(0.95, Number(scope.cfg.survivalBackgroundOpacity) || 0)));
        return {
          left: Math.max(0, Math.min(100, Number(scope.cfg.survivalPosX) || 0)) + '%',
          top: Math.max(0, Math.min(100, Number(scope.cfg.survivalPosY) || 0)) + '%',
          fontSize: Math.max(28, Math.min(110, Number(scope.cfg.survivalSize) || 54)) + 'px',
          fontStyle: scope.cfg.survivalItalic === false ? 'normal' : 'italic',
          fontWeight: scope.cfg.survivalFontWeight || '900',
          color: scope.survivalColor(),
          backgroundColor: (scope.cfg.survivalBackground || 'none') === 'none' ? 'transparent' : bg
        };
      };

      scope.survivalMainStyle = function() {
        var g = Number(scope.cfg.survivalLabelGap); if (isNaN(g)) g = 0.12;
        return (scope.cfg.survivalLayout || 'inline') === 'inline' ? { gap: Math.max(0, Math.min(1, g)) + 'em' } : {};
      };

      scope.survivalLabelStyle = function() {
        return {
          color: scope.cfg.survivalLabelColor || '#ffffff',
          fontSize: Math.max(.3, Math.min(1, Number(scope.cfg.survivalLabelScale) || .6)) + 'em',
          WebkitTextStroke: Math.max(0, Number(scope.cfg.survivalOutline) || 0) + 'px rgba(0,0,0,.72)'
        };
      };

      scope.survivalValueStyle = function() {
        var col = scope.survivalColor();
        var glow = Math.max(0, Math.min(30, Number(scope.cfg.survivalGlow) || 0));
        return {
          color:col,
          fontWeight:scope.cfg.survivalFontWeight || '900',
          WebkitTextStroke:Math.max(0, Number(scope.cfg.survivalOutline) || 0)+'px rgba(0,0,0,.60)',
          textShadow:'0 3px 3px rgba(0,0,0,.88),0 0 '+glow+'px '+col,
          animationDuration:Math.max(220,Number(scope.cfg.survivalRollDuration)||430)+'ms'
        };
      };

      scope.survivalOldStyle = function() {
        return {
          color:scope.survivalColor(),
          animationDuration:Math.max(220,Number(scope.cfg.survivalRollDuration)||430)+'ms'
        };
      };

      scope.survivalStatusStyle = function() {
        return {
          color:scope.survivalColor(),
          fontSize:Math.max(.12,Math.min(.80,Number(scope.cfg.survivalStatusSize)||.28))+'em',
          letterSpacing:Math.max(0,Math.min(.45,Number(scope.cfg.survivalStatusSpacing)||0))+'em',
          fontWeight:scope.cfg.survivalStatusWeight||'900'
        };
      };

      scope.survivalDeltaStyle = function(opacity, scale) {
        return {
          color:scope.cfg.survivalDeltaColor||'#ff8a32',
          fontSize:Math.max(.20,Math.min(1.10,Number(scope.cfg.survivalDeltaSize)||.42))+'em',
          opacity:opacity,
          transform:'scale('+(scale||1)+')',
          animationDuration:Math.max(300,Number(scope.cfg.survivalDeltaDuration)||850)+'ms'
        };
      };

      scope.survivalMeterStyle = function() {
        return { width: Math.max(0, Math.min(100, scope.survivalVisualValue())) + '%', background: scope.survivalColor() };
      };


      // =====================================================
      // v5.2 — DRAMA: flash, impact popup, GAME OVER, vignette, rrahje
      // =====================================================
      var survivalZone = null;
      function survivalNode() {
        if (!survivalZone && element && element[0] && element[0].querySelector) {
          survivalZone = element[0].querySelector('.pf-survival');
        }
        return survivalZone;
      }

      // Rifreskon variablat CSS te HUD-it (rrahja, vignette) dhe opacitetin e skajeve.
      function refreshSurvivalDrama() {
        var v = scope.survivalRawValue();
        var t = survivalThresholds();
        var node = survivalNode();

        // rrahja e zemres: sa me i ulet %, aq ma i shpejt e ma i forte
        var tt = Math.max(0, Math.min(1, (t.caution - v) / Math.max(1, t.caution)));
        var amt = Math.max(0, Math.min(100, Number(scope.cfg.survivalHeartbeatAmount) || 0)) / 100;
        var period = 1.30 - 0.90 * tt;
        if (node && node.style && node.style.setProperty) {
          try {
            node.style.setProperty('--hb', period.toFixed(2) + 's');
            node.style.setProperty('--hb1', (1 + 0.055 * amt * (0.35 + tt)).toFixed(4));
            node.style.setProperty('--hb2', (1 + 0.030 * amt * (0.35 + tt)).toFixed(4));
          } catch (e) {}
        }

        // v5.2.1: aureola dramatike — ngjyra e rrezikut pulson RRETH HUD-it,
        // ekrani i lojes nuk skuqet ma.
        var aura = 0;
        if (scope.cfg.survivalGlowPulse !== false && v < t.caution) {
          aura = ((t.caution - v) / Math.max(1, t.caution)) *
                 (Math.max(0, Math.min(100, Number(scope.cfg.survivalGlowAmount) || 0)) / 100) * 0.30;
        }
        scope.survival.auraOpacity = aura;
        if (node && node.style && node.style.setProperty) {
          try { node.style.setProperty('--aura', aura.toFixed(3)); } catch (e) {}
        }
      }
      scope.refreshSurvivalDrama = refreshSurvivalDrama;

      // v5.3.2: funksionet e flash-it të kuq dhe të vulës “TOTALED” u hoqën krejt.

      // =====================================================
      // v5.2 — ZË (Web Audio; pa file ekstra, pa instalim)
      // =====================================================
      var sound = { ctx:null, hbTimer:null, warned:false };

      scope.survivalSoundOn = function() {
        return (scope.cfg.survivalSoundMode || 'off') !== 'off';
      };
      function soundWants(what) {
        var m = scope.cfg.survivalSoundMode || 'off';
        if (m === 'off') return false;
        if (m === 'both') return true;
        return m === what;
      }
      function soundVolume() {
        return Math.max(0, Math.min(1, Number(scope.cfg.survivalSoundVolume) || 0.35));
      }

      function audioCtx() {
        try {
          var C = window.AudioContext || window.webkitAudioContext;
          if (!C) return null;
          if (!sound.ctx) sound.ctx = new C();
          if (sound.ctx.state === 'suspended' && sound.ctx.resume) sound.ctx.resume();
          return sound.ctx;
        } catch (e) { return null; }
      }

      function playThump(vol, freq) {
        var ctx = audioCtx(); if (!ctx) return;
        try {
          var t = ctx.currentTime, f = freq || 76;
          var osc = ctx.createOscillator(), gain = ctx.createGain();
          osc.type = 'sine';
          osc.frequency.setValueAtTime(f, t);
          osc.frequency.exponentialRampToValueAtTime(Math.max(24, f * 0.45), t + 0.16);
          gain.gain.setValueAtTime(0.0001, t);
          gain.gain.exponentialRampToValueAtTime(Math.max(0.0002, vol), t + 0.012);
          gain.gain.exponentialRampToValueAtTime(0.0001, t + 0.20);
          osc.connect(gain); gain.connect(ctx.destination);
          osc.start(t); osc.stop(t + 0.24);
        } catch (e) {}
      }

      function playBeep(freq, vol, dur, type) {
        var ctx = audioCtx(); if (!ctx) return;
        try {
          var t = ctx.currentTime;
          var osc = ctx.createOscillator(), gain = ctx.createGain();
          osc.type = type || 'square';
          osc.frequency.setValueAtTime(freq, t);
          gain.gain.setValueAtTime(0.0001, t);
          gain.gain.exponentialRampToValueAtTime(Math.max(0.0002, vol), t + 0.02);
          gain.gain.exponentialRampToValueAtTime(0.0001, t + (dur || 0.15));
          osc.connect(gain); gain.connect(ctx.destination);
          osc.start(t); osc.stop(t + (dur || 0.15) + 0.03);
        } catch (e) {}
      }

      function playCrashNoise(vol) {
        var ctx = audioCtx(); if (!ctx) return;
        try {
          var len = Math.floor(ctx.sampleRate * 0.30);
          var buf = ctx.createBuffer(1, len, ctx.sampleRate);
          var data = buf.getChannelData(0), n;
          for (n = 0; n < len; n++) data[n] = (Math.random() * 2 - 1) * Math.pow(1 - n / len, 2.4);
          var src = ctx.createBufferSource(); src.buffer = buf;
          var flt = ctx.createBiquadFilter(); flt.type = 'lowpass'; flt.frequency.value = 850;
          var g = ctx.createGain(); g.gain.value = Math.max(0.0001, vol);
          src.connect(flt); flt.connect(g); g.connect(ctx.destination);
          src.start();
        } catch (e) {}
      }

      function heartbeatPeriod(v) {
        var below = Math.max(5, Math.min(99, Number(scope.cfg.survivalSoundBelow) || 60));
        var tt = Math.max(0, Math.min(1, (below - v) / Math.max(1, below)));
        return (1.25 - 0.85 * tt) * 1000;
      }
      function heartbeatVolume(v) {
        var below = Math.max(5, Math.min(99, Number(scope.cfg.survivalSoundBelow) || 60));
        var tt = Math.max(0, Math.min(1, (below - v) / Math.max(1, below)));
        return soundVolume() * (0.35 + 0.65 * tt);
      }

      function heartbeatLoop() {
        sound.hbTimer = null;
        if (!soundWants('heartbeat') || !scope.cfg.survivalOn) return;   // ndalon vet
        var v = scope.survivalRawValue();
        var below = Math.max(5, Math.min(99, Number(scope.cfg.survivalSoundBelow) || 60));
        if (v < below && scope.survivalVisible()) {
          var vol = heartbeatVolume(v);
          playThump(vol, 76);
          setTimeout(function() { playThump(vol * 0.72, 60); }, 165);
        }
        sound.hbTimer = setTimeout(heartbeatLoop, heartbeatPeriod(v));
      }

      function startSurvivalSound() {
        if (sound.hbTimer) { try { clearTimeout(sound.hbTimer); } catch (e) {} sound.hbTimer = null; }
        if (!soundWants('heartbeat')) return;
        sound.hbTimer = setTimeout(heartbeatLoop, 500);
      }
      scope.startSurvivalSound = startSurvivalSound;

      function survivalSoundAlert(nowKey, beforeKey, drop) {
        if (!soundWants('alerts')) return;
        if (scope.cfg.memeSfxOn !== false) return;   // v5.6: meme SFX i zëvendëson alarmet e vjetra
        var vol = soundVolume();
        if (drop && drop >= 10) playCrashNoise(vol * 0.35);   // v5.3.1: ma i bute
        if (nowKey === 'dead') {
          playBeep(120, vol * 0.85, 0.9, 'sawtooth');
          setTimeout(function() { playBeep(88, vol * 0.85, 1.1, 'sawtooth'); }, 190);
        } else if (nowKey === 'critical' && beforeKey !== 'critical') {
          playBeep(760, vol * 0.32, 0.10, 'sine');
          setTimeout(function() { playBeep(600, vol * 0.32, 0.13, 'sine'); }, 140);
        } else if (nowKey === 'danger' && beforeKey !== 'danger') {
          playBeep(520, vol * 0.26, 0.09, 'sine');
        }
      }

      // =====================================================
      // v5.6 — MEME SFX (file .mp3 në /sounds): hit, bighit, critical, dead
      // =====================================================
      var SFX_BASE = '/ui/modules/apps/CreatorPack/sounds/';
      var SFX = {
        hit:      { file:'hit.mp3',      label:'Goditje (≥8%)' },
        bighit:   { file:'bighit.mp3',   label:'Goditje e fortë (≥20%)' },
        critical: { file:'critical.mp3', label:'Hyn në 1–5%' },
        dead:     { file:'dead.mp3',     label:'0%' }
      };
      scope.sfxSlots = ['hit','bighit','critical','dead'];
      scope.sfxLabel = function(k) { return SFX[k].label; };
      scope.sfxFile = function(k) { return SFX[k].file; };
      var sfxState = { last:0, critPlayed:false, deadPlayed:false, playing:null, missing:{} };
      scope.sfxMissing = sfxState.missing;

      // v5.6.1: ngarkim përmes XHR + WebAudio (ma i sigurt në BeamNG se <audio>)
      // dhe provon edhe emra të gabuar si "hit.mp3.mp3" (Windows fsheh prapashtesën).
      var sfxBuf = {}, sfxLoading = {};
      function sfxCandidates(key) {
        var b = key;
        return [b + '.mp3', b + '.mp3.mp3', b + '.MP3', b + '.wav', b + '.ogg', b + '.wav.wav', b + '.ogg.ogg', b];
      }
      function xhrBuf(url, ok, fail) {
        try {
          var x = new XMLHttpRequest();
          x.open('GET', url, true);
          x.responseType = 'arraybuffer';
          x.onload = function() {
            if ((x.status === 200 || x.status === 0) && x.response && x.response.byteLength > 200) ok(x.response); else fail();
          };
          x.onerror = fail;
          x.send();
        } catch (e) { fail(); }
      }
      function loadSfx(key, done) {
        if (sfxBuf[key]) return done(sfxBuf[key]);
        if (sfxLoading[key]) { sfxLoading[key].push(done); return; }
        sfxLoading[key] = [done];
        var list = sfxCandidates(key), i = 0;
        function finish(buf, name) {
          sfxBuf[key] = buf || null;
          scope.$evalAsync(function() {
            if (buf) { delete sfxState.missing[key]; scope.sfxFound[key] = name; }
            else { sfxState.missing[key] = true; delete scope.sfxFound[key]; }
          });
          var cbs = sfxLoading[key]; delete sfxLoading[key];
          cbs.forEach(function(cb) { cb(buf); });
        }
        function next() {
          if (i >= list.length) return finish(null);
          var name = list[i++];
          xhrBuf(SFX_BASE + name, function(ab) {
            var ctx = audioCtx();
            if (!ctx) return finish(null);
            try {
              ctx.decodeAudioData(ab, function(buf) { finish(buf, name); }, function() { next(); });
            } catch (e) { next(); }
          }, next);
        }
        next();
      }
      scope.sfxFound = {};
      scope.reloadSfx = function() {
        sfxBuf = {};
        scope.sfxSlots.forEach(function(k) { loadSfx(k, function() {}); });
      };

      function playSfx(key, force) {
        if (scope.cfg.memeSfxOn === false && !force) return false;
        var now = Date.now();
        if (!force && key !== 'dead' && now - sfxState.last < 1200) return false;   // pushim që mos me u bo shumë
        sfxState.last = now;
        loadSfx(key, function(buf) {
          if (!buf) return;
          try {
            var ctx = audioCtx();
            if (sfxState.playing && key === 'dead') { try { sfxState.playing.stop(); } catch (e) {} }
            var src = ctx.createBufferSource(), g = ctx.createGain();
            g.gain.value = Math.max(0, Math.min(1, Number(scope.cfg.memeSfxVolume) || 0.7));
            src.buffer = buf; src.connect(g); g.connect(ctx.destination); src.start(0);
            sfxState.playing = src;
          } catch (e) {}
        });
        return true;
      }
      // ngarko paraprakisht kur hapet modi
      $timeout(function() { scope.reloadSfx(); }, 1500);
      scope.testSfx = function(k) { playSfx(k, true); };

      // thirret pas çdo rënie të survival-it
      function memeSfxOnDrop(drop) {
        if (scope.cfg.memeSfxOn === false) return;
        var v = Number(scope.survivalRawValue()) || 0;
        if (v <= 0) {
          if (!sfxState.deadPlayed) { sfxState.deadPlayed = true; sfxState.critPlayed = true; playSfx('dead'); }
          return;
        }
        if (Math.ceil(v) <= 5 && !sfxState.critPlayed) { sfxState.critPlayed = true; playSfx('critical', true); return; }
        if (drop >= 20) playSfx('bighit');
        else if (drop >= 8) playSfx('hit');
      }
      // kur survival-i kthehet lart (reset / makinë e re) lejo prap critical/dead
      scope.$watch(function() { return scope.survivalRawValue(); }, function(v) {
        v = Number(v) || 0;
        if (v > 5) sfxState.critPlayed = false;
        if (v > 0) sfxState.deadPlayed = false;
      });

      scope.toggleSurvivalSound = function() {
        scope.cfg.survivalSoundMode = (scope.cfg.survivalSoundMode || 'off') === 'off' ? 'both' : 'off';
        scope.persist();
        startSurvivalSound();
      };

      scope.testSurvivalSound = function() {
        var vol = soundVolume();
        playThump(vol, 76);
        setTimeout(function() { playThump(vol * 0.72, 60); }, 165);
        setTimeout(function() { playCrashNoise(vol * 0.5); }, 520);
        setTimeout(function() { playBeep(880, vol * 0.45, 0.12, 'square'); }, 900);
      };

      // Browseri kerkon nje veprim te perdoruesit para se te leshoje ze.
      function resumeAudioOnGesture() {
        try {
          if (!scope.survivalSoundOn()) return;
          var ctx = audioCtx();
          if (ctx && ctx.state === 'running') {
            $document.off('mousedown', resumeAudioOnGesture);
            $document.off('keydown', resumeAudioOnGesture);
          }
        } catch (e) {}
      }
      $document.on('mousedown', resumeAudioOnGesture);
      $document.on('keydown', resumeAudioOnGesture);

      // =====================================================
      // v5.2 — STREAM MODE (nje tast: fsheh panelin, rrumullakat, guidat)
      // =====================================================
      scope.streamModeOn = function() { return scope.cfg.streamMode === true; };

      scope.toggleStreamMode = function() {
        if (scope.cfg.streamMode) {
          scope.cfg.streamMode = false;
          var p = scope.cfg.streamPrev || {};
          if (p.vehiclesOn !== undefined) scope.cfg.vehiclesOn = p.vehiclesOn;
          if (p.guidesOn !== undefined) scope.cfg.guidesOn = p.guidesOn;
          if (p.showPanel !== undefined) scope.cfg.showPanel = p.showPanel;
          if (p.survivalOn !== undefined) scope.cfg.survivalOn = p.survivalOn;
        } else {
          scope.cfg.streamPrev = {
            vehiclesOn: scope.cfg.vehiclesOn !== false,
            guidesOn: scope.cfg.guidesOn === true,
            showPanel: scope.cfg.showPanel !== false,
            survivalOn: scope.cfg.survivalOn !== false
          };
          scope.cfg.streamMode = true;
          scope.cfg.vehiclesOn = false;     // vetem Survival Chance ne ekran
          scope.cfg.guidesOn = false;
          scope.cfg.showPanel = false;      // paneli fshihet per regjistrim
          scope.cfg.survivalOn = true;
          scope.survival.visible = true;
        }
        scope.persist();
      };

      // Demo: nje sekuence e shpejte dramatikе per te provuar efektet.
      scope.testDramaticDrop = function() {
        var it = activeCostItem(); if (!it) return;
        var old = Number(it.survivalChance); if (!isFinite(old)) old = 100;
        var next = Math.max(0, old - 34);
        it.survivalChance = next;
        animateSurvivalDisplay(next);
        showSurvivalDelta(old - next, old);
        scope.persist();
      };

      scope.startSurvivalDrag = function(evt) {
        if (!scope.cfg.survivalEditPosition || !evt) return;
        evt.preventDefault(); evt.stopPropagation();
        measureViewport();
        function move(ev) {
          scope.$applyAsync(function() {
            scope.cfg.survivalPosX = Math.max(0, Math.min(100, ev.clientX / Math.max(1, scope.viewport.w) * 100));
            scope.cfg.survivalPosY = Math.max(0, Math.min(100, ev.clientY / Math.max(1, scope.viewport.h) * 100));
          });
        }
        function up() {
          $document.off('mousemove', move); $document.off('mouseup', up); scope.persist();
        }
        $document.on('mousemove', move); $document.on('mouseup', up);
      };

      scope.resetSurvival = function() {
        angular.forEach(scope.cfg.items, function(it) { if (it) it.survivalChance = 100; });
        scope.survival.deltaVisible = false; scope.survival.pulse = false; scope.survival.rolling = false; scope.survival.visible = true; syncSurvivalDisplay(); scope.persist();
      };

      scope.testSurvivalDrop = function() {
        var it = activeCostItem(); if (!it) return;
        var old = Number(it.survivalChance); if (!isFinite(old)) old = 100;
        var next = Math.max(0, old - 5); it.survivalChance = next; animateSurvivalDisplay(next); showSurvivalDelta(old-next, old); scope.persist();
      };

      // ---- legacy/internal cost values ----
      scope.currentCost = function() {
        var it = scope.cfg.items[scope.selected];
        return it ? (Number(it.costNow) || 0) : 0;
      };

      scope.costOfItem = function(item) {
        return item ? (Number(item.costNow) || 0) : 0;
      };

      scope.formatMoney = function(v) {
        v = Math.round(Number(v) || 0);
        var cur = scope.cfg.costCurrency || '$';
        if (scope.cfg.costCompactText) {
          if (v >= 1000000) return cur + (v/1000000).toFixed(1) + 'M';
          if (v >= 1000) return cur + (v/1000).toFixed(v >= 10000 ? 0 : 1) + 'K';
        }
        return cur + v.toLocaleString('en-US');
      };

      scope.costText = function() {
        // nese po ndjek nje rreth te markuar, trego koston e atij
        if (scope.costFollowIdx >= 0) {
          var f = scope.cfg.items[scope.costFollowIdx];
          if (f) return scope.formatMoney(f.costNow);
        }
        return scope.formatMoney(scope.currentCost());
      };

      scope.costTotal = function() {
        var t = 0;
        angular.forEach(scope.cfg.items, function(it) {
          if (it && it.enabled !== false) t += (Number(it.costNow) || 0);
        });
        return t;
      };

      scope.costVisible = function () {
        // v3.4: kur aktivizohet shiriti i madh, ne qender shfaqet VETEM
        // progress line — pa kartelë, pa sfond te zi dhe pa tekst te madh.
        return scope.cfg.costOn === true && scope.cfg.costBigOn === true;
      };

      // ---- pozicionimi ----
      // Normalisht: ne mes poshte rratheve.
      // Kur shtypet PASS/FAIL: kalon mbi ate rreth per disa sekonda.
      function itemCenter(idx) {
        var n = 0, order = [];
        angular.forEach(scope.cfg.items, function(it, i) {
          if (it && it.enabled !== false) { order.push(i); n++; }
        });
        var pos = order.indexOf(idx);
        if (pos < 0) return null;

        var lay = scope.cfg.layout || 'row';
        var size = Number(scope.cfg.itemSize) || 112;
        var gap  = Number(scope.cfg.gap) || 0;
        var cols = n, row = 0, col = pos;

        if (lay === 'column') { cols = 1; row = pos; col = 0; }
        else if (lay === 'grid') {
          cols = Math.max(1, Number(scope.cfg.gridCols) || 4);
          row = Math.floor(pos / cols);
          col = pos % cols;
        }

        var x = Number(scope.cfg.positionX || 0) + col * (size + gap) + size / 2;
        var y = Number(scope.cfg.positionY || 0) + row * (size + gap);
        return { x: x, y: y, size: size };
      }

      scope.costStyle = function () {
        // v3.4: progress line clean, transparent, pa card/sfond.
        var scale = scope.cost.pulse ? 1.04 : 1;
        var left = Number(scope.cfg.costPosX || 50) + '%';
        var top  = Number(scope.cfg.costPosY || 80) + '%';
        if (scope.cfg.costAuto) {
          var n = 0;
          angular.forEach(scope.cfg.items, function (it) { if (it && it.enabled !== false) n++; });
          if (n < 1) n = 1;
          var lay = scope.cfg.layout || 'row';
          var cols = n, rows = 1;
          if (lay === 'column') { cols = 1; rows = n; }
          else if (lay === 'grid') {
            cols = Math.max(1, Number(scope.cfg.gridCols) || 4);
            rows = Math.ceil(n / cols);
            if (n < cols) cols = n;
          }
          var size = Number(scope.cfg.itemSize) || 112;
          var gap  = Number(scope.cfg.gap) || 0;
          var labelH = scope.cfg.showLabels ? (Number(scope.cfg.labelSize) || 13) + 12 : 0;
          var hudW = cols * size + (cols - 1) * gap;
          var hudH = rows * size + (rows - 1) * gap + labelH;
          left = Math.round(Number(scope.cfg.positionX || 0) + hudW / 2) + 'px';
          top = Math.round(Number(scope.cfg.positionY || 0) + hudH + Number(scope.cfg.costGap || 40)) + 'px';
          return { left:left, top:top, transform:'translateX(-50%) scale(' + scale + ')' };
        }
        return { left:left, top:top, transform:'translate(-50%, -50%) scale(' + scale + ')' };
      };

      scope.costLabelStyle = function () {
        return {
          fontSize: Math.max(9, Math.round(Number(scope.cfg.costSize || 64) * 0.34)) + 'px',
          color: scope.cfg.costLabelColor || '#ffffff'
        };
      };

      scope.costValueStyle = function () {
        return {
          display: 'none'
        };
      };

      scope.costBarColor = function () {
        var it = activeCostItem();
        var now = it ? Math.max(0, Number(it.costNow) || 0) : 0;
        // Smooth 4-stage transition: green -> yellow -> orange -> red.
        var stops = [
          {v:0, c:[61,255,136]},
          {v:3000, c:[220,255,70]},
          {v:7000, c:[255,175,55]},
          {v:10000, c:[255,70,70]}
        ];
        if (now >= 10000) return '#ff4646';
        var a=stops[0], b=stops[1];
        for (var i=0;i<stops.length-1;i++) {
          if (now >= stops[i].v && now <= stops[i+1].v) { a=stops[i]; b=stops[i+1]; break; }
        }
        var t=(now-a.v)/Math.max(1,b.v-a.v);
        var rgb=a.c.map(function(x,j){ return Math.round(x+(b.c[j]-x)*t); });
        return 'rgb('+rgb.join(',')+')';
      };

      scope.costBarStyle = function () {
        var it = activeCostItem();
        var max = it ? Math.max(1, Number(it.costMax) || 1) : 1;
        var now = it ? Math.max(0, Number(it.costNow) || 0) : 0;
        var col = scope.costBarColor();
        return {
          width: Math.max(0, Math.min(100, (now / max) * 100)) + '%',
          background: col,
          boxShadow: scope.cfg.costGlow === false ? 'none' : '0 0 12px ' + col,
          transition: 'width 220ms cubic-bezier(.22,1,.36,1), background 500ms ease, box-shadow 500ms ease'
        };
      };

      // kostoja e vogel nen secilin rreth
      scope.circleCostStyle = function(item) {
        var top = scope.cfg.showLabels ? (Number(scope.cfg.labelSize) || 13) + 12 : 6;
        var col = scope.cfg.costCircleColor || scope.cfg.costColor || '#3dff88';
        if (scope.cfg.costColorByState && item) {
          if (item.state === 'pass') col = scope.cfg.costPassColor || '#3dff88';
          else if (item.state === 'fail') col = scope.cfg.costFailColor || '#ff5b5b';
        }
        return {
          marginTop: top + 'px',
          fontSize: Math.max(10, Math.round(Number(scope.cfg.itemSize || 112) * 0.16)) + 'px',
          color: col
        };
      };

      // ---- reset ----
      scope.resetCost = function() {
        engineLua("if extensions.creatorpack and extensions.creatorpack.resetCost then "
                + "extensions.creatorpack.resetCost() end");
        costLast = 0;
        angular.forEach(scope.cfg.items, function(it, idx) {
          if (it) { it.costNow = 0; it.damageRatio = 0; it.damagePulse = false; it.visited = idx === 0; it.survivalChance = 100; it.costLocked = false; }
        });
        scope.costFollowIdx = -1;
        syncSurvivalDisplay();
        scope.persist();
      };

      // v3.1.4: helper i perbashket (function declaration -> hoisted, i
      // perdorshem edhe nga next()/prev() qe ndodhen me poshte ne skedar).
      function releaseFollow() {
        if (followTimer) { try { $timeout.cancel(followTimer); } catch (e) {} }
        scope.costFollowIdx = -1;
      }

      // v3.1.2: hiq etiketen ngjitese nga rrethi (pa prekur vlerat)
      scope.clearCostFollow = function() {
        if (followTimer) { try { $timeout.cancel(followTimer); } catch (e) {} }
        scope.costFollowIdx = -1;
      };

      // v3.1.4: zero VETEM kostot, shenjat PASS/FAIL mbeten
      scope.resetAllCosts = function() {
        angular.forEach(scope.cfg.items, function(it, idx) {
          it.costNow = 0;
          it.damageRatio = 0;
          it.damagePulse = false;
          it.visited = idx === 0;
          it.survivalChance = 100;
          it.costLocked = false;
        });
        costLast = 0;
        releaseFollow();
        engineLua("if extensions.creatorpack and extensions.creatorpack.resetCost then "
                + "extensions.creatorpack.resetCost() end");
        syncSurvivalDisplay();
        scope.persist();
      };

      scope.resetCostOne = function(item) {
        if (!item) return;
        item.costNow = 0;
        item.damageRatio = 0;
        item.damagePulse = false;
        item.visited = true;
        item.survivalChance = 100;
        item.costLocked = false;
        costLast = 0;
        engineLua("if extensions.creatorpack and extensions.creatorpack.resetCost then "
                + "extensions.creatorpack.resetCost() end");
        scope.persist();
      };

      scope.applyMaxToAll = function() {
        var v = Number(scope.cfg.costDefaultMax) || 0;
        angular.forEach(scope.cfg.items, function(it) { if (it) it.costMax = v; });
        scope.persist();
      };

      // =====================================================
      // UNDO (Ctrl+Z)
      // =====================================================
      var undoStack = [];
      var UNDO_MAX = 40;

      function pushUndo(label) {
        try {
          undoStack.push({
            label: label || 'veprim',
            states: scope.cfg.items.map(function(it) { return it.state; }),
            selected: scope.selected
          });
          if (undoStack.length > UNDO_MAX) undoStack.shift();
        } catch (e) {}
      }

      scope.canUndo = function() { return undoStack.length > 0; };

      scope.undo = function() {
        var snap = undoStack.pop();
        if (!snap) return;
        angular.forEach(scope.cfg.items, function(it, i) {
          if (snap.states[i] !== undefined) {
            it.state = snap.states[i];
            if (it.state === 'pending') it.costLocked = false;
          }
        });
        scope.costFollowIdx = -1;
        scope.selected = snap.selected;
        scope.persist();
      };

      // =====================================================
      // PRESETS
      // =====================================================
      scope.presetName = '';

      // Cka ruhet ne preset: pamja/stili, JO fotot dhe JO rezultatet
      var PRESET_FIELDS = ['positionX','positionY','panelX','panelY','itemSize','gap','imageScale',
        'showArrows','showMarks','markSize','markPos','markOffsetX','markOffsetY','markSoundVolume','circleShape','outlineWidth','glow',
        'pendingFillOpacity','pendingOutlineOpacity','fxPosX','fxPosY','fxScale',
        'theme','layout','gridCols','animLevel','showLabels','labelSize',
        'costOn','costAuto','costPosX','costPosY','costGap','costSize','costLabel',
        'costLabelText','costCurrency','costColor','costLabelColor','costPulse',
        'costStick','costCircleColor','costColorByState','costPassColor','costFailColor',
        'costBigOn','costSens',
        'costPerCircle','costFollowMark','costFollowMs','costDefaultMax','costAutoMax','costVehicleFactor',
        'costStyleClass','costFontWeight','costCurve','costMinDamage','costShowBar','costCompactText','costGlow',
        'costPosX','costPosY','costSize','costGap','costLabel','costPulse','costCurrency','costLabelText',
        'hudDensity','theme','itemSize','gap','outlineWidth','glow','showArrows','showLabels','showMarks','markSize',
        'showMiniButton','soundOn',
        'vehiclesOn','vehiclesKey','liveOn','liveFlip','liveView','autoPhotoOnSwitch','autoPhotoNext','autoPhotoTolerance',
        'survivalOn','survivalPosX','survivalPosY','survivalSize','survivalSensitivity',
        'survivalLabelText','survivalLabelColor','survivalValueColor','survivalDeltaColor','survivalDynamicColor',
        'survivalWarningColor','survivalCriticalColor','survivalColorProfileVersion','survivalWarningThreshold','survivalCriticalThreshold',
        'survivalLayout','survivalBackground','survivalBackgroundColor','survivalBackgroundOpacity',
        'survivalShowLabel','survivalShowStatus','survivalStatusSize','survivalStatusSpacing','survivalStatusWeight','survivalStatusPosition','survivalStatusPulse','survivalEmojiOn','survivalEmojiMode','survivalEmojiSize','survivalEmojiPop','survivalEmojiProfileVersion',
        'survivalShowMeter','survivalShowPercent','survivalLabelScale',
        'survivalFontFamily','survivalFontWeight','survivalItalic','survivalOutline','survivalGlow','survivalDecimals',
        'survivalShowDelta','survivalDeltaDuration','survivalDeltaMin','survivalDeltaPosition','survivalDeltaSize','survivalDeltaGhosts','survivalRollingCounter','survivalRollDuration','survivalSmoothTime','survivalAnimationProfileVersion',
        'survivalImpactShake','survivalLowPulse','survivalDisplayMode','survivalAutoHideMs','survivalDangerShowAt',
        'survivalFormula','survivalDamageWeight','survivalImpactWeight','survivalSpeedWeight','survivalMinAlive'];

      scope.savePreset = function() {
        var name = (scope.presetName || '').trim();
        if (!name) { scope.storageWarning = 'Shkruaj nje emer per preset-in.'; return; }
        var data = {};
        angular.forEach(PRESET_FIELDS, function(k) { data[k] = scope.cfg[k]; });

        var existing = null;
        angular.forEach(scope.cfg.presets, function(p) { if (p.name === name) existing = p; });
        if (existing) { existing.data = data; existing.updatedAt = Date.now(); }
        else scope.cfg.presets.push({ name: name, data: data, updatedAt: Date.now() });

        scope.presetName = '';
        scope.persist();
      };

      scope.loadPreset = function(preset) {
        if (!preset || !preset.data) return;
        angular.forEach(preset.data, function(v, k) { scope.cfg[k] = v; });
        scope.persist();
      };

      scope.deletePreset = function(preset) {
        var i = scope.cfg.presets.indexOf(preset);
        if (i >= 0) scope.cfg.presets.splice(i, 1);
        scope.persist();
      };

      // =====================================================
      // EXPORT / IMPORT
      // =====================================================
      scope.exportText = '';
      scope.importText = '';

      scope.buildExport = function() {
        var out = angular.extend({}, scope.cfg);
        // hiq fotot base64 qe teksti te mos jete gjigant
        out.items = (scope.cfg.items || []).map(function(it) {
          var c = angular.extend({}, it);
          c.image = it.image ? '[image]' : '';
          return c;
        });
        scope.exportText = JSON.stringify(out, null, 2);
      };

      scope.applyImport = function() {
        try {
          var parsed = JSON.parse(scope.importText);
          if (!parsed || typeof parsed !== 'object') throw new Error('bad');
          // ruaj fotot ekzistuese
          var oldImages = (scope.cfg.items || []).map(function(it) { return it.image; });
          scope.cfg = normalizeConfig(parsed, defaults());
          angular.forEach(scope.cfg.items, function(it, i) {
            if (it.image === '[image]' || !it.image) it.image = oldImages[i] || '';
          });
          scope.selected = 0;
          scope.persist();
          scope.storageWarning = 'Konfigurimi u importua.';
        } catch (e) {
          scope.storageWarning = 'Teksti nuk eshte JSON i vlefshem.';
        }
      };

      scope.exportResults = function() {
        var lines = ['#,Emri,Rezultati'];
        angular.forEach(scope.cfg.items, function(it, i) {
          if (it.enabled === false) return;
          lines.push((i + 1) + ',"' + String(it.label || '').replace(/"/g, '""') + '",' + (it.state || 'pending'));
        });
        lines.push('');
        var np = 0, nf = 0;
        angular.forEach(scope.cfg.items, function(it) {
          if (!it || it.enabled === false) return;
          if (it.state === 'pass') np++;
          else if (it.state === 'fail') nf++;
        });
        var done = np + nf;
        lines.push('PASS,' + np);
        lines.push('FAIL,' + nf);
        lines.push('Perqindja,' + (done > 0 ? Math.round((np / done) * 100) : 0) + '%');
        scope.exportText = lines.join('\n');
      };

      scope.select = function(i) {
        scope.selected = i;
        if (scope.cfg.items[i]) scope.cfg.items[i].visited = true;
        syncSurvivalDisplay();
        // Kur zgjedh nje makine tjeter, kostoja ne mes i perket asaj makine,
        // jo rrethit te makines se kaluar.
        releaseFollow();
        costLast = Number((scope.cfg.items[i] && scope.cfg.items[i].costNow) || 0);
        scope.persist();
      };

      scope.addItem = function() {
        var idx = scope.cfg.items.length + 1;
        scope.cfg.items.push({
          label: 'Makina ' + idx,
          image: '',
          enabled: true,
          state: 'pending',
          imageScale: scope.cfg.imageScale || 1.0,
          imageOffsetX: 0,
          imageOffsetY: 0,
          imageRotation: 0,
          costMax: Number(scope.cfg.costDefaultMax) || 10000,
          costNow: 0,
          damageRatio: 0,
          damagePulse: false,
          visited: true,
          survivalChance: 100,
          costLocked: false
        });
        scope.selected = scope.cfg.items.length - 1;
        scope.persist();
      };

      scope.removeItem = function(index) {
        if (scope.cfg.items.length <= 1) return;
        scope.cfg.items.splice(index, 1);
        if (scope.selected >= scope.cfg.items.length) scope.selected = scope.cfg.items.length - 1;
        scope.persist();
      };

      scope.moveItem = function(index, delta) {
        var j = index + delta;
        if (j < 0 || j >= scope.cfg.items.length) return;
        var tmp = scope.cfg.items[index];
        scope.cfg.items[index] = scope.cfg.items[j];
        scope.cfg.items[j] = tmp;
        if (scope.selected === index) scope.selected = j;
        else if (scope.selected === j) scope.selected = index;
        scope.persist();
      };

      scope.resetStates = function() {
        pushUndo('reset');
        angular.forEach(scope.cfg.items, function(item, idx) {
          item.state = 'pending';
          item.markedAt = null;
          item.costNow = 0;
          item.damageRatio = 0;
          item.damagePulse = false;
          item.visited = idx === 0;
          item.survivalChance = 100;
          item.costLocked = false;
        });
        costLast = 0;
        scope.costFollowIdx = -1;
        scope.selected = 0;
        syncSurvivalDisplay();
        scope.persist();
      };

      // v5.9.10: "Fshi fotot" — dy klikime (pa dialog), pastron edhe modelin e ruajtur
      scope.clearArmed = false;
      scope.clearAllImages = function() {
        if (!scope.clearArmed) {
          scope.clearArmed = true;
          autoMsg('🗑️ Kliko edhe njëherë për me i fshi TË GJITHA fotot e rrathëve');
          $timeout(function(){ scope.clearArmed = false; }, 5000);
          return;
        }
        scope.clearArmed = false;
        var n = 0;
        angular.forEach(scope.cfg.items, function(item) {
          if (item && item.image) { item.image = ''; item.imageModel = ''; n++; }
        });
        scope.cfg.photoArchive = {};                 // v5.10.1: fshij edhe arkiven
        scope.lastShotPreview = ''; scope.lastShotInfo = '';
        scope.persist();
        autoMsg(n ? ('🗑️ U fshinë ' + n + ' foto — tash Ctrl+1 / Ctrl+2 i mbush një nga një në rrathët bosh')
                 : '🗑️ S\'kishte foto për me fshi');
      };

      scope.togglePanel = function() {
        scope.cfg.showPanel = !scope.cfg.showPanel;
        scope.persist();
      };

      scope.openPanel = function() {
        scope.cfg.showPanel = true;
        scope.persist();
      };

      scope.closePanel = function() {
        scope.cfg.showPanel = false;
        scope.persist();
      };

      scope.hudStyle = function() {
        var st = {
          left: Number(scope.cfg.positionX || 0) + 'px',
          top: Number(scope.cfg.positionY || 0) + 'px',
          gap: Number(scope.cfg.gap || 0) + 'px'
        };

        var lay = scope.cfg.layout || 'row';
        if (lay === 'grid') {
          var cols = Math.max(1, Number(scope.cfg.gridCols) || 4);
          st.display = 'grid';
          st.gridTemplateColumns = 'repeat(' + cols + ', auto)';
          st.alignItems = 'center';
          st.justifyItems = 'center';
        } else if (lay === 'column') {
          st.display = 'flex';
          st.flexDirection = 'column';
          st.alignItems = 'center';
        } else {
          st.display = 'flex';
          st.flexDirection = 'row';
          st.alignItems = 'flex-start';
        }
        return st;
      };


      scope.panelStyle = function() {
        return {
          left: Number(scope.cfg.panelX || 18) + 'px',
          top: Number(scope.cfg.panelY || 112) + 'px'
        };
      };

      scope.startPanelDrag = function(evt) {
        if (!evt || (evt.target && evt.target.closest && evt.target.closest('button,input,select,label'))) return;
        var startX = evt.clientX;
        var startY = evt.clientY;
        var baseX = Number(scope.cfg.panelX || 18);
        var baseY = Number(scope.cfg.panelY || 112);
        function move(ev) {
          scope.$applyAsync(function() {
            scope.cfg.panelX = Math.max(0, baseX + (ev.clientX - startX));
            scope.cfg.panelY = Math.max(0, baseY + (ev.clientY - startY));
            scope.persist();
          });
        }
        function up() {
          $document.off('mousemove', move);
          $document.off('mouseup', up);
        }
        $document.on('mousemove', move);
        $document.on('mouseup', up);
        if (evt.preventDefault) evt.preventDefault();
      };

      scope.itemStyle = function(item) {
        var size = Number(scope.cfg.itemSize || 112);
        var radius = '50%';
        if (String(scope.cfg.circleShape).toLowerCase() === 'rounded') radius = '18px';
        if (String(scope.cfg.circleShape).toLowerCase() === 'square') radius = '0px';

        var borderColor = 'rgba(255,255,255,' + Number(scope.cfg.pendingOutlineOpacity || 0.08) + ')';
        var boxShadow = '0 0 ' + Number(scope.cfg.glow || 8) + 'px rgba(0,0,0,0.12)';

        if (item.state === 'pass') {
          borderColor = 'rgba(104,255,164,0.98)';
          boxShadow = '0 0 ' + Number(scope.cfg.glow || 8) + 'px rgba(104,255,164,0.28)';
        } else if (item.state === 'fail') {
          borderColor = 'rgba(255,88,88,0.98)';
          boxShadow = '0 0 ' + Number(scope.cfg.glow || 8) + 'px rgba(255,88,88,0.25)';
        }

        return {
          width: size + 'px',
          height: size + 'px',
          borderRadius: radius,
          borderWidth: Number(scope.cfg.outlineWidth || 4) + 'px',
          borderColor: borderColor,
          boxShadow: boxShadow,
          opacity: item.enabled === false ? 0.18 : 1,   // v5.9.8: fotot ne rrathë duken GJITHMONE (ma pare 0.38)
          background: 'rgba(0,0,0,' + Number(scope.cfg.pendingFillOpacity || 0.16) + ')'
        };
      };

      scope.imageStyle = function(item) {
        var scale = item.imageScale != null ? item.imageScale : scope.cfg.imageScale || 1.0;
        var percent = Math.round(scale * 100);
        var ox = Number(item.imageOffsetX || 0);
        var oy = Number(item.imageOffsetY || 0);
        return {
          width: percent + '%',
          height: percent + '%',
          left: '50%',
          top: '50%',
          transform: 'translate(-50%, -50%) translate(' + ox + 'px,' + oy + 'px)'
        };
      };


      scope.imageBgStyle = function(item) {
        var scale = item.imageScale != null ? item.imageScale : scope.cfg.imageScale || 1.0;
        var ox = Number(item.imageOffsetX || 0);
        var oy = Number(item.imageOffsetY || 0);
        var rot = Number(item.imageRotation || 0);
        var idx = scope.cfg.items.indexOf(item);
        var active = idx === scope.selected;
        var finalScale = scale * 1.55 * (active ? 1.10 : 1.0);
        return {
          backgroundImage: item.image ? ('url(' + item.image + ')') : 'none',
          backgroundSize: Math.round(finalScale * 100) + '%',
          backgroundPosition: 'calc(50% + ' + ox + 'px) calc(50% + ' + oy + 'px)',
          opacity: 1,   // v5.9.7: fotot ne rrumullak duken GJITHMONE, jo vetem kur kalon mbi to
          transform: 'translateZ(0) rotate(' + rot + 'deg)'
        };
      };



      // v5.10: shenja ✓/✕ — pozicioni (mes / mbi / nen rreth) + zhvendosja
      scope.markPosClass = function() {
        var p = scope.cfg.markPos || 'center';
        return p === 'above' ? 'pos-above' : (p === 'under' ? 'pos-under' : 'pos-center');
      };
      scope.markStyle = function() {
        var base = Math.max(12, Math.round(Number(scope.cfg.itemSize || 112) * Number(scope.cfg.markSize || 0.82)));
        return {
          fontSize: base + 'px',
          transform: 'translate(' + Number(scope.cfg.markOffsetX || 0) + 'px,' + Number(scope.cfg.markOffsetY || 0) + 'px)'
        };
      };
      scope.setMarkPos = function(v) {
        scope.cfg.markPos = (v === 'above' || v === 'under') ? v : 'center';
        scope.persist();
      };
      scope.resetMarkOffset = function() {
        scope.cfg.markOffsetX = 0;
        scope.cfg.markOffsetY = 0;
        scope.persist();
      };

      // v5.9.7: efekti full-screen i PASS/FAIL (X/check i madh mes ekranit +
      // ngjyra anash) u HOQ KREJT. PASS/FAIL tani duket VETEM ne rrumullak
      // (unaza + shenja brenda rrethit). Funksioni mbetet bosh per siguri.
      scope.fxMarkStyle = function() { return {}; };
      scope.triggerOverlayFx = function() {};

      scope.stateClass = function(item, index) {
        var cls = 'pf-item';
        cls += ' state-' + (item.state || 'pending');
        if (index === scope.selected) cls += ' is-selected';
        if (item && item.pulse) cls += ' pf-pulse';
        if (item && item.damagePulse) cls += ' damage-hit';
        if (item.enabled === false) cls += ' is-disabled';
        return cls;
      };

      // v3.2.1 AUDIO FIX:
      // Perdoren skedaret MP3 te perfshire ne mod ne vend te WebAudio synth.
      // Kjo shmang problemet e AudioContext/autoplay ne CEF dhe ben qe
      // PASS/FAIL te kene efektet reale te zerit qe jane ne paket.
      // v5.10: zerat vijne TE PAKETUAR ne mod (sounds/pass.mp3 = ka-ching,
      // sounds/fail.mp3 = wrong-answer buzzer). Nese mungojne, provohen edhe
      // rruget e vjetra (ma heret pritej qe perdoruesi me i qit vete).
      var PF_SOUND_BASE = '/ui/modules/apps/CreatorPack/';
      var PF_SOUND_URLS = {
        pass: [PF_SOUND_BASE + 'sounds/pass.mp3', PF_SOUND_BASE + 'pass.mp3'],
        fail: [PF_SOUND_BASE + 'sounds/fail.mp3', PF_SOUND_BASE + 'fail.mp3']
      };
      var pfSounds = {}, pfSoundTry = { pass: 0, fail: 0 };

      var pfBuf = {}, pfLoading = {};

      // v5.10: i njejti mekanizem si MEME SFX (XHR + decodeAudioData) —
      // ne BeamNG CEF ky osht ma i sigurt se elementi <audio>.
      function loadPFBuffer(kind, done) {
        if (pfBuf[kind]) return done(pfBuf[kind]);
        if (pfLoading[kind]) { pfLoading[kind].push(done); return; }
        pfLoading[kind] = [done];
        var list = PF_SOUND_URLS[kind], i = 0;
        function finish(buf) {
          pfBuf[kind] = buf || null;
          var cbs = pfLoading[kind]; delete pfLoading[kind];
          (cbs || []).forEach(function(cb) { try { cb(buf); } catch (e) {} });
        }
        function next() {
          if (i >= list.length) return finish(null);
          xhrBuf(list[i++], function(ab) {
            var ctx = audioCtx();
            if (!ctx) return finish(null);
            try { ctx.decodeAudioData(ab, function(buf) { finish(buf); }, function() { next(); }); }
            catch (e) { next(); }
          }, next);
        }
        next();
      }

      function playPFBuffer(kind) {
        var buf = pfBuf[kind];
        if (!buf) { loadPFBuffer(kind, function() {}); return false; }
        try {
          var ctx = audioCtx();
          if (!ctx) return false;
          var src = ctx.createBufferSource(), g = ctx.createGain();
          g.gain.value = markSoundVolume();
          src.buffer = buf; src.connect(g); g.connect(ctx.destination); src.start(0);
          return true;
        } catch (e) { return false; }
      }

      function markSoundVolume() {
        var v = Number(scope.cfg.markSoundVolume);
        if (isNaN(v)) v = 0.85;
        return Math.max(0, Math.min(1, v));
      }

      function initPFSounds() {
        try {
          if (!$window.Audio) return;
          angular.forEach(PF_SOUND_URLS, function(list, kind) {
            var a = new $window.Audio();
            a.preload = 'auto';
            a.volume = markSoundVolume();
            a.onerror = function() {
              var i = (pfSoundTry[kind] || 0) + 1;
              if (i < list.length) {
                pfSoundTry[kind] = i;
                try { a.src = list[i]; a.load(); } catch (e) {}
              }
            };
            a.src = list[0];
            try { a.load(); } catch (e) {}
            pfSounds[kind] = a;
            loadPFBuffer(kind, function() {});   // v5.10: parangarko edhe buferin WebAudio
          });
        } catch (e) {}
      }

      initPFSounds();

      function playPFSound(kind) {
        // v5.10: provo pare buferin e dekoduar (WebAudio), pastaj elementin <audio>
        if (playPFBuffer(kind)) return true;
        try {
          var base = pfSounds[kind];
          if (!base) return false;

          // Klonimi lejon tingullin te rifilloje edhe nese nje efekt tjeter
          // eshte ende duke u luajtur.
          var audio = base.cloneNode(true);
          audio.volume = markSoundVolume();   // v5.10
          var p = audio.play();
          if (p && p.catch) p.catch(function() {
            // Fallback te objekti i preload-uar.
            try {
              base.currentTime = 0;
              base.volume = markSoundVolume();   // v5.10
              var bp = base.play();
              if (bp && bp.catch) bp.catch(function(){});
            } catch (x) {}
          });
          return true;
        } catch (e) {
          return false;
        }
      }

      function beep(kind) {
        if (!scope.cfg.soundOn) return;
        playPFSound(kind);
      }

      scope.testSound = function(kind) { playPFSound(kind); };

      scope.markState = function(state, index) {
        if (index === undefined || index === null) index = scope.selected;
        var item = scope.cfg.items[index];
        if (!item || item.enabled === false) return;

        pushUndo('mark');
        item.state = state;
        item.markedAt = Date.now();

        // v3.1: ngrij koston e kesaj makine dhe coje etiketen mbi ate rreth
        item.costLocked = true;
        costLast = 0;   // makina tjeter fillon nga e para

        if (scope.cfg.costOn && scope.cfg.costFollowMark) {
          scope.costFollowIdx = index;
          if (followTimer) { try { $timeout.cancel(followTimer); } catch (e) {} }
          // v3.1.2: me costStick, etiketa MBETET mbi ate rreth pa afat.
          if (!scope.cfg.costStick) {
            followTimer = $timeout(function() {
              scope.costFollowIdx = -1;
            }, Math.max(400, Number(scope.cfg.costFollowMs) || 2500));
          }
        }

        // dem i ri per makinen tjeter
        engineLua("if extensions.creatorpack and extensions.creatorpack.resetCost then "
                + "extensions.creatorpack.resetCost() end");

        beep(state);
        scope.triggerOverlayFx(state);

        // pulsim i shkurter mbi item-in e markuar
        if (scope.cfg.animLevel !== 'off') {
          item.pulse = true;
          $timeout(function() { item.pulse = false; }, 420);
        }

        // kalo automatikisht te itemi tjeter i pamarkuar
        if (scope.cfg.autoAdvance) {
          var nextIdx = findNextPending(index);
          if (nextIdx !== -1) {
            scope.selected = nextIdx;
            scope.cfg.items[nextIdx].visited = true;
            syncSurvivalDisplay();
            // Mos e leme koston e makines se kaluar ne qender.
            // Makina e re duhet ta shfaqe koston e vet (zakonisht $0).
            releaseFollow();
            costLast = Number(scope.cfg.items[nextIdx].costNow || 0);
          }
        }

        scope.persist();
      };

      function findNextPending(from) {
        var n = scope.cfg.items.length;
        for (var step = 1; step <= n; step++) {
          var i = (from + step) % n;
          var it = scope.cfg.items[i];
          if (it && it.enabled !== false && it.state === 'pending') return i;
        }
        return -1;
      }

      scope.prev = function() {
        scope.selected = Math.max(0, scope.selected - 1);
        if (scope.cfg.items[scope.selected]) scope.cfg.items[scope.selected].visited = true;
        syncSurvivalDisplay();
        releaseFollow();
        costLast = Number((scope.cfg.items[scope.selected] && scope.cfg.items[scope.selected].costNow) || 0);
        scope.persist();
      };

      scope.next = function() {
        scope.selected = Math.min(scope.cfg.items.length - 1, scope.selected + 1);
        if (scope.cfg.items[scope.selected]) scope.cfg.items[scope.selected].visited = true;
        syncSurvivalDisplay();
        releaseFollow();
        costLast = Number((scope.cfg.items[scope.selected] && scope.cfg.items[scope.selected].costNow) || 0);
        scope.persist();
      };

      scope.syncGlobalImageScale = function() {
        angular.forEach(scope.cfg.items, function(item) {
          if (item.imageScale === undefined || item.imageScale === null) item.imageScale = scope.cfg.imageScale;
        });
        scope.persist();
      };

      scope.clearSavedSettings = function() {
        try { localStorage.removeItem(STORAGE_KEY); } catch (e) {}
        scope.cfg = defaults();
        scope.selected = 0;
        syncSurvivalDisplay();
        scope.persist();
      };

      scope.keySummary = function() {
        return 'PASS K · FAIL L · PREV PageUp / Numpad4 · NEXT PageDown / Numpad6 · RESET G · PANEL H · CIRCLES ' +
               (scope.cfg.vehiclesKey || 'V').toUpperCase() + ' · STREAM ' + (scope.cfg.streamKey || 'B').toUpperCase();
      };



      // =====================================================
      // v5.9.0: AUTO FOTO — foto e makines + fshirje sfondi + rrumullak
      // =====================================================
      var autoPhotoTarget = null;
      scope.autoPhotoMsg = '';
      function autoMsg(t) { scope.autoPhotoMsg = t; $timeout(function(){ if (scope.autoPhotoMsg === t) scope.autoPhotoMsg = ''; }, 3500); }
      var AUTO_PHOTO_LUA = "(function()\n  local v = be:getPlayerVehicle(0)\n  if not v then return {err='no vehicle'} end\n  local function field(name)\n    local ok, r = pcall(function() return v[name] end)\n    if ok and type(r) == 'string' and r ~= '' then return r end\n    if v.getField then\n      ok, r = pcall(function() return v:getField(name, '') end)\n      if ok and type(r) == 'string' and r ~= '' then return r end\n    end\n    return nil\n  end\n  local m = field('JBeam') or 'vehicle'\n  local ck = string.match(field('partConfig') or '', '([^/\\\\]+)%.pc$')\n  local out, seen = {}, {}\n  local function add(p)\n    if type(p) == 'string' and p ~= '' then\n      if string.sub(p, 1, 1) ~= '/' then p = '/' .. p end\n      if not seen[p] and #out < 40 then seen[p] = true; table.insert(out, p) end\n    end\n  end\n  local name = m\n  pcall(function()\n    local d = core_vehicles.getCurrentVehicleDetails()\n    if d then\n      if type(d.configs) == 'table' then add(d.configs.preview); name = d.configs.Name or name end\n      if type(d.current) == 'table' then add(d.current.preview) end\n      if type(d.model) == 'table' then\n        add(d.model.preview)\n        if d.model.Name then name = (d.model.Brand and (d.model.Brand .. ' ') or '') .. d.model.Name end\n      end\n    end\n  end)\n  pcall(function() local mi = core_vehicles.getModel(m); if mi and mi.model then add(mi.model.preview) end end)\n  if ck then add('/vehicles/' .. m .. '/' .. ck .. '.jpg'); add('/vehicles/' .. m .. '/' .. ck .. '.png') end\n  add('/vehicles/' .. m .. '/default.jpg'); add('/vehicles/' .. m .. '/default.png'); add('/vehicles/' .. m .. '/default.jpeg')\n  pcall(function()\n    for _, pat in ipairs({'*.jpg', '*.png', '*.jpeg'}) do\n      for _, f in ipairs(FS:findFiles('/vehicles/' .. m .. '/', pat, 0, false, false) or {}) do add(f) end\n    end\n  end)\n  return {paths = out, model = m, name = name}\nend)()";
      var autoPhotoWait = null;
      scope.autoPhoto = function(index) {
        autoPhotoTarget = (index == null) ? null : Number(index);
        autoMsg('📸 duke marrë foton…');
        if (autoPhotoWait) $timeout.cancel(autoPhotoWait);
        autoPhotoWait = $timeout(function(){ autoMsg('✗ Loja s\'u përgjigj. Fshij versionet e vjetra të CreatorPack te mods dhe rindize lojën.'); }, 6000);
        var sent = false;
        try {
          if (window.bngApi && typeof window.bngApi.engineLua === 'function') {
            window.bngApi.engineLua(AUTO_PHOTO_LUA, function(res) {
              scope.$applyAsync(function() {
                if (autoPhotoWait) { $timeout.cancel(autoPhotoWait); autoPhotoWait = null; }
                if (typeof res === 'string') { try { res = JSON.parse(res); } catch (e) {} }
                if (!res || res.err) { autoMsg('✗ ' + ((res && res.err) || 'pa përgjigje') ); return; }
                var paths = res.paths; if (paths && !Array.isArray(paths)) paths = Object.keys(paths).map(function(k){ return paths[k]; });
                if (window.console && console.log) console.log('[HUD PRO] autofoto (Lua): model=' + (res.model || '?') + ', foto=' + ((paths && paths.length) || 0) + ', emri=' + (res.name || '?'));
                handleAutoPhoto({ paths: paths || [], name: res.name, model: res.model, auto: false });
              });
            });
            sent = true;
          }
        } catch (e) {}
        if (!sent) engineLua("extensions.load('creatorpack'); if extensions.creatorpack and extensions.creatorpack.pfhudAutoPhoto then extensions.creatorpack.pfhudAutoPhoto() end");
      };
function colDist(d, i, r, g, b) { var dr = d[i]-r, dg = d[i+1]-g, db = d[i+2]-b; return Math.sqrt(dr*dr + dg*dg + db*db); }

function removeBackground(img, tol) {
  var MAX = 640, sc = Math.min(1, MAX / Math.max(img.naturalWidth || img.width, img.naturalHeight || img.height));
  var w = Math.max(1, Math.round((img.naturalWidth || img.width) * sc)), h = Math.max(1, Math.round((img.naturalHeight || img.height) * sc));
  var c = document.createElement('canvas'); c.width = w; c.height = h;
  var x = c.getContext('2d'); x.drawImage(img, 0, 0, w, h);
  var id = x.getImageData(0, 0, w, h), d = id.data, n = w * h;

  function distTo(pi, r, g, b) { var dr = d[pi]-r, dg = d[pi+1]-g, db = d[pi+2]-b; return Math.sqrt(dr*dr + dg*dg + db*db); }

  // ---- 1) modeli i sfondit: ngjyrat e kufirit (unaza 2px), te grupuara ----
  var buckets = {}, keys = [];
  function sample(p) {
    var k = (d[p*4]>>4) + '_' + (d[p*4+1]>>4) + '_' + (d[p*4+2]>>4);
    if (!buckets[k]) { buckets[k] = { r: 0, g: 0, b: 0, n: 0 }; keys.push(k); }
    var bk = buckets[k]; bk.r += d[p*4]; bk.g += d[p*4+1]; bk.b += d[p*4+2]; bk.n++;
  }
  var ring = Math.max(1, Math.round(Math.min(w, h) * 0.012));
  for (var y0 = 0; y0 < ring; y0++) for (var x0 = 0; x0 < w; x0++) { sample(y0*w + x0); sample((h-1-y0)*w + x0); }
  for (var x1 = 0; x1 < ring; x1++) for (var y1 = 0; y1 < h; y1++) { sample(y1*w + x1); sample(y1*w + (w-1-x1)); }
  keys.sort(function(a, b) { return buckets[b].n - buckets[a].n; });
  var clusters = [];
  for (var ki = 0; ki < keys.length && clusters.length < 5; ki++) {
    var bk2 = buckets[keys[ki]];
    if (bk2.n < n * 0.004) continue;
    var r2 = bk2.r / bk2.n, g2 = bk2.g / bk2.n, b2 = bk2.b / bk2.n, dup = false;
    for (var ci = 0; ci < clusters.length; ci++) { var cl = clusters[ci]; if (Math.abs(cl.r-r2)+Math.abs(cl.g-g2)+Math.abs(cl.b-b2) < 40) { dup = true; break; } }
    if (!dup) clusters.push({ r: r2, g: g2, b: b2 });
  }
  if (!clusters.length) clusters.push({ r: d[0], g: d[1], b: d[2] });
  function clusterDist(p) {
    var best = 1e9;
    for (var ci = 0; ci < clusters.length; ci++) { var dd = distTo(p*4, clusters[ci].r, clusters[ci].g, clusters[ci].b); if (dd < best) best = dd; }
    return best;
  }

  // ---- 2) flood fill adaptiv: krahasim me sfondin LOKAL + kontroll global ----
  var bg = new Uint8Array(n), stack = [];
  var step = Math.max(4, tol * 0.55);          // ndryshim lokal i lejuar (gradient)
  var far = tol * 3.0;                          // largesia max nga modeli i sfondit
  for (var i = 0; i < w; i++) { bg[i] = 1; stack.push(i); bg[(h-1)*w+i] = 1; stack.push((h-1)*w+i); }
  for (var k2 = 0; k2 < h; k2++) { bg[k2*w] = 1; stack.push(k2*w); bg[k2*w + w-1] = 1; stack.push(k2*w + w-1); }
  while (stack.length) {
    var p = stack.pop(), px = p % w, py = (p / w) | 0;
    var lr = 0, lg = 0, lb = 0, ln = 0;
    var nb = [px > 0 ? p-1 : -1, px < w-1 ? p+1 : -1, py > 0 ? p-w : -1, py < h-1 ? p+w : -1];
    for (var q = 0; q < 4; q++) { var oq = nb[q]; if (oq >= 0 && bg[oq]) { lr += d[oq*4]; lg += d[oq*4+1]; lb += d[oq*4+2]; ln++; } }
    if (!ln) { lr = d[p*4]; lg = d[p*4+1]; lb = d[p*4+2]; ln = 1; }
    lr /= ln; lg /= ln; lb /= ln;
    for (var q2 = 0; q2 < 4; q2++) {
      var o = nb[q2]; if (o < 0 || bg[o]) continue;
      var cd = clusterDist(o);
      if (cd > far) continue;                                  // shume larg sfondit -> ndal
      var local = distTo(o*4, lr, lg, lb);
      if (local < step || cd < step) { bg[o] = 1; stack.push(o); }
    }
  }

  // ---- 3) pastrimi i "halo"-s: 2 kalime hollimi te skajit ----
  for (var pass = 0; pass < 2; pass++) {
    var toKill = [];
    for (var yy = 0; yy < h; yy++) for (var xx = 0; xx < w; xx++) {
      var pp = yy*w + xx; if (bg[pp]) continue;
      var b2r = 0, b2g = 0, b2b = 0, b2n = 0;
      if (xx > 0 && bg[pp-1]) { b2r += d[(pp-1)*4]; b2g += d[(pp-1)*4+1]; b2b += d[(pp-1)*4+2]; b2n++; }
      if (xx < w-1 && bg[pp+1]) { b2r += d[(pp+1)*4]; b2g += d[(pp+1)*4+1]; b2b += d[(pp+1)*4+2]; b2n++; }
      if (yy > 0 && bg[pp-w]) { b2r += d[(pp-w)*4]; b2g += d[(pp-w)*4+1]; b2b += d[(pp-w)*4+2]; b2n++; }
      if (yy < h-1 && bg[pp+w]) { b2r += d[(pp+w)*4]; b2g += d[(pp+w)*4+1]; b2b += d[(pp+w)*4+2]; b2n++; }
      if (!b2n) continue;
      b2r /= b2n; b2g /= b2n; b2b /= b2n;
      if (distTo(pp*4, b2r, b2g, b2b) < Math.max(10, tol * 1.5)) toKill.push(pp);
    }
    for (var t2 = 0; t2 < toKill.length; t2++) bg[toKill[t2]] = 1;
    if (!toKill.length) break;
  }

  // ---- 4) alpha e bute sipas largesise nga modeli i sfondit ----
  var lo = Math.max(6, tol * 0.9), hi = Math.max(lo + 10, tol * 2.4);
  var minX = w, minY = h, maxX = -1, maxY = -1, fg = 0;
  for (var y3 = 0; y3 < h; y3++) for (var x3 = 0; x3 < w; x3++) {
    var p3 = y3*w + x3;
    if (bg[p3]) { d[p3*4+3] = 0; continue; }
    var dist3 = clusterDist(p3);
    var a3 = Math.round(255 * Math.min(1, Math.max(0, (dist3 - lo) / (hi - lo))));
    if (a3 < 8) { d[p3*4+3] = 0; continue; }
    if (a3 < d[p3*4+3]) d[p3*4+3] = a3;
    if (a3 > 120) { fg++; if (x3 < minX) minX = x3; if (x3 > maxX) maxX = x3; if (y3 < minY) minY = y3; if (y3 > maxY) maxY = y3; }
  }
  x.putImageData(id, 0, 0);
  if (maxX < 0 || fg < n * 0.05) return null;                   // s'u gjet makinë
  var bw = maxX - minX + 1, bh = maxY - minY + 1, pad = Math.round(Math.max(bw, bh) * 0.06);
  var out = document.createElement('canvas'); out.width = bw + pad * 2; out.height = bh + pad * 2;
  out.getContext('2d').drawImage(c, minX, minY, bw, bh, pad, pad, bw, bh);
  return out;                       // v5.9.5: kthejme CANVAS-in (thirresi ben toDataURL)
}

      // v5.9.5: sa pjese e imazhit te prere eshte "gri e hapur" (hije/sfond i mbetur)?
      // Pikselat e erret (goma, dritare) nuk numerohen — vetem hija.
      function shadowRatioOf(cv) {
        var b = cv._buf || null, d = null, W = cv.width, H = cv.height;
        if (!b) { try { d = cv.getContext('2d').getImageData(0, 0, W, H).data; } catch (e) { return 0; } }
        var op = 0, sh = 0;
        for (var i = 0; i < W * H; i++) {
          var a = b ? b[i*4+3] : d[i*4+3]; if (a < 128) continue;
          op++;
          var r = b ? b[i*4] : d[i*4], g = b ? b[i*4+1] : d[i*4+1], bl = b ? b[i*4+2] : d[i*4+2];
          var mx = Math.max(r, g, bl), mn = Math.min(r, g, bl);
          var sat = mx <= 0 ? 0 : (mx - mn) / mx, luma = 0.299*r + 0.587*g + 0.114*bl;
          if (sat < 0.14 && luma > 105) sh++;
        }
        return op ? sh / op : 1;
      }

      // v5.9.5: nese mbetet hije, e rrit vete tolerancen (gomat/dritaret nuk preken,
      // sepse ato jane te erret dhe nuk numerohen si hije). Kthen canvas-in ose null.
      function removeBackgroundBest(img, tol) {
        tol = Math.max(8, Math.min(40, Number(tol) || 32));   // v5.9.9: kufi 40 (ma lart hante makinat)
        var cv = removeBackground(img, tol);
        if (!cv) return null;
        var ratio = shadowRatioOf(cv);
        if (ratio <= 0.06) return cv;
        var t = tol;
        for (var guard = 0; guard < 3 && t < 40; guard++) {
          var tn = Math.min(40, Math.round(t * 1.3) + 3);
          if (tn <= t) break;
          t = tn;
          var next = removeBackground(img, t);
          if (!next) break;
          // v5.9.9: nese prerja tkurret shume, ka hanger pjese te makines -> kthehu
          if (next.width * next.height < 0.6 * (cv.width * cv.height)) break;
          var r2 = shadowRatioOf(next);
          if (r2 < ratio - 0.005) { cv = next; ratio = r2; if (ratio <= 0.02) break; } else break;
        }
        return cv;
      }


      // =====================================================
      // v5.10.1: FOTOT NUK HUMBIN — arkiva e fotove + kompresim
      // =====================================================
      // Pse: kur ka shume foto (14+), memoria e UI-se (localStorage) mbushet
      // dhe fotot e ruajtura humbnin kur ndrrohej makina / rihapej modi.
      // Tani: (a) fotot ruhen ne arkive te veçantë (cfg.photoArchive),
      //       (b) fotot kompresohen vetë (max 320px) para se me u ruejt,
      //       (c) fotoja automatike e makines nuk mbulon KURRË foto ekzistuese.
      function archivePhoto(idx) {
        try {
          var it = scope.cfg.items[idx];
          if (!it || !it.image) return;
          if (!scope.cfg.photoArchive || typeof scope.cfg.photoArchive !== 'object') scope.cfg.photoArchive = {};
          scope.cfg.photoArchive['s' + idx] = it.image;
          if (it.imageModel) scope.cfg.photoArchive['m:' + it.imageModel] = it.image;
        } catch (e) {}
      }

      scope.restorePhotos = function() {
        var n = 0, ar = scope.cfg.photoArchive || {};
        (scope.cfg.items || []).forEach(function(it, i) {
          if (!it || it.image) return;
          var v = ar['s' + i] || (it.imageModel ? ar['m:' + it.imageModel] : '');
          if (v) { it.image = v; n++; }
        });
        if (n) scope.persist();
        autoMsg(n ? ('♻️ U rikthyen ' + n + ' foto nga arkiva') : '♻️ S\'ka foto për me rikthye');
        return n;
      };

      // Zvogëlon nje foto (dataURL) deri ne maxPx — ruan transparencën (PNG)
      function shrinkDataUrl(url, maxPx, cb) {
        try {
          if (!url || String(url).indexOf('data:image') !== 0) return cb(url);
          var img = new Image();
          img.onload = function() {
            try {
              var w = img.naturalWidth || img.width, h = img.naturalHeight || img.height;
              var sc = Math.min(1, Number(maxPx || 320) / Math.max(w, h));
              if (!w || !h || sc >= 1) return cb(url);
              var c = document.createElement('canvas');
              c.width = Math.max(1, Math.round(w * sc));
              c.height = Math.max(1, Math.round(h * sc));
              c.getContext('2d').drawImage(img, 0, 0, c.width, c.height);
              var out = c.toDataURL('image/png');
              cb(out && out.length > 100 ? out : url);
            } catch (e) { cb(url); }
          };
          img.onerror = function() { cb(url); };
          img.src = url;
        } catch (e) { cb(url); }
      }

      scope.compressPhotos = function(maxPx, done) {
        var max = Math.max(80, Number(maxPx) || Number(scope.cfg.photoMaxPx) || 300);
        var list = (scope.cfg.items || []).filter(function(it) { return it && it.image && String(it.image).indexOf('data:image') === 0; });
        if (!list.length) { if (done) done(0); return; }
        var left = list.length, changed = 0;
        list.forEach(function(it) {
          shrinkDataUrl(it.image, max, function(small) {
            if (small && small.length < it.image.length) { it.image = small; changed++; }
            if (--left === 0) {
              (scope.cfg.items || []).forEach(function(x, i) { if (x && x.image) archivePhoto(i); });
              scope.persist();
              if (done) done(changed);
            }
          });
        });
      };

      scope.removeItemPhoto = function(i) {
        var it = scope.cfg.items[i];
        if (!it) return;
        it.image = ''; it.imageModel = '';
        try { delete scope.cfg.photoArchive['s' + i]; } catch (e) {}
        scope.persist();
      };

      function placeAutoPhoto(dataUrl, name, model, autoMode) {
        var items = scope.cfg.items || [];
        var explicit = (autoPhotoTarget != null);   // v5.9.10: butoni "📸 Auto" i nje rrathullaku e respektohet
        var sel = autoPhotoTarget != null ? autoPhotoTarget : Number(scope.selected) || 0;
        autoPhotoTarget = null;
        var idx = sel;
        // v5.9.10: nese rrathullaku i zgjedhur ka foto te NJE MAKINE TJETER, fotoja e re
        // shkon ne rrathullakun e radhës BOSH (nje foto per makine — jo mbishkrim i vazhdueshem).
        // Nese eshte e njejta makine -> rifreskohet fotoja aty (retake).
        var sameCar = !!(model && items[idx] && items[idx].imageModel === model);
        var foundEmpty = false;
        if (!explicit && !sameCar && items[idx] && items[idx].enabled !== false && items[idx].image) {
          for (var s0 = 1; s0 <= items.length; s0++) {
            var j0 = (sel + s0) % items.length;
            if (items[j0] && items[j0].enabled !== false && !items[j0].image) { idx = j0; foundEmpty = true; break; }
          }
        }
        // v5.10.1: fotoja AUTOMATIKE (kur ndërron makinën) NUK mbulon KURRË
        // nje foto ekzistuese — nese s'ka vend bosh, nuk vendoset gje.
        if (autoMode && !explicit && !sameCar && !foundEmpty && items[sel] && items[sel].image) {
          autoMsg('ℹ️ Të gjithë rrathët plot — fotoja e re nuk u vendos (asnji foto nuk u hjek)');
          return;
        }
        if (!items[idx] || items[idx].enabled === false) {
          var e0 = -1;
          for (var e3 = 0; e3 < items.length; e3++) if (items[e3].enabled !== false && !items[e3].image) { e0 = e3; break; }
          idx = (e0 >= 0) ? e0 : (items[sel] ? sel : 0);
        }
        if (!items[idx]) { autoMsg('✗ S\'ka rrumullak'); return; }
        items[idx].enabled = true;
        items[idx].imageScale = 0.62; items[idx].imageOffsetX = 0; items[idx].imageOffsetY = 0; items[idx].imageRotation = 0;
        if (model) items[idx].imageModel = String(model);      // v5.9.10
        if (name && (!items[idx].label || /^(car|makina|vehicle)?\s*\d*$/i.test(items[idx].label))) items[idx].label = String(name);
        // v5.9.10: pamja e fotos se fundit ne panel (e plote — me kontrollu cilesine)
        scope.lastShotPreview = dataUrl;
        scope.lastShotInfo = (name ? name + ' · ' : '') + Math.round(String(dataUrl || '').length / 1024) + ' KB';
        if (scope.cfg.autoPhotoNext) {
          for (var s = 1; s <= items.length; s++) { var j2 = (idx + s) % items.length; if (!items[j2].image) { scope.selected = j2; scope.cfg.currentIndex = j2; break; } }
        }
        // v5.10.1: fotoja e ruejtur zvogëlohet (mos me mbushe memorjen) + shkon ne arkive
        shrinkDataUrl(dataUrl, scope.cfg.photoMaxPx || 320, function(small) {
          items[idx].image = small || dataUrl;
          archivePhoto(idx);
          scope.persist();
          autoMsg('✓ Foto u vendos në rrumullakun ' + (idx + 1) + (name ? ' (' + name + ')' : '') + ' — nuk humb kur ndërron makinën');
        });
      }
      // =====================================================
      // v5.9.9: FOTO LIVE — kerri ashtu si eshte ne loje (Ctrl+1)
      // UI-ja e nis kapjen, e pyet lojen cdo ~300ms, e merr foton si
      // base64, i heq sfondin vet dhe e ve ne rrumullak.
      // Nese nuk kapet gje ose prerja deshton -> kalon VETE ne foton e modit (s'betet kurre "asgje").
      // Gjithe rruget e v5.9.9: render i joni -> render_renderViews -> foto e modit
      // (screenshot-i klasik i lojes u hoq: nxinte gjithe ekranin + panelin).
      // =====================================================
      scope.liveHide = false;
      scope.liveInfo = '';
      scope.liveDiag = '';
      var livePollTimer = null;
      var liveWatchdog = null;

      function liveParse(res) {
        if (typeof res === 'string') {
          try { return JSON.parse(res); }
          catch (e) { return { err: 'përgjigje e papërpunuar: ' + res.slice(0, 140) }; }
        }
        return res;
      }
      // expr = shprehje e vetme Lua (UI-ja e vlerëson si "return <expr>")
      function liveCall(expr, cb) {
        var cmd = "(function() pcall(function() extensions.load('creatorpack') end); " +
                  "local e = extensions.creatorpack; " +
                  "if not e then return {err='extensioni creatorpack nuk u ngarkua'} end; " +
                  "return " + expr + " end)()";
        if (!cb) { try { engineLua(cmd); } catch (e) {} return true; }
        try {
          if (window.bngApi && typeof window.bngApi.engineLua === 'function') {
            window.bngApi.engineLua(cmd, function(res) {
              scope.$applyAsync(function() { try { cb(liveParse(res)); } catch (e) { cb({ err: String(e) }); } });
            });
            return true;
          }
        } catch (e) {}
        return false;
      }
      function isPngB64(b64) { return typeof b64 === 'string' && b64.indexOf('iVBORw0KGgo') === 0; }
      function b64ToBytes(b64) {
        try { var bin = atob(b64), n = bin.length, out = new Uint8Array(n);
              for (var i = 0; i < n; i++) out[i] = bin.charCodeAt(i); return out; } catch (e) { return null; }
      }
      // kthen Image ose canvas qe mund t'i kalojme removeBackground-it
      function liveSource(res) {
        if (!res || !res.b64) return null;
        var m = String(res.mode || '').toLowerCase();
        if (m !== 'buffer' && m !== 'raw' && (isPngB64(res.b64) || m === 'png' || m === 'jpg' || m === 'jpeg')) {
          var mime = (m === 'jpg' || m === 'jpeg') ? 'image/jpeg' : 'image/png';
          var im = new Image();
          im.src = 'data:' + mime + ';base64,' + res.b64;
          return im;
        }
        var w = Number(res.w) || 0, h = Number(res.h) || 0, bytes = b64ToBytes(res.b64);
        if (!w || !h || !bytes) return null;
        var per = bytes.length / (w * h);
        if (per < 3) return null;
        var c = document.createElement('canvas'); c.width = w; c.height = h;
        var cx = c.getContext('2d'), id = cx.createImageData(w, h), out = id.data;
        var flip = scope.cfg.liveFlip === true;
        for (var y = 0; y < h; y++) {
          var sy = flip ? (h - 1 - y) : y;
          for (var x = 0; x < w; x++) {
            var si = Math.floor((sy * w + x) * per), di = (y * w + x) * 4;
            out[di] = bytes[si]; out[di + 1] = bytes[si + 1]; out[di + 2] = bytes[si + 2];
            out[di + 3] = per >= 4 ? bytes[si + 3] : 255;
          }
        }
        cx.putImageData(id, 0, 0);
        return c;
      }
      var liveCropRect = null;
      var liveResModel = null;      // v5.9.10: modeli i makines se kapur (nga Lua)
      function liveCrop(src, rect) {           // pret vetem pjesen ku ndodhet makina
        try {
          var sw = src.naturalWidth || src.width || 0, sh = src.naturalHeight || src.height || 0;
          if (!rect || !sw || !sh) return src;
          if ((rect.x1 - rect.x0) < 0.35 || (rect.y1 - rect.y0) < 0.35) return src;  // dyshohet -> mos prej
          var x = Math.max(0, Math.floor(rect.x0 * sw)), y = Math.max(0, Math.floor(rect.y0 * sh));
          var w = Math.min(sw - x, Math.ceil((rect.x1 - rect.x0) * sw)), h = Math.min(sh - y, Math.ceil((rect.y1 - rect.y0) * sh));
          if (w < 24 || h < 24) return src;
          var c = document.createElement('canvas'); c.width = w; c.height = h;
          c.getContext('2d').drawImage(src, x, y, w, h, 0, 0, w, h);
          return c;
        } catch (e) { return src; }
      }
      function liveCutScore(cv, minCover) {   // sa e mire duket prerja (-1 = e keqe)
        try {
          var w = cv.width, h = cv.height;
          if (!w || !h) return -1;
          var d = cv.getContext('2d').getImageData(0, 0, w, h).data;
          var opaque = 0, border = 0, borderOpaque = 0;
          var ring = Math.max(1, Math.round(Math.min(w, h) * 0.03));
          for (var y = 0; y < h; y++) {
            for (var x = 0; x < w; x++) {
              var solid = d[(y * w + x) * 4 + 3] > 60;
              if (solid) opaque++;
              if (x < ring || y < ring || x >= w - ring || y >= h - ring) { border++; if (solid) borderOpaque++; }
            }
          }
          var cover = opaque / (w * h);
          if (cover < (minCover || 0.08)) return -1;          // u honger edhe makina
          var borderClean = border ? (1 - borderOpaque / border) : 1;
          var coverScore = 1 - Math.abs(cover - 0.55) / 0.55;
          return borderClean * 0.7 + Math.max(0, coverScore) * 0.3;
        } catch (e) { return -1; }
      }
      function liveCut(src, tol, minCover) {   // provo disa toleranca, zgjidh ma te miren
        var tries = [tol, Math.round(tol * 0.72), Math.min(36, Math.round(tol * 1.35))];
        var best = null, bestScore = -1;
        for (var i = 0; i < tries.length; i++) {
          var t = Math.max(8, Math.min(70, tries[i]));
          var cv = null;
          try { cv = removeBackground(src, t); } catch (e) { cv = null; }
          if (!cv) continue;
          var sc = liveCutScore(cv, minCover);
          if (sc > bestScore) { bestScore = sc; best = cv; }
        }
        if (bestScore < 0.2) return null;      // asnje prerje e mire -> rruga tjeter
        return best;
      }
      function liveCutMeasured(cv) {          // a mund te matet? (pa kanavac -> s'gjykojme = e mbajme)
        try { cv.getContext('2d').getImageData(0, 0, 1, 1).data; return true; } catch (e) { return false; }
      }
      function liveFinish(src) {               // true = fotoja u vendos ne rrumullak
        // v5.9.9: LIVE perdor tolerance te matur (18-30), pa marre parasysh vleren e larte te rreshqitesit
        var tol = Math.max(18, Math.min(30, Number(scope.cfg.autoPhotoTolerance) || 28));
        var base = liveCrop(src, liveCropRect);   // v5.9.8: prejme vetem makinen
        var url = null;
        try {
          var cv = liveCut(base, tol, 0.20);          // mbi foton e prerë
          if (!cv && base !== src) cv = liveCut(src, tol, 0.02);   // mbi foton e plote
          if (!cv) cv = removeBackgroundBest(src, tol);
          if (cv && liveCutMeasured(cv) && liveCutScore(cv, 0.12) < 0.1) cv = null;   // siluetë? -> pa prerje
          if (cv) url = cv.toDataURL('image/png');
        } catch (e) { url = null; }
        // v5.9.9: nese prerja e sfondit nuk doli mire, NUK e venim foton e paperpunuar
        // (ma heret dilte gjithe ekrani) -> thirresi kalon vete ne foton e modit.
        if (!url) return false;
        placeAutoPhoto(url, 'Live', liveResModel);
        return true;
      }

      // Ctrl+1: foto LIVE; nese s'kapet gje, kalon vete ne foton e modit
      scope.livePhoto = function(fallbackToPreview) {
        autoPhotoTarget = null;
        var done = false, polls = 0, MAX_POLLS = 55;      // 55 x 300ms ≈ 16 s
        scope.liveHide = true;
        scope.liveInfo = '⏳ LIVE: po kap foton…';
        autoMsg('📸 duke marrë foton LIVE…');
        if (livePollTimer) { try { $timeout.cancel(livePollTimer); } catch (e) {} livePollTimer = null; }
        if (liveWatchdog) { try { $timeout.cancel(liveWatchdog); } catch (e) {} liveWatchdog = null; }

        function stopTimers() {
          if (livePollTimer) { try { $timeout.cancel(livePollTimer); } catch (e) {} livePollTimer = null; }
          if (liveWatchdog) { try { $timeout.cancel(liveWatchdog); } catch (e) {} liveWatchdog = null; }
        }
        function fail(msg) {
          if (done) return; done = true;
          stopTimers();
          scope.liveHide = false;
          scope.liveInfo = msg;
          liveCall("e.liveDone()");
          if (fallbackToPreview === false) { autoMsg(msg); return; }
          autoMsg(msg + ' → foto e modit (pa screenshot)');
          scope.autoPhoto();
        }
        function poll(res) {
          if (done) return;
          if (!res) { fail('✗ LIVE: loja nuk u përgjigj'); return; }
          if (res.err) { fail('✗ LIVE: ' + res.err); return; }
          if (res.ready && res.b64) {
            var kb = Math.round((Number(res.size) || 0) / 1024);
            liveCropRect = res.crop || null;      // v5.9.8: ku ndodhet makina ne foto
            liveResModel = res.model || null;     // v5.9.10
            var src = liveSource(res);
            if (!src) { fail('✗ LIVE: foto u mor (' + kb + ' KB) po nuk u lexua'); return; }
            done = true; stopTimers(); scope.liveHide = false;
            function settle(okFlag) {
              liveCall("e.liveDone()");
              if (okFlag) { scope.liveInfo = '✓ LIVE: foto u vendos (' + kb + ' KB, ' + (res.mode || '?') + ')'; autoMsg(scope.liveInfo); }
              else { done = false; fail('✗ LIVE: prerja e sfondit dështoi (' + kb + ' KB)'); }
            }
            if (src.tagName === 'IMG') {
              src.onload = function() { scope.$applyAsync(function() { settle(liveFinish(src)); }); };
              src.onerror = function() { scope.$applyAsync(function() { done = false; fail('✗ LIVE: imazhi nuk u lexua (' + kb + ' KB)'); }); };
              return;
            }
            settle(liveFinish(src));
            return;
          }
          if (++polls > MAX_POLLS) { fail('✗ LIVE: koha kaloi (' + ((res && res.note) || '?') + ')'); return; }
          if (res.note) scope.liveInfo = '⏳ LIVE: ' + res.note;
          livePollTimer = $timeout(function() { liveCall("e.livePoll()", poll); }, 300);
        }

        liveWatchdog = $timeout(function() { fail('✗ LIVE: koha kaloi (22 s)'); }, 22000);
        liveCall("e.setLiveFront(" + (scope.cfg.liveView === 'front' ? 'true' : 'false') + ")", null);
        var started = liveCall("e.liveShot()", function(res) {
          if (done) return;
          if (!res) { fail('✗ LIVE: loja nuk u përgjigj (bngApi)'); return; }
          if (res.err) { fail('✗ LIVE: ' + res.err); return; }
          scope.liveInfo = '⏳ LIVE: ' + (res.phase === 'classic' ? 'screenshot i lojës…' : ('render ' + (res.w || '') + 'x' + (res.h || '') + '…'));
          livePollTimer = $timeout(function() { liveCall("e.livePoll()", poll); }, 350);
        });
        if (!started) fail('✗ LIVE: bngApi.engineLua nuk u gjet');
      };

      // Butoni "Foto e modit" i vjetri vazhdon te punojë; ky eshte vetem info
      scope.liveDiagnose = function() {
        scope.liveDiag = '⏳ po kontrolloj…';
        var ok = liveCall("e.liveDiag()", function(res) {
          if (!res) { scope.liveDiag = '✗ pa përgjigje nga loja'; return; }
          var keys = Object.keys(res).sort();
          var parts = [];
          for (var i = 0; i < keys.length; i++) parts.push(keys[i] + '=' + res[keys[i]]);
          scope.liveDiag = parts.join(' · ');
          if (window.console && console.log) console.log('[HUD PRO] LIVE diag', res);
        });
        if (!ok) scope.liveDiag = '✗ bngApi.engineLua nuk u gjet';
      };
      scope.setLiveView = function(v) {
        scope.cfg.liveView = (v === 'front') ? 'front' : 'auto';
        scope.persist();
        liveCall("e.setLiveFront(" + (scope.cfg.liveView === 'front' ? 'true' : 'false') + ")", null);
        autoMsg(scope.cfg.liveView === 'front' ? '📷 kamera: 3/4 përpara' : '📷 kamera: 3/4 mbrapa');
      };

      // Rruga rezervë: nese ndonje cope tjeter e Lua-s njofton nje foto LIVE
      var unsubLivePhoto = $rootScope.$on('creatorpack.livephoto', function(e, data) {
        if (!data || !data.b64) return;
        scope.$applyAsync(function() {
          var src = liveSource(data);
          if (src && src.tagName === 'IMG') {
            src.onload = function() { scope.$applyAsync(function() { liveFinish(src); }); };
            return;
          }
          if (src) liveFinish(src);
        });
      });

      var unsubAutoPhoto = $rootScope.$on('creatorpack.autophoto', function(e, data) {
        if (data && !data.auto && autoPhotoWait) { $timeout.cancel(autoPhotoWait); autoPhotoWait = null; }
        scope.$applyAsync(function(){ handleAutoPhoto(data); });
      });
      function handleAutoPhoto(data) {
        {
          if (!data) return;
          if (data.auto && !scope.cfg.autoPhotoOnSwitch) return;
          var list = [];
          (data.paths || []).forEach(function(p){ if (p && list.indexOf(p) < 0) list.push(p); });
          if (data.path && list.indexOf(data.path) < 0) list.unshift(data.path);
          if (!list.length) { autoMsg('✗ S\'u gjet foto (' + (data.model || '?') + ')'); return; }
          // v5.9.4: provo edhe rrugen e plote local://local/... (disa versione te CEF)
          var cands2 = [];
          list.forEach(function(p){
            if (!p) return;
            var s = String(p); if (s.charAt(0) !== '/' && !/^[a-z]+:/i.test(s)) s = '/' + s;
            if (cands2.indexOf(s) < 0) cands2.push(s);
            if (s.charAt(0) === '/' && cands2.indexOf('local://local' + s) < 0) cands2.push('local://local' + s);
          });
          if (window.console && console.log) console.log('[HUD PRO] autofoto: ' + list.length + ' kandidate, model=' + (data.model || '?'));
          var tol = Math.max(8, Math.min(40, Number(scope.cfg.autoPhotoTolerance) || 28));   // v5.9.9: kufi 40
          (function tryAt(k) {
            if (k >= cands2.length) { autoMsg('✗ S\'u gjet foto (' + (data.model || '?') + ', ' + cands2.length + ' provuar)'); return; }
            var src = cands2[k];
            var img = new Image();
            img.onload = function() {
              if (!img.naturalWidth) return tryAt(k + 1);
              var url = null;
              try {
                // v5.9.9: prerja e forte (heq hijen) + kontroll se mos e ka hanger makinën.
                // Nese prerja del "e hollë" (vetem dritare/goma), merret prerja ma e bute.
                var cv = removeBackgroundBest(img, tol);
                if (cv && liveCutMeasured(cv) && liveCutScore(cv, 0.22) < 0.2) {
                  var soft = liveCut(img, Math.min(20, tol), 0.15);
                  if (soft) cv = soft;
                  else cv = null;                 // ma mire fotoja e plote se nje siluetë
                }
                if (cv) url = cv.toDataURL('image/png');
              } catch (err) { url = null; }
              if (!url) { try { var cc = document.createElement('canvas'); cc.width = img.naturalWidth; cc.height = img.naturalHeight; cc.getContext('2d').drawImage(img, 0, 0); url = cc.toDataURL('image/png'); } catch (e2) { url = src; } }
              scope.autoPhotoPreview = url; scope.autoPhotoSrc = src;
              scope.$applyAsync(function(){ placeAutoPhoto(url, data.name, data.model, data.auto === true); });
            };
            img.onerror = function() {
              if (window.console && console.log) console.log('[HUD PRO] autofoto: imazhi nuk u ngarkua -> ' + src);
              tryAt(k + 1);
            };
            img.src = src;
          })(0);
        }
      }
      scope.$on('$destroy', function(){ try { unsubAutoPhoto(); unsubLivePhoto(); } catch (e) {} });
      var unsubPfhudAction = $rootScope.$on('pfhud.action', function(e, data) {
        if (!data || !data.action) return;
        if (data.action === 'pass') scope.markState('pass');
        else if (data.action === 'fail') scope.markState('fail');
        else if (data.action === 'next') scope.next();
        else if (data.action === 'prev') scope.prev();
        else if (data.action === 'reset') scope.resetStates();
        else if (data.action === 'togglePanel') scope.togglePanel();
        // v2.1: veprime te reja nga bindings-at
        else if (data.action === 'undo') scope.undo();
        else if (data.action === 'toggleGuides') {
          scope.cfg.guidesOn = !scope.cfg.guidesOn;
          scope.persist();
        }
        // v5.1: ON/OFF i rrumullakateve nga bindings (Options -> Controls)
        else if (data.action === 'toggleVehicles') scope.toggleVehicles();
        // v5.2: stream mode dhe ze nga bindings (Options -> Controls)
        else if (data.action === 'toggleStream') scope.toggleStreamMode();
        else if (data.action === 'resetSurvival') scope.resetSurvival();
        scope.$applyAsync();
      });

      function isTypingTarget(target) {
        if (!target) return false;
        var tag = (target.tagName || '').toLowerCase();
        return tag === 'input' || tag === 'textarea' || tag === 'select' || target.isContentEditable;
      }

      function keyMatches(e, configured) {
        if (!configured) return false;
        var conf = String(configured).trim().toLowerCase();
        if (!conf) return false;

        var key = String(e.key || '').trim().toLowerCase();
        var code = String(e.code || '').trim().toLowerCase();
        var keyCode = e.keyCode || e.which;

        if (conf === key || conf === code) return true;

        if (conf.length === 1) {
          if (key === conf) return true;
          if (code === ('key' + conf)) return true;
          if (keyCode && String.fromCharCode(keyCode).toLowerCase() === conf) return true;
        }

        if (conf === 'arrowleft') return key === 'arrowleft' || code === 'arrowleft' || keyCode === 37;
        if (conf === 'arrowright') return key === 'arrowright' || code === 'arrowright' || keyCode === 39;
        if (conf === 'arrowup') return key === 'arrowup' || code === 'arrowup' || keyCode === 38;
        if (conf === 'arrowdown') return key === 'arrowdown' || code === 'arrowdown' || keyCode === 40;
        if (conf === 'pageup' || conf === 'pgup') return key === 'pageup' || code === 'pageup' || keyCode === 33;
        if (conf === 'pagedown' || conf === 'pgdn' || conf === 'pgdown') return key === 'pagedown' || code === 'pagedown' || keyCode === 34;
        if (conf === 'numpad4' || conf === 'num4') return key === '4' || code === 'numpad4' || keyCode === 100;
        if (conf === 'numpad6' || conf === 'num6') return key === '6' || code === 'numpad6' || keyCode === 102;

        return false;
      }

      function handleHotkey(e) {
        if (!scope.cfg.useHotkeys) return;
        if (isTypingTarget(e.target)) return;

        var handled = false;

        // v5.9.0: Ctrl+1 = Auto foto · v5.9.6: foto LIVE nga loja
        if ((e.ctrlKey || e.metaKey) && (String(e.key || '') === '1' || e.code === 'Digit1')) {
          scope.$applyAsync(function(){ if (scope.cfg.liveOn === false) scope.autoPhoto(); else scope.livePhoto(true); });
          e.preventDefault(); e.stopPropagation(); return false;
        }

        // v5.9.9: Ctrl+2 = FOTO E MODIT (pa screenshot)
        if ((e.ctrlKey || e.metaKey) && (String(e.key || '') === '2' || e.code === 'Digit2')) {
          scope.$applyAsync(function(){ scope.autoPhoto(); });
          e.preventDefault(); e.stopPropagation(); return false;
        }

        // Ctrl+Z = Undo
        if ((e.ctrlKey || e.metaKey) && String(e.key || '').toLowerCase() === 'z') {
          scope.$applyAsync(function(){ scope.undo(); });
          e.preventDefault();
          e.stopPropagation();
          return false;
        }

        if (keyMatches(e, scope.cfg.togglePanelKey)) {
          scope.$applyAsync(function(){ scope.togglePanel(); });
          handled = true;
        } else if (keyMatches(e, scope.cfg.streamKey)) {
          scope.$applyAsync(function(){ scope.toggleStreamMode(); });
          handled = true;
        } else if (keyMatches(e, scope.cfg.vehiclesKey)) {
          scope.$applyAsync(function(){ scope.toggleVehicles(); });
          handled = true;
        } else if (keyMatches(e, scope.cfg.passKey)) {
          scope.$applyAsync(function(){ scope.markState('pass'); });
          handled = true;
        } else if (keyMatches(e, scope.cfg.failKey)) {
          scope.$applyAsync(function(){ scope.markState('fail'); });
          handled = true;
        } else if (keyMatches(e, 'PageDown') || keyMatches(e, 'Numpad6') || keyMatches(e, scope.cfg.nextKey)) {
          scope.$applyAsync(function(){ scope.next(); });
          handled = true;
        } else if (keyMatches(e, 'PageUp') || keyMatches(e, 'Numpad4') || keyMatches(e, scope.cfg.prevKey)) {
          scope.$applyAsync(function(){ scope.prev(); });
          handled = true;
        } else if (keyMatches(e, scope.cfg.resetKey)) {
          scope.$applyAsync(function(){ scope.resetStates(); });
          handled = true;
        }

        if (handled) {
          e.preventDefault();
          e.stopPropagation();
          return false;
        }
      }

      // FIX v2.0: me pare i njejti handler ishte i lidhur me keydown + keyup +
      // keypress njekohesisht, ne 3 target-e (node, $document, $window). Nje
      // shtypje e vetme e tastit e thirrte handler-in 2-3 here, keq per 'next'
      // (kercente 2 pozicione) dhe per markimet. Tani: VETEM keydown, dhe
      // vetem ne $document (qe i kap edhe eventet nga node-i permes bubbling).
      var node = element && element[0] ? element[0] : null;
      // nis uren e kostos nese moduli eshte i ndezur nga sesioni i kaluar
      if (scope.cfg.costOn) bootCostLua();

      // v3.1.2: tastet dështonin sepse handler-i ishte VETËM në $document.
      // Kur fokusi shkon te canvas-i i lojës (pas rinisjes, ose pasi klikon
      // në botë), dokumenti i UI-së nuk i merr më eventet. Tani dëgjojmë në
      // document, window DHE në vetë node-in, me capture=true, dhe mbrohemi
      // nga dublikimi me një vulë kohore për event.
      var lastHotkeyStamp = 0;
      function hotkeyEntry(e) {
        var stamp = e.timeStamp || Date.now();
        if (stamp === lastHotkeyStamp) return;   // i njejti event nga 2 target-e
        lastHotkeyStamp = stamp;
        return handleHotkey(e);
      }

      $document.on('keydown', hotkeyEntry);
      try { $window.addEventListener('keydown', hotkeyEntry, true); } catch (e) {}
      try { if (node) node.addEventListener('keydown', hotkeyEntry, true); } catch (e) {}

      // Mbaj fokusin te UI-ja: bëje node-in të fokusueshëm dhe rimerre fokusin
      // sa herë përdoruesi prek HUD-in ose panelin.
      $timeout(function() {
        try {
          if (node) {
            node.setAttribute('tabindex', '0');
            node.addEventListener('mousedown', function() {
              try { node.focus({ preventScroll: true }); } catch (x) {}
            }, true);
          }
        } catch (e) {}
      }, 250);

      scope.$on('$destroy', function() {
        if (fxTimer) { try { $timeout.cancel(fxTimer); } catch (e) {} }
        if (unsubPfhudAction) unsubPfhudAction();
        $document.off('keydown', hotkeyEntry);
        try { $window.removeEventListener('keydown', hotkeyEntry, true); } catch (e) {}
        try { if (node) node.removeEventListener('keydown', hotkeyEntry, true); } catch (e) {}
        $window.removeEventListener('resize', onResize);
        if (unsubCost) { try { unsubCost(); } catch(e) {} }
        if (costPulseDelay) { try { clearTimeout(costPulseDelay); } catch(e) {} }
        if (costPulseTimer) { try { clearTimeout(costPulseTimer); } catch(e) {} }
        if (followTimer) { try { $timeout.cancel(followTimer); } catch(e) {} }
        if (survivalPulseTimer) { try { $timeout.cancel(survivalPulseTimer); } catch(e) {} }
        if (survivalDeltaTimer) { try { $timeout.cancel(survivalDeltaTimer); } catch(e) {} }
        if (survivalHideTimer) { try { $timeout.cancel(survivalHideTimer); } catch(e) {} }
        if (survivalShakeTimer) { try { $timeout.cancel(survivalShakeTimer); } catch(e) {} }
        if (survivalRollTimer) { try { $timeout.cancel(survivalRollTimer); } catch(e) {} }
        if (survivalTweenTimer) { try { $timeout.cancel(survivalTweenTimer); } catch(e) {} }
        if (survivalEmojiTimer) { try { $timeout.cancel(survivalEmojiTimer); } catch(e) {} }
        if (unwatchSurvivalEmoji) { try { unwatchSurvivalEmoji(); } catch(e) {} }
        // ---- v5.2 ----
        if (unwatchSurvivalState) { try { unwatchSurvivalState(); } catch(e) {} }
        if (toastTimer) { try { $timeout.cancel(toastTimer); } catch(e) {} }
        if (survivalRotateTimer) { try { $timeout.cancel(survivalRotateTimer); } catch(e) {} }
        if (sound.hbTimer) { try { clearTimeout(sound.hbTimer); } catch(e) {} sound.hbTimer = null; }
        try { if (sound.ctx && sound.ctx.close) sound.ctx.close(); } catch(e) {}
        try {
          $document.off('mousedown', resumeAudioOnGesture);
          $document.off('keydown', resumeAudioOnGesture);
        } catch(e) {}
        $document.off('click', onDocClickPicker);
      });
    }
  };
}]);
