FOLDERI I IMAZHEVE — HUD PRO (v5.11.0)
======================================

Këtu i qet file-at PNG (transparente) qe i shkarkon. Shtoje / ndërroje
emrin si te duash, e pastaj rizip-o modin. Ka dy mënyra:

-----------------------------------------------
1) LOGOT E MARKAVE (dalin VETË në rrathullak)
-----------------------------------------------
Emri i file-it e tregon markën. Shembuj:

    logo_bmw.png        -> logoja e BMW
    logo_audi.png       -> logoja e Audi
    logo_mercedes.png   -> logoja e Mercedes
    bmw.png             -> e njejta gja (pa "logo_")
    LAMBORGHINI_logo.png -> punon edhe kshtu (emri permban markën)

Kur hipën në nje makinë te asaj marke, logoja del VETË në rrathullakun
tënd — pa foto, pa Choose File, pa base64 (s'mbushet memoria).

Cilat marka njihen: bmw, audi, mercedes, vw/volkswagen, toyota, nissan,
ford, gmc, peugeot, volvo, chevrolet/chevy, dodge, honda, mazda, subaru,
porsche, jeep, tesla, lexus, hyundai, kia, fiat, renault, citroen, skoda,
seat, opel, mini, jaguar, maserati, ferrari, lamborghini, bugatti,
bentley, mclaren, lancia, alfa, genesis, suzuki, mitsubishi, cadillac,
buick, chrysler, ram, hummer, smart, rover, scania, man, iveco, daihatsu.

Nese s'ka file logo per ate marke -> del BADGE me shkronja (p.sh. BMW)
automatikisht. Kshtu punon per KREJT makinat, edhe mod-et.

-----------------------------------------------
2) FOTOT (galeria në panel)
-----------------------------------------------
Çdo file tjeter (p.sh. foto_makina1.png) shfaqet në panel te karta
"🏷️ Logot e markave + Folderi imazhet/" si nje galeri e vogel.
Klik në nje foto -> shkon DIREKT në rrathullakun e zgjedhur.
Pa "Choose File", pa Windows.

Shenim: fotot prej këtu ruhen si rruge file-i (jo base64) — s'mbushet
memoria, e mbeten edhe pas rihapjes se lojës.

-----------------------------------------------
SI ME I SHTU FILE-AT
-----------------------------------------------
1) Shkarko PNG-të (me sfond transparent).
2) Kopjoji në këtë folder (imazhet/).
3) Ri-zipo modin (ose shtoje file-at brenda zip-it në të njejtën rruge:
   ui/modules/apps/CreatorPack/imazhet/).
4) Instaloje modin, hap panelin -> "🔁 Rikontrollo folderin".

Keshille: PNG me sfond transparent, rreth 256-512 px, duket ma mirë.
