import { runRaw } from "@/bridge/libs/Lua"
import { openConfirmation } from "@/services/popup"
import { ACCENTS } from "@/common/components/base"

const BUTTON_CLASS = "vmd-quick-disable"
const STYLE_ID = "vmd-quick-disable-style"
const infoCache = new Map()
const pending = new Map()
let observer = null
let scanTimer = null
let styleElement = null
let started = false

function luaString(value) {
  return '"' + String(value ?? "").replace(/\\/g, "\\\\").replace(/"/g, '\\"').replace(/[\r\n]/g, " ") + '"'
}

function decodeLuaResult(result) {
  if (result && typeof result === "object") return result
  if (typeof result !== "string") return null
  try { return JSON.parse(result) } catch (_) {}
  // Some CEF/Lua bridge builds wrap the returned JSON string one more time.
  try { return JSON.parse(JSON.parse(result)) } catch (_) {}
  return null
}

function keyFromTile(tile) {
  const nodes = [tile, ...tile.querySelectorAll("img, [style]")]
  const values = []
  for (const node of nodes) {
    for (const attr of ["src", "data-src", "data-original", "ng-src", "style", "alt", "title"]) {
      const value = node.getAttribute?.(attr)
      if (value) values.push(value)
    }
    if (node.currentSrc) values.push(node.currentSrc)
  }
  for (const value of values) {
    const decoded = String(value).replace(/\\\//g, "/")
    const match = decoded.match(/(?:^|[\\/])((?:vehicles|levels))[\\/]([A-Za-z0-9_.-]+)(?=[\\/?#]|$)/i)
    if (match) {
      return { kind: match[1].toLowerCase() === "vehicles" ? "vehicle" : "level", id: match[2] }
    }
  }
  return null
}

function inSelector() {
  const route = String(window.location?.hash || "").toLowerCase()
  return /vehicle-selector|freeroam-wizard|freeroam-selector|level-selector/.test(route)
}

async function getInfo(key) {
  const cacheKey = `${key.kind}:${key.id}`
  if (infoCache.has(cacheKey)) return infoCache.get(cacheKey)
  if (pending.has(cacheKey)) return pending.get(cacheKey)
  const request = runRaw(`extensions.vehicle_mod_quick_disable.getSourceInfo(${luaString(key.kind)}, ${luaString(key.id)})`)
    .then(decodeLuaResult)
    .catch(() => null)
    .then(result => {
      const info = result?.ok && result.info ? result.info : null
      if (info) infoCache.set(cacheKey, info)
      pending.delete(cacheKey)
      return info
    })
  pending.set(cacheKey, request)
  return request
}

function buttonMarkup(button, tile, key) {
  button.type = "button"
  button.className = BUTTON_CLASS
  button.textContent = "⏻"
  button.title = "Çaktivizo modin e kësaj veture/h harte"
  button.setAttribute("aria-label", "Çaktivizo modin e kësaj veture ose harte")
  button.dataset.kind = key.kind
  button.dataset.itemId = key.id
  button.dataset.ready = "0"
  button.addEventListener("mouseenter", async () => {
    if (!inSelector()) return
    const info = await getInfo(key)
    if (info && info.active) {
      button.dataset.ready = "1"
      button.dataset.filename = info.filename || ""
      button.title = `Çaktivizo: ${info.filename || info.name}`
    } else {
      button.dataset.ready = "0"
      button.title = "Kjo veturë/hartë s’ka mod të çaktivizueshëm"
    }
  }, { passive: true })
  button.addEventListener("click", async event => {
    event.preventDefault()
    event.stopPropagation()
    event.stopImmediatePropagation()
    if (!inSelector()) return
    const info = await getInfo(key)
    if (!info || !info.active) return

    const answer = await openConfirmation(
      "Çaktivizo këtë mod?",
      `Artikulli: ${tile.innerText?.trim().split("\n")[0] || key.id}\nZIP-i: ${info.filename || "emër i panjohur"}\n\nDo të çaktivizohet i gjithë ZIP-i, jo vetëm kjo veturë/hartë. Nuk fshihet asnjë skedar. Pastaj mundesh me e fshi vetë ZIP-in te Mods.`,
      [
        { label: "Anulo", value: "cancel", extras: { cancel: true, outsideCancel: true, accent: ACCENTS.text } },
        { label: "Çaktivizo modin", value: "disable", extras: { default: true, confirm: true, accent: ACCENTS.main } },
      ],
    )
    if (answer !== "disable") return

    button.disabled = true
    button.textContent = "…"
    let result = null
    try {
      result = decodeLuaResult(await runRaw(
        `extensions.vehicle_mod_quick_disable.deactivate(${luaString(key.kind)}, ${luaString(key.id)}, ${luaString(info.filename || "")})`
      ))
    } catch (_) {}

    if (result?.ok) {
      infoCache.set(`${key.kind}:${key.id}`, null)
      button.textContent = "✓"
      button.title = `U çaktivizua: ${result.filename || info.filename}`
      button.dataset.ready = "0"
      await openConfirmation(
        "Modi u çaktivizua",
        `${result.filename || info.filename} u çaktivizua, nuk u fshi. Kthehu te Mods Manager dhe fshije këtë ZIP kur të jesh gati. Mund të duhet me dalë e me rihap selector-in që vetura të largohet prej listës.`,
        [{ label: "Në rregull", value: "ok", extras: { default: true, confirm: true, accent: ACCENTS.main } }],
      )
    } else {
      button.disabled = false
      button.textContent = "⏻"
      await openConfirmation(
        "S’u çaktivizua",
        result?.error || "Nuk u gjet ZIP-i burimor për këtë kartelë.",
        [{ label: "Në rregull", value: "ok", extras: { default: true, confirm: true, accent: ACCENTS.main } }],
      )
    }
  })
  tile.appendChild(button)
}

function installStyle() {
  if (document.getElementById(STYLE_ID)) return
  styleElement = document.createElement("style")
  styleElement.id = STYLE_ID
  styleElement.textContent = `
    .tile { position: relative !important; }
    .${BUTTON_CLASS} {
      position: absolute; top: .4rem; right: .4rem; z-index: 40;
      display: none; width: 2.15rem; height: 2.15rem; padding: 0;
      align-items: center; justify-content: center; border-radius: 50%;
      border: 1px solid rgba(255,255,255,.72); color: #fff;
      background: rgba(22,28,38,.93); box-shadow: 0 2px 8px rgba(0,0,0,.48);
      font: 800 1.05rem/1 sans-serif; cursor: pointer; pointer-events: auto;
    }
    .tile:hover > .${BUTTON_CLASS}[data-ready="1"] { display: flex; }
    .${BUTTON_CLASS}:hover { background: #df8b20; border-color: #fff; transform: scale(1.06); }
    .${BUTTON_CLASS}:disabled { opacity: .65; cursor: wait; }
  `
  document.head?.appendChild(styleElement)
}

function scanTiles() {
  scanTimer = null
  if (!started || !document.body) return
  installStyle()
  if (!inSelector()) return
  for (const tile of document.querySelectorAll(".tile")) {
    if (tile.querySelector(`:scope > .${BUTTON_CLASS}`)) continue
    const key = keyFromTile(tile)
    if (!key) continue
    const button = document.createElement("button")
    buttonMarkup(button, tile, key)
  }
}

function scheduleScan() {
  if (scanTimer || !started) return
  scanTimer = window.setTimeout(scanTiles, 120)
}

export async function onLoad() {
  if (started) return
  started = true
  installStyle()
  observer = new MutationObserver(scheduleScan)
  observer.observe(document.documentElement, { childList: true, subtree: true, attributes: true, attributeFilter: ["src", "data-src", "style"] })
  scheduleScan()
}

export async function onUnload() {
  started = false
  if (observer) observer.disconnect()
  observer = null
  if (scanTimer) window.clearTimeout(scanTimer)
  scanTimer = null
  document.querySelectorAll(`.${BUTTON_CLASS}`).forEach(button => button.remove())
  document.getElementById(STYLE_ID)?.remove()
  styleElement = null
  infoCache.clear()
  pending.clear()
}
