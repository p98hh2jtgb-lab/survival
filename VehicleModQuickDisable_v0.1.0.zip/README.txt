VEHICLE MOD QUICK DISABLE v0.1.0 — BeamNG.drive 0.39.4
======================================================

QËLLIMI
-------
Shton një ikonë të vogël ⏻ mbi kartelat e veturave/hartave në selector. Ikona shfaqet kur kalon mausin mbi kartelë. Ajo e gjen ZIP-in burimor, ta tregon emrin e saktë dhe e çaktivizon me konfirmimin tand.

E RËNDËSISHME
-------------
- Nuk e fshin ZIP-in. Pasi çaktivizohet, ti mundesh me e fshi vetë te Mods Manager ose prej folderit Mods.
- Çaktivizimi vepron mbi MODIN/ZIP-in e krejt, jo veç mbi një veturë. Nëse ZIP-i ka disa vetura ose përmbajtje tjetër, krejt çaktivizohet. Emri i ZIP-it shfaqet para konfirmimit.
- Modet origjinale të BeamNG-së nuk çaktivizohen.
- Nëse kartela nuk e ka një preview me rrugë të identifikueshme, butoni nuk shfaqet për atë kartelë.
- Pas çaktivizimit, mund të duhet me dalë e me rihap selector-in që artikulli të largohet prej listës.

INSTALIMI
---------
1. Mbylle BeamNG.drive.
2. Vendose VehicleModQuickDisable_v0.1.0.zip te folderi Mods i userfolder-it të BeamNG.drive. Mos e çzip-o.
3. Nise lojën dhe hape Vehicle Selector ose Level Selector.
4. Kaloje mausin mbi kartelën e modit; shtype ikonën ⏻.
5. Kontrolloje emrin e ZIP-it në dritaren e konfirmimit. Nëse është ai që do, zgjidhe “Çaktivizo modin”.
6. Pastaj shko te Mods Manager dhe fshije ZIP-in kur të jesh gati.

KTHIMI MBRAPA
-------------
Nëse e çaktivizon gabimisht, hape Mods Manager dhe aktivizoje përsëri. ZIP-i nuk është fshirë.

STATUSI I TESTIMIT
------------------
Paketuar për BeamNG.drive 0.39.4. Kontrolli statik është kryer në kod, por ky sandbox nuk e nis lojën BeamNG; duhet provuar në lojë. Ky është build-i i parë testues. Nëse ikona nuk shfaqet, ose del ndonjë gabim, dërgo screenshot të selector-it dhe, nëse mundesh, tekstin e kuq nga UI Console me Ctrl+U.
