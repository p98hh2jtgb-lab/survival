HUD PRO v5.9.9 — Ctrl+1 PUNON + FOTO E MODIT PA SCREENSHOT (Ctrl+2)
==================================================================

ÇKA U RREGULLUA (v5.9.9)
------------------------
1) FOTO LIVE (Ctrl+1) — GJETUR ARSYEJA E VËRTETË PSE NUK PUNONTE
   Në v5.9.8 fotoja që dilte në rrumullak ishte SCREENSHOT I EKRANIT TË PLOTË
   (me panelin e modit brenda) — sepse dy rrugët e render-it nuk shkruanin
   fajll, dhe modi kalonte te "screenshot klasik".
   Tani:
   - Fajlli provohet të shkruhet në TRI trajta rruge (relative, me '/', dhe e
     zgjatura e plotë) derisa njëra të shkruajë — kjo ishte pengesa.
   - Rruga e screenshot-it klasik u HOQ krejt: ai nxinte gjithë ekranin +
     panelin dhe e priste foton.
   - Kamera = e njëjta matematikë e lojës për thumbnailet (frameVehicle):
     fov 20, 500x281, kënd 3/4 mbrapa (ose përpara) — makina e madhe, si
     default.jpg i lojës.
   - Nëse kapja ose prerja e sfondit dështon -> vjen VETË foto e modit.
     Me Ctrl+1 nuk mbetesh KURRË pa foto të mirë.

2) FOTO E MODIT PA SCREENSHOT — Ctrl+2 (e re)
   Shtyp Ctrl+2 (ose butonin "🖼 Foto e modit") dhe modi e merr vetë foton
   zyrtare të makinës nga dosja e lojës, i heq sfondin dhe e ven në rrumullak.
   Asnjë screenshot, asnjë dorëzim manual.

3) FSHIRJA E SFONDIT — KUFI I RI (mos hante makinën)
   Toleranca ma e lart se 40 NUK lejohet ma (rrëshqitësi: 8-40). Vlerat e
   vjetra ma të larta kthehen vetë në 32. Kjo ishte arsyeja që fotot e
   ndritshme dilnin "vetëm dritare e goma" — pra "s'po dilte mirë asnjo".
   Veç kësaj: nëse prerja e fortë del vetëm siluetë (hangeri makinën), modi
   e kupton dhe merr prerjen ma të butë.

4) DIAGNOSTIKA — fusha të reja
   Butoni "🩺 Diagnostikë LIVE" tani tregon edhe: fov, wrote (a u shkrua
   fajlli), takeVar (cila trajtë rruge), classic (ndryshimi i hequr).

SI TË TESTOHET
--------------
1) Fshij versionet e vjetra nga mods/ (5.9.4 ... 5.9.8) dhe veç këtë ZIP.
   Rifillo lojën.
2) Kalo në një makinë, shtyp Ctrl+1. Duhet: "✓ LIVE: foto u vendos (KB, jpg)"
   ose, nëse kapja nuk punon në PC-në tënd, "→ foto e modit" — GJITHMONË
   duhet një foto e mirë në rrumullak.
3) Shtyp Ctrl+2: fotoja e modit, pa screenshot.
4) Shiko rrathët: fotot duhet të duken qartë edhe pa i prekur.
5) Shtyp L/H: PASS/FAIL duhet të duket VETËM te rrathët (unaza e gjelbër me ✓
   ose e kuqe me ✕), pa X/✓ të madh mes ekranit.

Nëse ndonjë gjë nuk punon, shtyp "🩺 Diagnostikë LIVE" dhe dërgo foton e
ekranit me ato që shkruan.

-----------------------------------------------------------------------------

HUD PRO v5.9.8 — FOTO LIVE E KORNIZUAR SI THUMBNAIL-I I LOJES
============================================================

ÇKA U RREGULLUA (v5.9.8)
------------------------
1) FOTO LIVE (Ctrl+1) — MAKINA TANI DEL E MADHE, JO SI SCREENSHOT I LOJES
   v5.9.7-s e kapte foton, po korniza ishte e keqe: makina dilte e vogël në
   një foto të madhe (shpesh edhe screenshot i ekranit të plotë), e pastaj
   heqja e sfondit linte një foto të shëmtuar.
   Tani:
   - Kamera llogaritet me TË NJËJTËN matematikë që përdor VET loja për
     thumbnailet e makinave (util_screenshotCreator.frameVehicle):
     makina mbulon ~83% te kornizes, kënd 3/4 (mbrapa ose përpara), fov 32.
   - Fotoja bëhet 500x281 (e njëjta madhësi si default.jpg e lojes), JPG i
     vogël (~50-80 KB), PA HUD dhe pa panele brenda fotos.
   - Rruga 1: render view i vet (s'varet nga ekstensione te tjera te lojes).
   - Rruga 2: render_renderViews.takeScreenshot (API-ja e lojes) — tani
     parangarkohet gameplay_markerInteraction, se pa ate fajlli nuk shkruhet.
   - Rruga 3: screenshot klasik i lojes.  Rruga 4: foto e modit.
     Renditja bëhet vetë; Ctrl+1 nuk mbetet KURRË pa foto.
   - Lua kthen edhe "crop" (ku ndodhet makina në foto) -> UI-ja pret vetëm
     atë pjesë PARA heqjes së sfondit, pastaj provon disa toleranca dhe
     zgjedh më të mirën (pa hije, pa mbeturina, pa prerje aksidentale).
   - Statusi në panel:  ✓ LIVE: foto u vendos (KB, jpg)  ose  ✗ LIVE: arsyeja
   - Butoni "🩺 Diagnostikë LIVE" tregon çka mbeshtet loja (jobsystem, render
     view manager, markerExt, faza, crop) — nëse diçka nuk punon, aty shihet.

2) RRATHËT E RRUMLULLAKUT — FOTOT GJITHMONË TË DUFSHME (jo vetëm kur kalon)
   Ma parë vetëm rrethi i zgjedhur e tregonte foton qartë; të tjerët ishin
   të zbehtë (38%). Tani TË GJITHA fotot janë 100% të dukshme gjithmonë.

3) EFEKTI FULL-SCREEN PASS/FAIL — HEQUR KREJT (nga v5.9.7)
   X/✓ i madh mes ekranit + ngjyra anash nuk shfaqen ma kur shtyp L/H.
   PASS/FAIL duket VETËM te rrathët: unaza e gjelbër me ✓ ose e kuqe me ✕.

SI TË TESTOHET
--------------
1) Fshij versionet e vjetra nga mods/ (5.9.4, 5.9.5, 5.9.6, 5.9.7) dhe veç
   këtë ZIP. Rifillo lojën.
2) Hap panelin -> "Reaksionet -> Auto foto". Kliko "🩺 Diagnostikë LIVE" dhe
   shiko çka shkruan (nëse diçka është 'pa', ai është problemi).
3) Kalo në një makinë dhe shtyp Ctrl+1 (ose butonin "📸 Foto LIVE").
   Duhet të shfaqet: "✓ LIVE: foto u vendos (XX KB, jpg)" dhe fotoja e
   makinës në rrumullak — e madhe, e prerë mirë, pa sfond.
4) Shiko rrathët: fotot duhet të duken qartë edhe pa i prekur.

Nëse diçka nuk punon, dërgo foton e ekranit me statusin e Diagnostikës LIVE.

-----------------------------------------------------------------------------

HUD PRO v5.9.7 — FOTO LIVE E RREGULLUAR + RRATHËT E QARTË
==========================================================

ÇKA U RREGULLUA (v5.9.7)
------------------------
1) FOTO LIVE (Ctrl+1) — TANI PUNON
   v5.9.6-s s'e kapte foton: rruga e vjetër (color buffer) nuk ekziston në
   BeamNG.drive dhe screenshot-i nuk lexohej dot. Tani:
   - Modi i kërkon vetë lojës një render offscreen të makinës
     (render_renderViews.takeScreenshot) me kamer 3/4 rreth makinës,
     madhësi 800x450 -> fajll i vogël JPG, pa HUD në foto.
   - UI-ja e pyet lojën çdo 300ms dhe e merr foton direkt (base64) -> e pret
     sfondin vetë -> e ve në rrumullak.
   - Nëse kjo rrugë nuk punon në versionin tond, provon vetë screenshot-in
     klasik të lojës. Nëse as ajo, kalon VETË në foton e modit.
     Kështu Ctrl+1 GJITHMONË të jep një foto — kurrë "asgjë".
   - Në panelin "Reaksionet -> Auto foto" shkruan statusi i saktë:
       ✓ LIVE: foto u vendos (KB, jpg)   ose   ✗ LIVE: <arsyeja>
   - Butoni i ri "🩺 Diagnostikë LIVE" të tregon çka mbeshtet loja (nëse
     diçka nuk punon, aty shihet arsyeja e saktë).
   - Butonat "3/4 mbrapa / 3/4 përpara" ndërrojnë këndin e kamerës.

2) FOTOT NË RRATHË DUKEN GJITHMONË
   Ma parë vetëm rrethi i zgjedhur e tregonte foton qartë, të tjerët ishin
   të zbehtë (45%). Tani të gjitha fotot janë 100% të dukshme.

3) EFEKTI FULL-SCREEN PASS/FAIL U HOQ KREJT
   X/✓ i madh në mes të ekranit + ngjyra anash nuk shfaqen ma kur shtyp
   K/L (PASS/FAIL). PASS/FAIL tani duket VETËM te rrathët: unaza e gjelbër
   me ✓ ose unaza e kuqe me ✕ brenda rrethit.

NDRYSHIME NË PANEL
------------------
- 3 sliderat "Pozicioni i PASS/FAIL X/Y" dhe "Madhësia e PASS/FAIL" u hoqën
  (s'kanë ma kuptim, efekti u hoq).
- Shtuar: butoni 🩺 Diagnostikë LIVE, statusi LIVE, butonat e këndit të kamerës.
- Diagnostika (tabi TJERA) tregon edhe statusin e fotos LIVE.

SI ME PROVU
-----------
1. Fshiji ZIP-et e vjetra te Documents/BeamNG.drive/mods, lëre vetëm këtë.
2. Restarto lojën (jo vetëm Reload UI).
3. Spawno makinën, vendos kamerën si do, ndal (0 km/h).
4. Shtyp Ctrl+1 (ose butonin 📸 Foto LIVE). HUD-i fshihet ~1 sekondë,
   pastaj fotoja del në rrumullak me sfond të prerë.
5. Nëse del "✗ LIVE: ..." — shtyp 🩺 Diagnostikë LIVE dhe dërgo tekstin.

HUD PRO v5.9.6 — FOTO LIVE ME Ctrl+1 (kerri ashtu si eshte ne loje)
====================================================================

ÇKA E BAN TASH Ctrl+1
---------------------
Shtyp Ctrl+1 -> modi e kap EKRANIN E LOJES (kerri ashtu si eshte spawn,
me pozicion, ngjyra e dëmtime) -> i heq sfondin automatikisht -> e ve
foton ne rrumullak. Pa foto te modit, pa screenshot manuale.

SI PUNON (3 rruge, po provohen vet):
1) "Color buffer" i lojes: getColorBufferBase64 / Engine.getColorBufferBase64
   (frame i fundit i renderuar, 384x216) -> kthehet direkt si base64.
   - Nese vjen RGBA i papërpunuar, UI-ja e kthen ne foto.
   - Nese vjen PNG i gatshem, e njeh vete (iVBORw0KGgo).
2) Nese rruga 1 s'ekziston ne versionin tond: modi kerkon qe LOJA ta bej
   foton (doScreenshot / triggerScreenshot), pret ~30 frame, e lexon
   fajllin, e dergon te UI-ja dhe e fshin mbas vetes.
3) Nese as kjo s'punon: pas 7 sekondash kalon vete ne foton e modit
   (si ma pare) — kshtu Ctrl+1 gjithmone ben diçka.

GIATE KAPJES
------------
HUD-i fshihet per ~1 sekonde (qe te mos hyje ne foto). Nese kapja del
me koke poshte (disa versione e japin buffer-in nga poshte lart), kyç
checkbox-in "kthe foton LIVE vertikalisht" ne panel.

OPSIONE TE REJA (te Reaksionet -> Auto foto)
--------------------------------------------
- Butoni  "📸 Foto LIVE (Ctrl+1)"   dhe  "🖼 Foto e modit"
- Checkbox "Ctrl+1 = foto LIVE nga loja (kerri si është)"  (default ON)
- Checkbox "kthe foton LIVE vertikalisht"
- Slideri "Fshirja e sfondit" (8-70) vlen edhe per LIVE.

PER LIVE MA MIRE
----------------
- Vendose kamerën n'kend te mire (3/4 pamje) dhe hiqe shpejtesine (0 km/h)
  qe kerri te dale i qete ne foto.
- Nese sfondi eshte i ngaterruar (shumë detaje), rrite tolerancën në 45-60.
- Nese do vetem kerri: pozicionoje makinën para nji sfondi te thjeshte
  (qiell, asfalt, bar i njetrajtshem).

HUD PRO v5.9.5 — FOTO MA "CLEAN" (fshirje sfondi v2)
=====================================================

ÇKA U NDRYSHUA
--------------
1) Algoritmi i re i fshirjes se sfondit (zëvendëson flood-fill-in e vjetër):
   - Modeli i sfondit ndërtohet prej KUFIRIT te fotos (unaza 2px, ngjyrat
     grupohen ne max 5 "klastera") -> punon edhe me gradient/vignette.
   - Flood-fill adaptiv: çdo hap krahasohet ME SFONDIN LOKAL (jo veç me
     pikselin fqinj) + kontroll global kundrejt modelit te sfondit.
   - Pastrim "halo"-je: 2 kalime qe heqin skajin e piste gri rreth makines.
   - Alpha e bute sipas largesise prej sfondit (skaje pa shkallare).
2) Hiqet vete HIJEJA nën makine:
   - Masa tolerancen vete (32 -> 43 -> 58 -> 70) sa kohe mbetet hije e hapur.
   - Gomat e zeza/dritaret NUK preken, sepse numrohen si "te erret", jo si hije.
   (Testet: hija e mbetur 12-19% -> 0.0-0.4%, gomat te paprekura.)
3) Toleranca default tani 32 (ma pare 28). Slideri në panel mbetet 8-70.
4) Nese prerja deshton (p.sh. sfond shume i ngjashem me makinen), kthehet
   automatikisht ne rrugen e vjeter dhe, ne fund, ne foton e plote — pa "null".

ÇKA MBETET
----------
Ctrl+1 / butoni 📸 Auto foto / butoni 📸 Auto për çdo rrumullak / foto
automatike kur ndërron makina (checkbox). Rruga e fotos: be:getObjectByID
(ndryshimi i v5.9.4) mbetet.

HUD PRO v5.9.4 — RREGULLIM: AUTO FOTO (foto e makines ne rrumullak)
====================================================================

ÇKA ISHTE E PRISHUR (v5.9.0 – v5.9.2)
------------------------------------
Kodi i Lua-s e kerkonte makinen e lojtarit me  be:getObject(vehId)  — por
kjo funksion pret nje INDEKS (0 .. be:getObjectCount()-1), JO ID-ne e
makines. Me nje ID kthente gjithmone nil, kshtu qe lista e fotove mbetej
e zbrazet dhe asgje nuk hynte ne rrumullak: as me butonin
"Auto foto (Ctrl+1)", as automatikisht kur ndrron makinen.
Fajlli i fotos nuk gjendej kurre — s'kish faj as fotoja as mod-i tjeter.

ÇKA U RREGULLUA (v5.9.4)
-----------------------
- be:getObjectByID(vehId) — rruga e sakte per ID (be:getPlayerVehicle(0)
  mbetet rruga e dyte nese API-ja mungon).
- Fushat JBeam/partConfig lexohen edhe me  veh:getField('JBeam','')
  (disa versione te lojes i ekspozojne vetem kshtu).
- Inline-Lua e butonit u forcua ne te njejten menyre — pa error edhe kur
  JBeam vjen vetem me getField.
- Fallback i URL-se: provohet edhe  local://local/vehicles/...
- default.jpeg si kandidat shesh + diagnostika ne konsolen CEF (Ctrl+U):
     [HUD PRO] autofoto: ...
- mod.json / app.json tani shkruajne v5.9.4 (ma pare 5.6.1, e vjeter).

SI ME PROVU
-----------
1. Fshij çdo ZIP te vjeter CreatorPack te Documents\BeamNG.drive\mods
   (veçanerisht v5.9.0 / v5.9.1 / v5.9.2 / v5.9.3) dhe lere vetem
   CreatorPack_v5.9.4.zip.
2. Restarto lojen (ose Mods -> Reload UI).
3. Paneli -> Reaksionet -> "Auto foto (Ctrl+1)": fotoja duhet te hyje ne
   rrumullakun e zgjedhur dhe te dale edhe si preview i vogel.
4. Per automatikisht: ndize  "Foto automatike kur ndrron makinen".

HUD PRO v5.6.0 — MEME SOUND EFFECTS
===================================
4 zëra që bien vetë (vendosi .mp3 te ui/modules/apps/CreatorPack/sounds/):
  hit.mp3       goditje ≥8%
  bighit.mp3    goditje e fortë ≥20%
  critical.mp3  kur hyn në 1–5% (nji herë)
  dead.mp3      0% (nji herë)
Paneli → Zë: Meme SFX ON/OFF, volumi, butona test për secilin.

HUD PRO v5.5.0 — EMOJI 3D NË ÇDO FRAZË
=====================================
• Krejt 1056 frazat kanë emoji që i përshtatet fjalës (187 emoji të ndryshme).
• Emoji dalin si foto 3D (Microsoft Fluent 3D, licencë MIT) — duken shumë
  si iOS dhe njejt në çdo PC, pa varë prej Windows-it.
• Paneli → Reaksionet: "Emoji në çdo frazë" (on/off) dhe "Emoji 3D"
  (fike për emoji të zakonshme të Windows-it).
• Emoji Mood i vjetër (😎 veç nji për nivel) fiket automatikisht që
  mos me dal dy emoji. Mundesh me e ndezë prap te paneli.

HUD PRO v5.4.0 — 22 STILE REAKSIONESH NËN SURVIVAL CHANCE
=========================================================

• 22 stile + Custom (zgjedhen te paneli → Reaksionet).
• 6 nivele sipas përqindjes: 76–100 · 51–75 · 26–50 · 6–25 · 1–5 · 0%.
• 8 fraza për çdo nivel (1056 gjithsej), ndërrohen çdo 3 sekonda,
  rastësisht, pa u përsërit e njejta dy herë rresht.
• Custom ka 6 fusha (nji për çdo nivel).
• Glow-i i kuq i butë nga v5.3.3 mbetet.

LISTA E PLOTË
-------------

[CINEMATIC]
  76-100%: ALL QUIET · IN CONTROL · CLEAR SKIES · STEADY HANDS · CALM BEFORE · UNTOUCHED · FOCUSED · ON COURSE
  51-75% : SOMETHING'S COMING · STAY SHARP · EYES OPEN · THE AIR CHANGES · TENSION RISES · NOT ALONE · WATCH THE ROAD · FIRST CRACKS
  26-50% : BRACE YOURSELF · NO MARGIN LEFT · THE ODDS TURN · PRESSURE MOUNTS · HOLD THE LINE · TIME RUNS SHORT · ON THIN ICE · EVERYTHING SHAKES
  6-25%  : DON'T BLINK · BRACE FOR IMPACT · THIS COULD BE IT · NO WAY BACK · SECONDS LEFT · DANGER CLOSE · HANGING BY A THREAD · EVERYTHING ON THE LINE
  1-5%   : LAST CHANCE · THIS IS IT · ONE MORE HIT... · FINAL SECONDS · NOW OR NEVER · THE LAST BREATH · ONE SHOT LEFT · AGAINST ALL ODDS
  0%     : LIGHTS OUT · FADE TO BLACK · THE END · ROLL CREDITS · SILENCE · IT'S OVER · CUT. · NO SEQUEL

[DRAMATIC]
  76-100%: LOOKING GOOD · STILL STRONG · ALL GOOD · HOLDING UP · FEELING GOOD · NOTHING TO FEAR · SOLID · UNBROKEN
  51-75% : CAREFUL... · GETTING RISKY · NOT SO SAFE... · THAT WAS CLOSE · HOLD STEADY · IT'S SLIPPING · EASY NOW... · FEEL THAT?
  26-50% : HOLD ON! · THIS IS BAD · IT'S FALLING APART · NOT GOOD · WE'RE LOSING IT · FIGHT IT! · STAY WITH ME · PLEASE HOLD
  6-25%  : NO... NO... · IT'S BREAKING · HANG ON! · DON'T GIVE UP · SO MUCH DAMAGE · IT CAN'T END · KEEP FIGHTING · NOT LIKE THIS
  1-5%   : NO WAY · STILL BREATHING?! · BARELY ALIVE · ONE LAST PUSH · HOW?! · DON'T YOU DARE · HOLD ON... PLEASE · IT'S NOT OVER!
  0%     : IT'S OVER · GONE. · NOTHING LEFT · HEARTBREAK · IT'S FINISHED · ALL IS LOST · NO MORE · FAREWELL

[STREAMER]
  76-100%: WE'RE GOOD · EASY MONEY · CHAT WE CHILLING · LOOKIN' CLEAN · NO STRESS · W DRIVING · CLIP THAT · TOO EASY CHAT
  51-75% : GETTING SPICY · CAREFUL NOW · CHAT... · AYO? · WE GOOD? · OKAY OKAY · THAT'S SUS · HOLD UP
  26-50% : CHAT IT'S BAD · UH OH · NAH WAIT · BRO WHAT · WE'RE TWEAKING · CHAT HELP · NOT THE BUMPER · THIS AIN'T IT
  6-25%  : BRO PLEASE · CHAT PRAY FOR ME · AIN'T NO WAY · WE'RE SO BACK? · NAHHH · CHAT DON'T CLIP · HANDS SHAKING · I'M SWEATING
  1-5%   : CHAT I'M COOKED 💀 · BRO PLEASE 😭 · AIN'T NO WAY · ONE HP CHAT · CLIP IT CLIP IT · HOW AM I ALIVE · DON'T BREATHE · CHAT HOLD MY HAND
  0%     : CHAT I'M COOKED · GG CHAT · WE'RE DONE · L + RATIO · ENDING STREAM · CHAT IT'S JOEVER · RUN IT BACK · UNINSTALLING

[YOUTUBE]
  76-100%: STAY TILL THE END · WATCH THIS · EASY... FOR NOW · SO FAR SO GOOD · HERE WE GO · PERFECT RUN? · ALL SMILES · KEEP WATCHING
  51-75% : WAIT FOR IT... · HERE IT COMES · OH? · THIS GETS WORSE · NOTICE THAT? · PLOT TWIST? · HMM... · IT STARTS
  26-50% : WATCH CLOSELY · SO CLOSE · WHAT JUST HAPPENED? · OH NO... · IT GETS WORSE · DON'T SKIP · REWIND THAT · BIG MISTAKE
  6-25%  : NO WAY... · LOOK AT THIS · THE WORST PART · IS THIS THE END? · YOU SEE THAT?! · COMMENT IF ALIVE · KEEP WATCHING · HOW MUCH MORE?
  1-5%   : WAIT... WHAT?! · HOW IS THIS ALIVE · 1% CLUTCH? · UNREAL · NO WAY IT HOLDS · BEST MOMENT · DON'T LOOK AWAY · SUBSCRIBE IF IT LIVES
  0%     : AND THAT'S THAT · WELL... THAT HAPPENED · SEE YOU NEXT VIDEO · THAT'S A WRAP · TOTALLED · REPLAY? · LIKE IF YOU CRIED · 0% ACHIEVED

[MEME]
  76-100%: VIBING 😎 · STONKS 📈 · BIG CHILLIN · WE CHILLIN · TOP G DRIVER · EZ CLAP · SIGMA MODE · NPC BEHAVIOR
  51-75% : HMMM 🤨 · SUS · BRO? 🤨 · UH... 👀 · NOT STONKS 📉 · SIDE EYE 👀 · WELL... · HOUSTON?
  26-50% : BRO 💀 · NAHH 😭 · THIS IS FINE 🔥 · EMOTIONAL DAMAGE · OOF · YIKES · BONK · BRUH
  6-25%  : WELL... 💀 · INSTANT REGRET · F IN THE CHAT · SEND HELP · TO BE CONTINUED · HE'S LOST IT 😭 · OUCH OWIE · CAR SAID NO
  1-5%   : 1 HP 💀 · HOLD MY BEER · PLOT ARMOR? · LOADING... 1% · BRO IS A CAT 🐈 · HOW 😭 · NOT DEAD YET · SPEEDRUN %
  0%     : COOKED · RIP · WASTED · F · GG 💀 · YOU DIED · RIP BOZO · PRESS F

[SAVAGE]
  76-100%: BEGINNER'S LUCK · DON'T GET COCKY · WON'T LAST · ENJOY IT · SUSPICIOUSLY OK · EVEN YOU CAN'T FAIL · NOT BAD... YET · SURPRISING
  51-75% : WHO GAVE YOU KEYS? · DRIVING TEST FAIL · THAT WAS YOU · BRAKES EXIST · NICE ONE, GENIUS · WOW. JUST WOW. · GOOGLE 'STEERING' · BOLD MOVE
  26-50% : SKILL ISSUE · NICE DRIVING 💀 · AMAZING JOB... · PEAK TALENT · GET A BUS PASS · THAT'S EMBARRASSING · CERTIFIED MENACE · INSURANCE CRIES
  6-25%  : YOU HAD ONE JOB · 10/10 DRIVING · SHOULD'VE WALKED · HISTORY IN MAKING · TRULY GIFTED · PROUD OF YOU? NO · LICENSE REVOKED · DID YOU CLOSE EYES?
  1-5%   : IMPRESSIVELY BAD · HOW? JUST HOW? · ALMOST TALENT · UNIQUE SKILLSET · CAR BEGS MERCY · YOU'RE DOING GREAT 🙂 · STILL? PATHETIC · WORLD RECORD FAIL
  0%     : WELL DESERVED · SKILL ISSUE · TOLD YOU · TAKE THE BUS · NICE DRIVING 💀 · CAREER OVER · LEGENDARY FAIL · UNINSTALL

[CHAOTIC]
  76-100%: VROOOM · YEEHAW · FULL SEND! · WHEEE · LET'S GOOO · NO BRAKES! · ZOOM ZOOM · YAHOO!
  51-75% : WAIT WHAT · HUH?! · WHO DID THAT · EEEK · WOAH WOAH · WHAT WAS THAT · OOPS? · ACK!
  26-50% : OH GOD · ABORT ABORT · WHAT IS HAPPENING · MAYDAY! · EVERYTHING HURTS · AAAAH · WHY IS IT SPINNING · FIRE?!
  6-25%  : NO NO NO · HELP · ALARMS EVERYWHERE · PULL UP PULL UP · WHERE ARE THE BRAKES · I CAN'T SEE · AAAAAAAH · RED ALERT
  1-5%   : AAAAAAAAA · EJECT EJECT · SYSTEM MELTDOWN · EVERYTHING IS ON FIRE · WHAT WHY HOW · OH NONONONO · SOMEBODY DO SOMETHING · HOLY—
  0%     : KABOOM · WELP. · SPLAT · ERROR 404: CAR · CHAOS WON · BOOM. · CRASH.EXE · ...WHAT

[DEADPAN]
  76-100%: FINE. · ACCEPTABLE. · ADEQUATE. · NO COMPLAINTS. · TOLERABLE. · UNREMARKABLE. · IT'S A CAR. · GOING.
  51-75% : HM. · NOTED. · INTERESTING. · SLIGHTLY WORSE. · WELL THEN. · THAT HAPPENED. · LESS FINE. · OKAY.
  26-50% : NOT IDEAL. · THAT'S A PROBLEM. · UNFORTUNATE. · CONCERNING. · SUBOPTIMAL. · DISAPPOINTING. · HOW NICE. · LOVELY.
  6-25%  : THIS SEEMS BAD. · QUITE BROKEN. · PROBABLY FINE. · MILDLY FATAL. · IT'S FINE. · AS EXPECTED. · REGRETTABLE. · HOW TYPICAL.
  1-5%   : STILL HERE. SOMEHOW. · BARELY. · STATISTICALLY RUDE. · IMPRESSIVE, I GUESS. · ONE PERCENT. NEAT. · CLOSE ENOUGH. · MORE OR LESS. · ANY SECOND.
  0%     : EXPECTED. · AND THAT'S THAT. · CAR: NO. · GREAT. · SHOCKING. NOT. · COMPLETE. · OK. · END.

[COMMENTATOR]
  76-100%: FLAWLESS SO FAR! · WHAT A DRIVE! · HE'S IN CONTROL! · BEAUTIFUL LINE! · TEXTBOOK! · CLEAN AS YOU LIKE! · LOOK AT HIM GO! · PERFECT START!
  51-75% : A LITTLE SCRAPE! · HE'S TAKEN A HIT! · DAMAGE REPORTED! · HE'LL FEEL THAT! · SLIGHT WOBBLE! · CAN HE RECOVER? · HE'S RATTLED! · CONTACT!
  26-50% : HE'S IN TROUBLE! · THIS IS CLOSE! · BIG DAMAGE! · HE'S LOSING IT! · OH HE'S HURT! · WHAT A HIT! · SMOKE FROM THE CAR! · HE'S STRUGGLING!
  6-25%  : HE'S STILL IN IT! · CAN HE HOLD ON?! · UNBELIEVABLE! · SERIOUS DAMAGE! · IT'S FALLING APART! · WHAT A DISASTER! · THE CROWD GASPS! · HANGING ON!
  1-5%   : HE'S BARELY ALIVE! · CAN HE SURVIVE?! · WHAT A SAVE! · YOU CANNOT SCRIPT THIS! · INCREDIBLE SCENES! · ON A KNIFE'S EDGE! · STILL MOVING! · HISTORY IN THE MAKING!
  0%     : IT'S ALL OVER! · AND HE'S OUT! · RETIRED! · THAT'S THE END! · DNF! · WHAT A FINISH! · HEARTBREAK! · NO WAY BACK!

[HORROR]
  76-100%: TOO QUIET... · SOMETHING WATCHES · DON'T RELAX · FOR NOW... · IT WAITS · STILL ALONE? · DON'T LOOK BACK · IT'S CALM. TOO CALM.
  51-75% : DID YOU HEAR THAT? · IT'S CLOSER · SOMETHING'S WRONG · THE LIGHTS FLICKER · DON'T STOP · FOOTSTEPS... · IT SAW YOU · COLD AIR
  26-50% : RUN. · IT'S HERE · NO ESCAPE · THEY'RE COMING · DON'T SCREAM · HIDE · THE DOORS ARE LOCKED · IT FOUND YOU
  6-25%  : IT'S TOO LATE · THE END IS NEAR · BEHIND YOU · NOWHERE TO HIDE · CAN'T GET OUT · IT'S INSIDE · THE DARK TAKES · SILENCE FALLS
  1-5%   : LAST CHANCE · ONE BREATH LEFT · IT'S SMILING · DON'T MOVE · IT'S RIGHT THERE · TOO CLOSE · CAN'T WAKE UP · THE CLOCK STOPS
  0%     : NO ONE SURVIVES · CONSUMED · THE DARK WINS · NEVER SEEN AGAIN · IT'S OVER · GOODNIGHT · SILENCE · TAKEN

[ACTION]
  76-100%: LOCKED AND LOADED · LET'S ROLL · HERE WE GO! · PEDAL DOWN · MISSION START · GEAR UP · HIT IT! · ENGINES HOT
  51-75% : INCOMING! · EVASIVE! · HEADS UP! · WE'VE GOT COMPANY · TAKE COVER · STAY ON TARGET · PUNCH IT! · MOVE MOVE!
  26-50% : HANG ON! · IMPACT INCOMING · WE'RE HIT! · GO GO GO! · HOLD IT TOGETHER · SHE CAN'T TAKE MUCH · DAMAGE CONTROL! · PUSH THROUGH!
  6-25%  : BRACE FOR IMPACT · NOT TODAY · HOLD ON TIGHT! · SHE'S BREAKING UP · ALL OR NOTHING · ENGINE FAILING! · DON'T QUIT NOW · TOO HOT!
  1-5%   : ONE LAST RUN · YIPPEE-KI-YAY · SAY YOUR PRAYERS · MAKE IT COUNT · FINAL STAND · JUMP! · IT'S NOW OR NEVER · THIS ENDS NOW
  0%     : MISSION FAILED · BOOM. · TARGET DOWN · WE LOST HER · OUT OF ACTION · KIA · SIGNAL LOST · HASTA LA VISTA

[ARCADE]
  76-100%: FULL HEALTH · PLAYER 1 READY · COMBO x3 · PERFECT! · HIGH SCORE! · BONUS STAGE · POWER UP! · 1UP
  51-75% : WARNING! · HP DROPPING · SHIELD DOWN · TAKE COVER! · ARMOR LOW · COMBO LOST · -100 PTS · HIT!
  26-50% : DANGER! · LOW HP · HEALTH LOW · BOSS ATTACK! · DODGE! · NEED HEALTH · COMBO BREAKER · OUCH! -250
  6-25%  : CRITICAL! · LAST LIFE · HP RED · FIND A MEDKIT · BEEP BEEP BEEP · LOW BATTERY · TIME RUNNING OUT · HEALTH CRITICAL
  1-5%   : 1 HP LEFT · EXTRA LIFE? · CONTINUE? · INSERT COIN · 9... 8... 7... · FINAL LIFE · POWER UP NEEDED · LAST HIT POINT
  0%     : GAME OVER · YOU LOSE · TRY AGAIN? · NO LIVES LEFT · PLAYER 1 DOWN · CONTINUE? NO · K.O. · THANKS FOR PLAYING

[GENZ]
  76-100%: LOWKEY GOATED · IT'S GIVING SAFE · NO CAP WE GOOD · MAIN CHARACTER · SLAY · UNBOTHERED · RENT FREE · ATE THAT
  51-75% : LOWKEY SUS · NOT THE VIBE · IT'S GIVING RISK · BRO... · HOLD UP FR · SLIGHTLY TWEAKING · UMM OK · RED FLAG 🚩
  26-50% : NAH THIS IS WILD · NOT GOOD FR · WE'RE TWEAKING · THIS AIN'T IT · BRO WHY · HIGHKEY BAD · NO BECAUSE WHY · IT'S GIVING DOOM
  6-25%  : BRO IS COOKED 💀 · WE'RE SO DONE · AIN'T NO WAY · I'M CRASHING OUT · NAHHH FR · IT'S JOEVER-ISH · DELULU TO SURVIVE · BRO...
  1-5%   : HOW IS BRO ALIVE · ON GOD 1% · IT'S GIVING MIRACLE · BRO REFUSES TO DIE · LITERALLY SHAKING · NO CAP HOW · CAN'T BE REAL · UNREAL AURA
  0%     : IT'S JOEVER · BRO IS COOKED · WE'RE SO DONE · MASSIVE L · AURA -1000 · NO SHOT · IT'S OVER FR · RIP BRO

[MINIMAL]
  76-100%: SAFE · STABLE · NOMINAL · OK · CLEAR · SECURE · GOOD · NORMAL
  51-75% : CAUTION · WARNING · ALERT · MINOR DAMAGE · UNSTABLE · CHECK · NOTICE · WATCH
  26-50% : DANGER · DAMAGED · HIGH RISK · SEVERE · UNSAFE · BREACH · FAILING · HAZARD
  6-25%  : CRITICAL · BREAKING · EMERGENCY · CRITICAL DAMAGE · IMMINENT · SYSTEM FAILING · LOW INTEGRITY · RED
  1-5%   : MINIMAL · FINAL · LAST · 1% LEFT · NEAR FAILURE · BARELY · LIMIT · EDGE
  0%     : TOTALLED · DESTROYED · FAILED · OFFLINE · NO CHANCE · ZERO · ENDED · LOST

[DARKHUMOR]
  76-100%: ENJOY IT WHILE IT LASTS · NOT DEAD YET · SPARE PARTS: 0 NEEDED · INSURANCE SMILES · MECHANIC IS SAD · SO FAR SO ALIVE · COFFIN ON HOLD · LIFE IS GOOD
  51-75% : CALL THE MECHANIC · PARTS FALLING OFF? · WRITE YOUR WILL? · TOW TRUCK ON STANDBY · THAT'S EXPENSIVE · SCRAPYARD WAVES · HEARSE WARMING UP · PRAY FOR PAINT
  26-50% : THAT WENT WELL... · CAR IS CRYING · PARTS EVERYWHERE · SCRAPYARD CALLING · RIP BUMPER · FUNERAL BOOKED? · PIECE BY PIECE · WHO NEEDS DOORS
  6-25%  : WELL, THAT'S IT 💀 · PICK A COFFIN · FLOWERS ORDERED · IT WAS A GOOD CAR · EULOGY LOADING · HALF A CAR · CAR.EXE DYING · TELL MY WIFE...
  1-5%   : SAY GOODBYE · ZOMBIE CAR · BORROWED TIME · ALIVE-ISH · WALKING DEAD · ONE FOOT IN SCRAP · GHOST MODE · DEATH IS WAITING
  0%     : REST IN PIECES · SEE YOU NEXT RUN · GOODBYE · LEGO SET NOW · BOX OF PARTS · SCRAP METAL · PAID IN PIECES · ORGAN DONOR

[OPTIMISTIC]
  76-100%: WE GOT THIS · BEAUTIFUL DAY · SMOOTH SAILING · LIVING THE DREAM · PERFECT! · SO PROUD · KEEP IT UP! · YOU'RE AMAZING
  51-75% : STILL GREAT! · JUST A SCRATCH · TOTALLY FINE! · BARELY NOTICED · KEEP GOING · WE'RE OKAY! · NO BIG DEAL · STAY POSITIVE
  26-50% : STILL POSSIBLE! · WE CAN FIX THIS · HALF FULL! · CHIN UP! · DON'T GIVE UP · PLENTY LEFT! · COMEBACK TIME · BELIEVE!
  6-25%  : NOT OVER YET · MIRACLES HAPPEN · STAY STRONG! · STILL MOVING! · EVERY % COUNTS · YOU CAN DO IT! · THINK POSITIVE · HOPE LIVES
  1-5%   : BELIEVE! · 1% IS ENOUGH! · STILL ALIVE = WIN · ANYTHING'S POSSIBLE · LEGENDS DO THIS · COMEBACK LOADING · NEVER SURRENDER · WE'RE SO BACK
  0%     : MAYBE NEXT TIME · ALMOST... · GOOD TRY · YOU DID GREAT · LEARNING EXPERIENCE · PROUD OF YOU · TRY AGAIN! · SO CLOSE!

[PESSIMISTIC]
  76-100%: I DON'T LIKE THIS · TOO GOOD TO BE TRUE · IT WON'T LAST · SOMETHING'S OFF · SUSPICIOUS · HERE IT COMES · ANY MOMENT NOW · DON'T JINX IT
  51-75% : SEE? STARTING · SOMETHING'S WRONG · KNEW IT · DOWNHILL FROM HERE · HERE WE GO AGAIN · OF COURSE · TOLD YOU SO · TYPICAL
  26-50% : THIS WON'T END WELL · DOOMED FROM START · WHAT DID I SAY · NO SURPRISE · INEVITABLE · WORST CASE: NOW · IT ONLY GETS WORSE · WHY DO WE TRY
  6-25%  : YEP. WE'RE DONE. · SAW IT COMING · POINTLESS · SAVE THE REPLAY · WHY BOTHER · WRITTEN IN STONE · COUNTING DOWN · ACCEPT IT
  1-5%   : JUST END IT · PROLONGING PAIN · ALIVE? NOT FOR LONG · DELAYING THE END · ANY SECOND NOW · DON'T GET HOPEFUL · THIS IS DUMB · SIGH.
  0%     : CALLED IT. · TOLD YOU. · OBVIOUSLY. · AS PREDICTED · WHO'S SURPRISED? · NOBODY. · SAME AS ALWAYS · I KNEW IT.

[OVERCONFIDENT]
  76-100%: EASY · LIGHT WORK · I GOT THIS · ZERO PROBLEM · TOO GOOD · NO ONE CAN STOP ME · BUILT DIFFERENT · UNKILLABLE
  51-75% : STILL EASY... · OKAY... · MEANT TO DO THAT · WARM-UP ONLY · STILL WINNING · TOTALLY PLANNED · A SCRATCH. PFF. · WAIT A SECOND...
  26-50% : MAYBE NOT... · HMM. OKAY. · STILL FINE. PROBABLY · THAT WAS LAG · NOT MY FAULT · UH... PLANNED? · LET ME COOK · ALMOST CALCULATED
  6-25%  : I TAKE IT BACK · WE HAVE A PROBLEM · SLIGHT MISTAKE · OKAY THAT HURT · NOT SO EASY · I MAY HAVE LIED · HUMBLED · HELP? JUST ASKING
  1-5%   : OKAY I LIED. · MAYBE NOT. · WE'RE COOKED. · I'M SORRY · NEVER AGAIN · EGO: DESTROYED · WHO SAID EASY? · PLEASE HOLD
  0%     : I LIED. · WE'RE COOKED. · HUMBLED. · LESSON LEARNED · NEVER SPEAKING AGAIN · DON'T SAY IT · OKAY. FAIR. · EGO: 0%

[PANIC]
  76-100%: WE'RE GOOD · ALL GOOD · FINE, TOTALLY FINE · RELAXED · CALM · NO WORRIES · BREATHING NORMAL · CHILL
  51-75% : WAIT... · HOLD ON... · UM... · WAS THAT BAD? · OKAY OKAY · STAY CALM · BREATHE... · IT'S FINE?
  26-50% : WAIT WAIT · NO NO · OH NO · NOT GOOD NOT GOOD · WHAT DO I DO · STAY CALM STAY CALM · OKAY PANIC · UH OH UH OH
  6-25%  : NO NO NO · STOP STOP STOP · PLEASE PLEASE · WHY WHY WHY · HELP HELP · I CAN'T · NONONO · MAKE IT STOP
  1-5%   : NO NO NO NO 💀 · HELP 😭 · PLEASE PLEASE PLEASE · STOP STOP STOP · AAAAAA · I'M GONNA CRY · NONONONONO · MOMMY 😭
  0%     : NOOOOOO · WHY 😭 · I'M SHAKING · IT'S GONE 😭 · NO NO... IT'S OVER · I CAN'T BREATHE · SOBBING · WHAT HAPPENED 😭

[STORYTELLER]
  76-100%: IT BEGAN SO WELL... · HE FELT UNSTOPPABLE · EVERYTHING WAS FINE · IT WAS A GOOD DAY · FOR NOW... · NOBODY SAW IT COMING · LITTLE DID HE KNOW · HE WAS SO SURE
  51-75% : HE HAD NO IDEA... · THEN IT HAPPENED · THE FIRST MISTAKE · SOMETHING CHANGED · A SMALL CRACK · HE IGNORED IT · THAT WAS THE SIGN · AND THEN...
  26-50% : THINGS GOT WORSE... · IT SPIRALED · HE COULDN'T STOP IT · THE TRUTH HIT HARD · NO TURNING BACK · PANIC SET IN · HE KNEW IT THEN · THE ROAD TURNED
  6-25%  : THIS WAS THE MOMENT... · EVERYTHING FELL APART · HE HELD ON · ONE LAST HOPE · THE END WAS NEAR · HE PRAYED · TIME SLOWED DOWN · NOBODY BREATHED
  1-5%   : AGAINST ALL ODDS... · HE REFUSED TO QUIT · ONE HIT FROM LEGEND · HISTORY WATCHED · THE FINAL CHAPTER · ONE LAST BREATH... · WOULD HE MAKE IT? · AND THEN...
  0%     : IT WAS TOO LATE... · THE END. · AND THAT WAS IT · HE NEVER MADE IT · THE STORY ENDS · A TRAGIC ENDING · THEY STILL TALK ABOUT IT · SO IT ENDED

[CLICKBAIT]
  76-100%: 100% PERFECT?! · YOU WON'T BELIEVE THIS · WATCH WHAT HAPPENS · BEST RUN EVER?! · NO DAMAGE?! · WORLD RECORD?! · IS THIS REAL?! · NOT CLICKBAIT
  51-75% : WAIT FOR IT! · SHOCKING! · THIS CHANGES EVERYTHING · UH OH?! · WHAT?! · (GONE WRONG) · UNEXPECTED! · FIRST HIT?!
  26-50% : GONE WRONG! · EMOTIONAL! · DISASTER?! · (NOT CLICKBAIT) · CAUGHT ON CAMERA · HALF GONE?! · INSANE! · OMG!!
  6-25%  : SCARIEST MOMENT! · CAN IT SURVIVE?! · YOU WON'T BELIEVE · 10%?! · 3AM CHALLENGE?! · GONE SUPER WRONG · CRAZIEST EVER · WATCH TILL END
  1-5%   : IMPOSSIBLE?! · 1%?! · MIRACLE?! · SCIENCE CAN'T EXPLAIN · NOBODY SURVIVES THIS · WORLD'S LUCKIEST · INSANE CLUTCH?! · UNBELIEVABLE!!
  0%     : 0%?! · IT'S DESTROYED! · (EMOTIONAL) · I CAN'T BELIEVE IT · RIP?! · IT FINALLY HAPPENED · GONE FOREVER! · SHOCKING ENDING

[BRAINROT]
  76-100%: SKIBIDI SAFE · RIZZ LEVEL MAX · SIGMA DRIVING · GYATT DAMN CLEAN · MEWING AT 100% · AURA +9999 · OHIO? NOT TODAY · FANUM TAX FREE
  51-75% : OHIO MOMENT · AURA -100 · LOW TAPER FADE? · NOT VERY SIGMA · RIZZ DROPPING · EDGING DANGER · SUS AMOGUS · BUSSIN? NO
  26-50% : OHIO FINAL BOSS · AURA DEBT · SKIBIDI DAMAGE · FANUM TAXED · BRAIN = 404 · RIZZ BANKRUPT · GRIMACE SHAKE · MOG'D BY WALL
  6-25%  : BRAINROT CRASH · SKIBIDI DOOMED · NPC MELTDOWN · AURA NEGATIVE · OHIO FOREVER · CAR GOT FANUM'D · BUGGED OUT · L RIZZ
  1-5%   : 1% SIGMA · BRO IS MEWING · AURA FARMING · SKIBIDI MIRACLE · HOW BRO ALIVE · BEYOND OHIO · GLITCH IN MATRIX · BRAIN FULLY ROTTED
  0%     : SKIBIDI TOILETED · OHIO WON · AURA 0 · COOKED ×1000 · FANUM TAXED 100% · BRAIN ROTTED · SIGMA DIED · GYATT DAMN OVER


